# دليل البناء والتشغيل والاختبار — ARCHON SHIELD

## المتطلبات المسبقة على جهاز التطوير
1. **Flutter SDK** (`>= 3.24` / Dart `>= 3.3`).
2. **Android Studio** (Ladybug أو أحدث) مع **Android SDK Platform 35** و **Build-Tools 35.0.0**.
3. **JDK 17**.
4. هاتف Android حقيقي بنظام **Android 8.0 (API 26)** إلى **Android 15 (API 35)**. *(يُفضل الهاتف الحقيقي لاختبار تبديل Wi-Fi / Mobile Data والـ VpnService).*

## خطوات البناء والتشغيل
```bash
cd archon_shield_android
flutter pub get
flutter test
flutter build apk --release
```

### تشغيل اختبارات Kotlin المحلية
```bash
cd archon_shield_android/android
./gradlew testDebugUnitTest
```

### التثبيت على الهاتف عبر ADB
```bash
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

## توقيع نسخة الإنتاج (Release Signing)
قبل النشر الرسمي، أضف ملف `android/key.properties` وعدّل `signingConfig` في `android/app/build.gradle.kts` بمفاتيح التوقيع الخاصة بأرشون تك.
