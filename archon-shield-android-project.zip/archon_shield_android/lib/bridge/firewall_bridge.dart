import 'package:flutter/services.dart';
import '../models/firewall_models.dart';

class FirewallBridge {
  static const MethodChannel _methods =
      MethodChannel('com.archontech.shield/methods');
  static const EventChannel _events =
      EventChannel('com.archontech.shield/events');

  Stream<Map<String, dynamic>> eventsStream() {
    return _events.receiveBroadcastStream().map((event) {
      if (event is Map) {
        return Map<String, dynamic>.from(event);
      }
      return <String, dynamic>{};
    });
  }

  Future<Map<String, dynamic>> getVpnStatus() async {
    final res = await _methods.invokeMapMethod<String, dynamic>('getVpnStatus');
    return res ?? {};
  }

  Future<bool> startFirewall() async {
    return await _methods.invokeMethod<bool>('startFirewall') ?? false;
  }

  Future<bool> stopFirewall() async {
    return await _methods.invokeMethod<bool>('stopFirewall') ?? false;
  }

  Future<bool> requestNotificationPermission() async {
    return await _methods.invokeMethod<bool>('requestNotificationPermission') ??
        false;
  }

  Future<void> openBatteryOptimizationSettings() async {
    await _methods.invokeMethod('openBatteryOptimizationSettings');
  }

  Future<List<InstalledAppItem>> getInstalledApps({bool includeIcons = true}) async {
    final list = await _methods.invokeListMethod<dynamic>(
      'getInstalledApps',
      {'includeIcons': includeIcons},
    );
    return (list ?? [])
        .whereType<Map>()
        .map((m) => InstalledAppItem.fromMap(m))
        .toList();
  }

  Future<void> setAppRule({
    required String packageName,
    required NetworkTransport network,
    required RuleAction action,
    int durationMinutes = 0,
    bool isSensitive = false,
  }) async {
    await _methods.invokeMethod('setAppRule', {
      'packageName': packageName,
      'network': network.wire,
      'action': action.wire,
      'durationMinutes': durationMinutes,
      'isSensitive': isSensitive,
    });
  }

  Future<void> setAppScreenOffBlock(String packageName, bool enabled) async {
    await _methods.invokeMethod('setAppScreenOffBlock', {
      'packageName': packageName,
      'enabled': enabled,
    });
  }

  Future<List<PendingRequestItem>> getPendingRequests() async {
    final list = await _methods.invokeListMethod<dynamic>('getPendingRequests');
    return (list ?? [])
        .whereType<Map>()
        .map((m) => PendingRequestItem.fromMap(m))
        .toList();
  }

  Future<List<ActivityLogItem>> getActivityLogs({String? packageName, int limit = 300}) async {
    final list = await _methods.invokeListMethod<dynamic>('getActivityLogs', {
      'packageName': packageName,
      'limit': limit,
    });
    return (list ?? [])
        .whereType<Map>()
        .map((m) => ActivityLogItem.fromMap(m))
        .toList();
  }

  Future<void> clearActivityLogs({String? packageName}) async {
    await _methods.invokeMethod('clearActivityLogs', {'packageName': packageName});
  }

  Future<Map<String, dynamic>> getStatistics() async {
    final res = await _methods.invokeMapMethod<String, dynamic>('getStatistics');
    return res ?? {};
  }

  Future<List<FirewallProfileItem>> getProfiles() async {
    final list = await _methods.invokeListMethod<dynamic>('getProfiles');
    return (list ?? [])
        .whereType<Map>()
        .map((m) => FirewallProfileItem.fromMap(m))
        .toList();
  }

  Future<void> setActiveProfile(String profileId) async {
    await _methods.invokeMethod('setActiveProfile', {'profileId': profileId});
  }

  Future<void> saveProfile(FirewallProfileItem p) async {
    await _methods.invokeMethod('saveProfile', {
      'id': p.id,
      'nameAr': p.nameAr,
      'nameEn': p.nameEn,
      'defaultWifiRule': p.defaultWifiRule.wire,
      'defaultMobileRule': p.defaultMobileRule.wire,
      'blockOnRoaming': p.blockOnRoaming,
      'screenOffAutoBlock': p.screenOffAutoBlock,
    });
  }

  Future<bool> deleteProfile(String profileId) async {
    return await _methods.invokeMethod<bool>('deleteProfile', {'profileId': profileId}) ?? false;
  }

  Future<List<String>> getBlockedDomains() async {
    final list = await _methods.invokeListMethod<dynamic>('getBlockedDomains');
    return (list ?? []).map((e) => e.toString()).toList();
  }

  Future<void> addBlockedDomain(String domain) async {
    await _methods.invokeMethod('addBlockedDomain', {'domain': domain});
  }

  Future<void> removeBlockedDomain(String domain) async {
    await _methods.invokeMethod('removeBlockedDomain', {'domain': domain});
  }

  Future<Map<String, dynamic>> getSettings() async {
    final res = await _methods.invokeMapMethod<String, dynamic>('getSettings');
    return res ?? {};
  }

  Future<void> updateSettings(Map<String, dynamic> patch) async {
    await _methods.invokeMethod('updateSettings', patch);
  }

  Future<bool> setAppLockPin(String pin) async {
    return await _methods.invokeMethod<bool>('setAppLockPin', {'pin': pin}) ?? false;
  }

  Future<bool> verifyAppLockPin(String pin) async {
    return await _methods.invokeMethod<bool>('verifyAppLockPin', {'pin': pin}) ?? false;
  }

  Future<void> disableAppLock() async {
    await _methods.invokeMethod('disableAppLock');
  }

  Future<bool> authenticateBiometric(String title, String subtitle, String cancel) async {
    final res = await _methods.invokeMapMethod<String, dynamic>('authenticateBiometric', {
      'title': title,
      'subtitle': subtitle,
      'cancel': cancel,
    });
    return res?['success'] == true;
  }

  Future<Map<String, dynamic>> exportBackupViaSaf({String? password}) async {
    final res = await _methods.invokeMapMethod<String, dynamic>('exportBackupViaSaf', {
      'password': password,
    });
    return res ?? {'success': false};
  }

  Future<Map<String, dynamic>> importBackupViaSaf({String? password}) async {
    final res = await _methods.invokeMapMethod<String, dynamic>('importBackupViaSaf', {
      'password': password,
    });
    return res ?? {'success': false};
  }
}
