import 'package:flutter/material.dart';

class AppStrings {
  final String lang;
  const AppStrings(this.lang);

  bool get isAr => lang == 'ar';
  TextDirection get direction => isAr ? TextDirection.rtl : TextDirection.ltr;

  String get brandDual => 'أرشون تك | ARCHON TECH';
  String get appDual => isAr ? 'درع أرشون | ARCHON SHIELD' : 'ARCHON SHIELD | درع أرشون';
  String get officialDesc => isAr
      ? 'جدار الحماية الذكي من أرشون تك — تحكم لحظي وشامل في اتصال كل تطبيق بالواي فاي وبيانات الهاتف، بخصوصية محلية 100%.'
      : 'The Smart Firewall by Archon Tech — Real-time per-app Wi-Fi & mobile data control with 100% local privacy.';

  // Navigation
  String get navHome => isAr ? 'الرئيسية' : 'Home';
  String get navPending => isAr ? 'الانتظار' : 'Pending';
  String get navApps => isAr ? 'التطبيقات' : 'Apps';
  String get navLogs => isAr ? 'السجل' : 'Logs';
  String get navMore => isAr ? 'المزيد' : 'More';

  // Engine Status
  String get startProtection => isAr ? 'ابدأ الحماية' : 'Start Protection';
  String get stopProtection => isAr ? 'إيقاف الحماية' : 'Stop Protection';
  String get statusActive => isAr ? 'الحماية نشطة — وضع الحجب الافتراضي' : 'Protection Active — Default-Deny';
  String get statusStopped => isAr ? 'الحماية متوقفة' : 'Protection Stopped';
  String get statusRevoked => isAr ? 'تم سحب إذن VPN من النظام' : 'VPN Permission Revoked';
  String get statusConflict => isAr ? 'يوجد VPN آخر نشط قد يتعارض مع الدرع' : 'Conflicting VPN Detected';
  String get statusError => isAr ? 'تعذر تشغيل محرك VPN' : 'VPN Engine Error';

  // Rules Symbols
  String get symAllowSession => isAr ? '✓ سماح للجلسة' : '✓ Session Allow';
  String get symAllowPerm => isAr ? '✓✓ سماح دائم' : '✓✓ Permanent Allow';
  String get symDenyTemp => isAr ? '✕ رفض مؤقت' : '✕ Temp Deny';
  String get symDenyPerm => isAr ? '✕✕ حظر دائم' : '✕✕ Permanent Block';
  String get wifiLabel => isAr ? 'واي فاي' : 'Wi-Fi';
  String get mobileLabel => isAr ? 'بيانات الهاتف' : 'Mobile Data';
  String get roamingLabel => isAr ? 'تجوال' : 'Roaming';

  // Classification messages
  String get sevGreenTitle => isAr ? 'آمن للحجب غالباً' : 'Usually Safe to Block';
  String get sevGreenMsg => isAr
      ? 'حجب الإنترنت عن هذا التطبيق لا يؤثر غالباً على وظائفه الأساسية.'
      : 'Blocking internet access for this app usually does not affect its core offline functions.';

  String get sevOrangeTitle => isAr ? 'تأثير متوسط' : 'Medium Impact';
  String get sevOrangeMsg => isAr
      ? 'قد يؤدي حجب الإنترنت إلى توقف الإشعارات والمزامنة وبعض الوظائف.'
      : 'Blocking internet may stop push notifications, cloud sync, and online features.';

  String get sevRedTitle => isAr ? 'تطبيق حساس' : 'Sensitive Component';
  String get sevRedMsg => isAr
      ? 'تحذير: قد يؤثر حجب هذا التطبيق أو الخدمة على استقرار النظام أو وظائف أساسية في الهاتف.'
      : 'Warning: Blocking this app or service may impact OS stability or essential device functions.';

  String get sevUnknownTitle => isAr ? 'غير معروف' : 'Unknown';
  String get sevUnknownMsg => isAr
      ? 'لا تتوفر أدلة كافية لتصنيف هذا التطبيق تلقائياً بدقة.'
      : 'Insufficient metadata to classify impact reliably.';

  // Sections & Screens
  String get screenProtectionControl => isAr ? 'التحكم بالحماية والـ VPN' : 'Protection & VPN Control';
  String get screenStats => isAr ? 'الإحصائيات والبيانات' : 'Statistics & Traffic';
  String get screenProfiles => isAr ? 'ملفات التعريف' : 'Firewall Profiles';
  String get screenSettings => isAr ? 'الإعدادات' : 'Settings';
  String get screenBackup => isAr ? 'النسخ الاحتياطي المحلي' : 'Local Backup & Restore';
  String get screenAppLock => isAr ? 'قفل التطبيق والأمان' : 'App Lock & Security';
  String get screenHelp => isAr ? 'المساعدة والدعم' : 'Help & Support';
  String get screenAbout => isAr ? 'من نحن' : 'About ARCHON TECH';
  String get screenPermissions => isAr ? 'الصلاحيات والإعداد الأولي' : 'Permissions & Setup';

  String get localPrivacyPledge => isAr
      ? 'تطبيق محلي بالكامل (Local-First): لا يرسل أي أسماء تطبيقات أو سجلات أو نطاقات أو نسخ احتياطية لأي خادم خارجي.'
      : '100% Local-First: No app lists, logs, domains, or backups are ever sent to external servers.';

  String get aboutBio => isAr
      ? 'أرشون تك | ARCHON TECH مساحة تقنية تنطلق من الشغف بالابتكار والمعرفة، وتهتم بتطوير الحلول الرقمية والتطبيقات والأنظمة الحديثة، واستكشاف مجالات الذكاء الاصطناعي والأمن السيبراني.'
      : 'ARCHON TECH is a technology hub driven by innovation and knowledge, building modern digital solutions, apps, and systems while exploring AI and cybersecurity.';

  String get aboutVision => isAr
      ? 'نؤمن أن التقنية تبدأ بفكرة، وتنمو بالمعرفة، وتترك أثرها عندما تتحول إلى حل يخدم الإنسان.'
      : 'We believe technology starts with an idea, grows through knowledge, and leaves its mark when turned into a human-centric solution.';
}
