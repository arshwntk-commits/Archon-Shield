import 'package:flutter/material.dart';

class ArchonColors {
  static const Color obsidianBg = Color(0xFF05070A);
  static const Color surfaceCard = Color(0xFF0E131B);
  static const Color surfaceElevated = Color(0xFF141B26);
  static const Color borderSubtle = Color(0xFF1E293B);

  static const Color archonBlue = Color(0xFF1A6BFF);
  static const Color archonBlueGlow = Color(0xFF3B82F6);

  static const Color safeGreen = Color(0xFF10B981);
  static const Color warningOrange = Color(0xFFF59E0B);
  static const Color dangerRed = Color(0xFFEF4444);
  static const Color unknownSlate = Color(0xFF64748B);

  static const Color textPrimary = Color(0xFFF8FAFC);
  static const Color textSecondary = Color(0xFF94A3B8);
}

class ArchonTheme {
  static ThemeData buildDarkTheme() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: ArchonColors.obsidianBg,
      colorScheme: const ColorScheme.dark(
        primary: ArchonColors.archonBlue,
        secondary: ArchonColors.archonBlueGlow,
        surface: ArchonColors.surfaceCard,
        error: ArchonColors.dangerRed,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: ArchonColors.obsidianBg,
        foregroundColor: ArchonColors.textPrimary,
        elevation: 0,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        color: ArchonColors.surfaceCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: ArchonColors.borderSubtle, width: 1),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: ArchonColors.surfaceCard,
        indicatorColor: ArchonColors.archonBlue.withValues(alpha: 0.18),
        labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}
