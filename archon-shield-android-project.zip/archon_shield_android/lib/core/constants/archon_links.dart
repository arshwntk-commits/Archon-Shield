class ArchonLinks {
  static const String officialWebsite = 'https://archon-tech-m.netlify.app/';
  static const String supportBot = 'https://t.me/Archon_S_BOT';
  static const String telegramChannel = 'https://t.me/ArchonTech';
  static const String whatsappChannel =
      'https://whatsapp.com/channel/0029Vb7zJIs5PO0vfbmXoL0K';
  static const String facebookPage = 'https://www.facebook.com/ArchonTech2026';
  static const String instagramAccount =
      'https://www.instagram.com/archon_tech2026';

  static const String faqPage = 'https://archon-tech-m.netlify.app/#faq';
  static const String contactPage = 'https://archon-tech-m.netlify.app/#contact';
  static const String allPolicies =
      'https://archon-tech-m.netlify.app/policies/';
  static const String privacyPolicy =
      'https://archon-tech-m.netlify.app/policies/privacy-policy';
  static const String termsOfUse =
      'https://archon-tech-m.netlify.app/policies/terms-of-use';
  static const String intellectualProperty =
      'https://archon-tech-m.netlify.app/policies/intellectual-property';
}
