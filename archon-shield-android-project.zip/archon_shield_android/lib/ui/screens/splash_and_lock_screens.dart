import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/archon_theme.dart';
import '../../state/firewall_controller.dart';

// Screen 1: Splash Screen
class SplashScreen extends StatelessWidget {
  final AppStrings strings;
  const SplashScreen({super.key, required this.strings});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ArchonColors.obsidianBg,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset('assets/images/archon-tech-logo.png', width: 150, height: 150),
            const SizedBox(height: 20),
            Text(
              strings.appDual,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            Text(
              strings.brandDual,
              style: const TextStyle(
                fontSize: 13,
                color: ArchonColors.archonBlueGlow,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 28),
            const SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(strokeWidth: 2.5, color: ArchonColors.archonBlue),
            ),
          ],
        ),
      ),
    );
  }
}

// Screen 16: App Lock Screen (Biometric + PIN)
class AppLockScreen extends StatefulWidget {
  final FirewallController controller;
  final AppStrings strings;
  const AppLockScreen({super.key, required this.controller, required this.strings});

  @override
  State<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends State<AppLockScreen> {
  final _pinCtrl = TextEditingController();
  String? _error;

  @override
  void initState() {
    super.initState();
    if (widget.controller.biometricAvailable) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _tryBiometric());
    }
  }

  Future<void> _tryBiometric() async {
    await widget.controller.unlockWithBiometric(
      widget.strings.appDual,
      widget.strings.isAr ? 'تحقق بالبصمة لفتح درع أرشون' : 'Authenticate to unlock ARCHON SHIELD',
      widget.strings.isAr ? 'استخدام الرمز' : 'Use PIN',
    );
  }

  Future<void> _verifyPin() async {
    final ok = await widget.controller.unlockWithPin(_pinCtrl.text.trim());
    if (!ok && mounted) {
      setState(() {
        _error = widget.strings.isAr ? 'الرمز السري غير صحيح' : 'Incorrect PIN';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.strings;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/images/archon-tech-logo.png', width: 92, height: 92),
              const SizedBox(height: 16),
              Text(s.appDual, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(
                s.isAr ? 'التطبيق مقفل لحماية قواعد الجدار الناري' : 'App locked to protect firewall rules',
                style: const TextStyle(color: ArchonColors.textSecondary),
              ),
              const SizedBox(height: 24),
              TextField(
                controller: _pinCtrl,
                obscureText: true,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: s.isAr ? 'أدخل رمز PIN' : 'Enter PIN',
                  errorText: _error,
                  border: const OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: ArchonColors.archonBlue),
                  onPressed: _verifyPin,
                  child: Text(s.isAr ? 'فتح القفل' : 'Unlock'),
                ),
              ),
              if (widget.controller.biometricAvailable) ...[
                const SizedBox(height: 12),
                TextButton.icon(
                  onPressed: _tryBiometric,
                  icon: const Icon(Icons.fingerprint),
                  label: Text(s.isAr ? 'فتح بالبصمة' : 'Unlock with Biometrics'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// Screen 20: Permissions & First-Run Setup Screen
class PermissionsSetupScreen extends StatelessWidget {
  final FirewallController controller;
  final AppStrings strings;
  final VoidCallback onContinue;
  const PermissionsSetupScreen({
    super.key,
    required this.controller,
    required this.strings,
    required this.onContinue,
  });

  @override
  Widget build(BuildContext context) {
    final s = strings;
    return Scaffold(
      appBar: AppBar(title: Text(s.screenPermissions)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    s.isAr ? '1. صلاحية VPN المحلي (بدون Root)' : '1. Local VPN Permission (No Root)',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    s.isAr
                        ? 'يستخدم درع أرشون خدمة VpnService المحلية داخل الجهاز لاعتراض الحزم غير المصرح بها دون إرسال أي بيانات لخوادم خارجية.'
                        : 'ARCHON SHIELD uses Android local VpnService on-device to block unauthorized traffic without external servers.',
                    style: const TextStyle(color: ArchonColors.textSecondary, height: 1.5),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Icon(
                        controller.vpnConsentGranted ? Icons.check_circle : Icons.pending_outlined,
                        color: controller.vpnConsentGranted
                            ? ArchonColors.safeGreen
                            : ArchonColors.warningOrange,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        controller.vpnConsentGranted
                            ? (s.isAr ? 'ممنوحة' : 'Granted')
                            : (s.isAr ? 'تُطلب عند الضغط على ابدأ' : 'Requested on Start'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    s.isAr ? '2. صلاحية الإشعارات الفورية' : '2. Instant Notification Permission',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    s.isAr
                        ? 'لعرض طلبات الانتظار بأزرار السماح والرفض المباشرة وتنبيهات توقف الحماية.'
                        : 'Required on Android 13+ for instant connection prompts and service stop alerts.',
                    style: const TextStyle(color: ArchonColors.textSecondary, height: 1.5),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton.icon(
                    onPressed: () => controller.requestNotifications(),
                    icon: const Icon(Icons.notifications_active_outlined),
                    label: Text(
                      controller.notificationsGranted
                          ? (s.isAr ? 'الإشعارات مفعّلة ✓' : 'Notifications Enabled ✓')
                          : (s.isAr ? 'منح صلاحية الإشعارات' : 'Grant Notification Permission'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    s.isAr ? '3. استثناء تحسين البطارية' : '3. Battery Optimization Exemption',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    s.isAr
                        ? 'يوصى باستثناء درع أرشون من تحسين البطارية حتى لا يوقف نظام Android خدمة الجدار الناري في الخلفية.'
                        : 'Recommended so Android does not kill the background firewall service.',
                    style: const TextStyle(color: ArchonColors.textSecondary, height: 1.5),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: () => controller.openBatterySettings(),
                    icon: const Icon(Icons.battery_saver_outlined),
                    label: Text(
                      controller.batteryOptimizationIgnored
                          ? (s.isAr ? 'مستثنى من التقييد ✓' : 'Unrestricted ✓')
                          : (s.isAr ? 'فتح إعدادات البطارية' : 'Open Battery Settings'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 48,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: ArchonColors.archonBlue),
              onPressed: onContinue,
              child: Text(s.isAr ? 'متابعة للتطبيق' : 'Continue to App'),
            ),
          ),
        ],
      ),
    );
  }
}

// Screen 19: Reusable Error & Empty State View
class ArchonStateView extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final Color accent;
  final String? actionLabel;
  final VoidCallback? onAction;

  const ArchonStateView({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.accent = ArchonColors.textSecondary,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 46, color: accent),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 6),
            Text(
              message,
              style: const TextStyle(color: ArchonColors.textSecondary, height: 1.5),
              textAlign: TextAlign.center,
            ),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 16),
              OutlinedButton(onPressed: onAction, child: Text(actionLabel!)),
            ],
          ],
        ),
      ),
    );
  }
}
