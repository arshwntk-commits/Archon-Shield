import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/archon_theme.dart';
import '../../models/firewall_models.dart';
import '../../state/firewall_controller.dart';
import '../widgets/archon_brand_widgets.dart';

// Screen 2: Home Dashboard
class HomeDashboardScreen extends StatelessWidget {
  final FirewallController controller;
  final AppStrings strings;
  final ValueChanged<int> onNavigateTab;
  final VoidCallback onOpenProtectionControl;
  final VoidCallback onOpenStats;
  final VoidCallback onOpenProfiles;

  const HomeDashboardScreen({
    super.key,
    required this.controller,
    required this.strings,
    required this.onNavigateTab,
    required this.onOpenProtectionControl,
    required this.onOpenStats,
    required this.onOpenProfiles,
  });

  @override
  Widget build(BuildContext context) {
    final s = strings;
    final active = controller.vpnState == VpnEngineState.active;
    final pendingCount =
        controller.pendingRequests.where((r) => r.status == 'new').length;
    final stats = controller.statistics;
    final blockedAttempts = (stats['totalBlocked'] as num?)?.toInt() ?? 0;
    final allowedAttempts = (stats['totalAllowed'] as num?)?.toInt() ?? 0;

    return Stack(
      children: [
        const ArchonAmbientWatermark(opacity: 0.06),
        ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (controller.externalVpnDetected && !active)
              Card(
                color: ArchonColors.warningOrange.withValues(alpha: 0.14),
                child: ListTile(
                  leading: const Icon(Icons.vpn_lock, color: ArchonColors.warningOrange),
                  title: Text(s.statusConflict),
                  subtitle: Text(
                    s.isAr
                        ? 'نظام Android يسمح باتصال VPN واحد فقط في نفس الوقت.'
                        : 'Android allows only one active VpnService at a time.',
                  ),
                ),
              ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _statusLabel(controller.vpnState, s),
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: active ? ArchonColors.safeGreen : ArchonColors.dangerRed,
                          ),
                        ),
                        InkWell(
                          onTap: onOpenProtectionControl,
                          child: const Icon(Icons.tune, size: 20, color: ArchonColors.archonBlueGlow),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    GestureDetector(
                      onTap: () => controller.toggleProtection(),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        width: 146,
                        height: 146,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: active
                              ? ArchonColors.safeGreen.withValues(alpha: 0.14)
                              : ArchonColors.archonBlue.withValues(alpha: 0.16),
                          border: Border.all(
                            color: active ? ArchonColors.safeGreen : ArchonColors.archonBlue,
                            width: 3,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              active ? Icons.shield : Icons.power_settings_new,
                              size: 44,
                              color: active ? ArchonColors.safeGreen : ArchonColors.textPrimary,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              active ? s.stopProtection : s.startProtection,
                              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      '${_networkLabel(controller.currentNetwork, s)}${controller.isRoaming ? ' · ${s.roamingLabel}' : ''}',
                      style: const TextStyle(color: ArchonColors.textSecondary, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _StatTile(
                    label: s.isAr ? 'محجوب' : 'Blocked',
                    value: '$blockedAttempts',
                    color: ArchonColors.dangerRed,
                    onTap: onOpenStats,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _StatTile(
                    label: s.isAr ? 'مسموح' : 'Allowed',
                    value: '$allowedAttempts',
                    color: ArchonColors.safeGreen,
                    onTap: onOpenStats,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _StatTile(
                    label: s.isAr ? 'طلبات انتظار' : 'Pending',
                    value: '$pendingCount',
                    color: ArchonColors.warningOrange,
                    onTap: () => onNavigateTab(1),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.layers_outlined, color: ArchonColors.archonBlueGlow),
                title: Text(s.screenProfiles),
                subtitle: Text(
                  controller.profiles
                          .where((p) => p.id == controller.activeProfileId)
                          .map((p) => s.isAr ? p.nameAr : p.nameEn)
                          .firstOrNull ??
                      controller.activeProfileId,
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: onOpenProfiles,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              s.localPrivacyPledge,
              style: const TextStyle(fontSize: 11, color: ArchonColors.textSecondary),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ],
    );
  }

  String _statusLabel(VpnEngineState st, AppStrings s) {
    switch (st) {
      case VpnEngineState.active:
        return s.statusActive;
      case VpnEngineState.revoked:
        return s.statusRevoked;
      case VpnEngineState.conflictOtherVpn:
        return s.statusConflict;
      case VpnEngineState.error:
        return s.statusError;
      default:
        return s.statusStopped;
    }
  }

  String _networkLabel(NetworkTransport t, AppStrings s) {
    switch (t) {
      case NetworkTransport.wifi:
        return s.wifiLabel;
      case NetworkTransport.mobile:
        return s.mobileLabel;
      case NetworkTransport.roaming:
        return s.roamingLabel;
      case NetworkTransport.none:
        return s.isAr ? 'غير متصل' : 'Offline';
    }
  }
}

class _StatTile extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final VoidCallback onTap;
  const _StatTile({
    required this.label,
    required this.value,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
          child: Column(
            children: [
              Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: color)),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(fontSize: 11, color: ArchonColors.textSecondary)),
            ],
          ),
        ),
      ),
    );
  }
}

// Screen 3: Protection & VPN Control Screen
class ProtectionControlScreen extends StatelessWidget {
  final FirewallController controller;
  final AppStrings strings;
  const ProtectionControlScreen({super.key, required this.controller, required this.strings});

  @override
  Widget build(BuildContext context) {
    final s = strings;
    final active = controller.vpnState == VpnEngineState.active;
    return Scaffold(
      appBar: AppBar(title: Text(s.screenProtectionControl)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: Icon(
                active ? Icons.shield : Icons.shield_outlined,
                color: active ? ArchonColors.safeGreen : ArchonColors.dangerRed,
              ),
              title: Text(active ? s.statusActive : s.statusStopped),
              subtitle: Text('VPN State: ${controller.vpnState.wire}'),
              trailing: Switch(
                value: active,
                onChanged: (_) => controller.toggleProtection(),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                s.isAr
                    ? 'آلية العمل الهندسية:\n• يتم تطبيق Default-Deny عبر VpnService المحلي بدون Root.\n• يتم توجيه IPv4 (0.0.0.0/0) و IPv6 (::/0) للتطبيقات المحجوبة داخل واجهة TUN لمنع التسريب.\n• عند إيقاف الحماية أو إعادة تشغيل الهاتف، تُمسح قواعد الجلسة (✓ و ✕) تلقائياً وتبقى القواعد الدائمة (✓✓ و ✕✕).'
                    : 'Architecture:\n• Default-Deny enforced via local VpnService (No-Root).\n• Both IPv4 & IPv6 of blocked apps are trapped in TUN to prevent leaks.\n• Ephemeral session rules (✓ / ✕) clear automatically on stop or reboot.',
                style: const TextStyle(color: ArchonColors.textSecondary, height: 1.6),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Screen 9: Statistics Screen
class StatisticsScreen extends StatelessWidget {
  final FirewallController controller;
  final AppStrings strings;
  const StatisticsScreen({super.key, required this.controller, required this.strings});

  @override
  Widget build(BuildContext context) {
    final s = strings;
    final st = controller.statistics;
    final topApps = (st['topApps'] as List?) ?? [];
    final tunBytes = (st['tunneledBytesRead'] as num?)?.toInt() ?? 0;

    return Scaffold(
      appBar: AppBar(title: Text(s.screenStats)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(s.isAr ? 'ملخص المحاولات' : 'Attempts Summary',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  _row(s.isAr ? 'اليوم' : 'Today', '${st['todayAttempts'] ?? 0}'),
                  _row(s.isAr ? 'آخر 7 أيام' : 'Last 7 Days', '${st['weekAttempts'] ?? 0}'),
                  _row(s.isAr ? 'آخر 30 يوماً' : 'Last 30 Days', '${st['monthAttempts'] ?? 0}'),
                  _row(
                    s.isAr ? 'حجم الحزم المحجوبة المقروءة في TUN' : 'Blocked TUN Bytes Observed',
                    '${(tunBytes / 1024).toStringAsFixed(1)} KB',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(s.isAr ? 'أكثر التطبيقات نشاطاً' : 'Most Active Apps',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  if (topApps.isEmpty)
                    Text(s.isAr ? 'لا توجد إحصائيات مسجلة بعد.' : 'No recorded stats yet.',
                        style: const TextStyle(color: ArchonColors.textSecondary)),
                  ...topApps.map((item) {
                    final m = item as Map;
                    return ListTile(
                      dense: true,
                      title: Text(m['appName']?.toString() ?? ''),
                      subtitle: Text(m['packageName']?.toString() ?? ''),
                      trailing: Text('${m['attempts']} (${m['blocked']} ✕)'),
                    );
                  }),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(k, style: const TextStyle(color: ArchonColors.textSecondary)),
            Text(v, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      );
}

// Screen 10: Firewall Profiles Screen
class ProfilesScreen extends StatelessWidget {
  final FirewallController controller;
  final AppStrings strings;
  const ProfilesScreen({super.key, required this.controller, required this.strings});

  @override
  Widget build(BuildContext context) {
    final s = strings;
    return Scaffold(
      appBar: AppBar(title: Text(s.screenProfiles)),
      floatingActionButton: FloatingActionButton(
        backgroundColor: ArchonColors.archonBlue,
        onPressed: () => _createCustomProfile(context),
        child: const Icon(Icons.add),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: controller.profiles.map((p) {
          final active = p.id == controller.activeProfileId;
          return Card(
            child: ListTile(
              leading: Icon(
                active ? Icons.radio_button_checked : Icons.radio_button_off,
                color: active ? ArchonColors.archonBlueGlow : ArchonColors.textSecondary,
              ),
              title: Text(s.isAr ? p.nameAr : p.nameEn),
              subtitle: Text(
                'Wi-Fi: ${p.defaultWifiRule.symbol} · Mobile: ${p.defaultMobileRule.symbol}',
                style: const TextStyle(fontSize: 12),
              ),
              trailing: p.isBuiltIn
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.delete_outline, color: ArchonColors.dangerRed),
                      onPressed: () => controller.deleteProfile(p.id),
                    ),
              onTap: () => controller.setActiveProfile(p.id),
            ),
          );
        }).toList(),
      ),
    );
  }

  Future<void> _createCustomProfile(BuildContext context) async {
    final nameCtrl = TextEditingController();
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: ArchonColors.surfaceCard,
        title: Text(strings.isAr ? 'ملف تعريف جديد' : 'New Firewall Profile'),
        content: TextField(
          controller: nameCtrl,
          decoration: InputDecoration(
            labelText: strings.isAr ? 'اسم الملف' : 'Profile Name',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(strings.isAr ? 'إلغاء' : 'Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final title = nameCtrl.text.trim();
              if (title.isEmpty) return;
              await controller.saveCustomProfile(
                FirewallProfileItem(
                  id: 'custom_${DateTime.now().millisecondsSinceEpoch}',
                  nameAr: title,
                  nameEn: title,
                  isBuiltIn: false,
                  defaultWifiRule: RuleAction.none,
                  defaultMobileRule: RuleAction.denyPermanent,
                  blockOnRoaming: true,
                  screenOffAutoBlock: false,
                ),
              );
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: Text(strings.isAr ? 'حفظ' : 'Save'),
          ),
        ],
      ),
    );
  }
}
