import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/archon_theme.dart';
import '../../models/firewall_models.dart';
import '../../state/firewall_controller.dart';
import '../widgets/archon_brand_widgets.dart';
import 'splash_and_lock_screens.dart';

// Screen 4: Apps List Screen
class AppsListScreen extends StatefulWidget {
  final FirewallController controller;
  final AppStrings strings;
  const AppsListScreen({super.key, required this.controller, required this.strings});

  @override
  State<AppsListScreen> createState() => _AppsListScreenState();
}

class _AppsListScreenState extends State<AppsListScreen> {
  String _search = '';
  String _filterType = 'all'; // all | user | system | allowed | blocked | new
  bool _sortAsc = true;

  @override
  Widget build(BuildContext context) {
    final s = widget.strings;
    final now = DateTime.now().millisecondsSinceEpoch;
    final filtered = widget.controller.apps.where((a) {
      if (_search.isNotEmpty) {
        final q = _search.toLowerCase();
        if (!a.appName.toLowerCase().contains(q) &&
            !a.packageName.toLowerCase().contains(q)) {
          return false;
        }
      }
      switch (_filterType) {
        case 'user':
          return !a.isSystemApp;
        case 'system':
          return a.isSystemApp;
        case 'allowed':
          return a.rules.wifiRule.isAllow || a.rules.mobileRule.isAllow;
        case 'blocked':
          return a.rules.wifiRule.isDeny || a.rules.mobileRule.isDeny || a.isQuarantined;
        case 'new':
          return a.isQuarantined || (now - a.installedAtMs < 7 * 86400000);
        default:
          return true;
      }
    }).toList()
      ..sort((a, b) => _sortAsc
          ? a.appName.toLowerCase().compareTo(b.appName.toLowerCase())
          : b.appName.toLowerCase().compareTo(a.appName.toLowerCase()));

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  onChanged: (v) => setState(() => _search = v),
                  decoration: InputDecoration(
                    hintText: s.isAr ? 'بحث بالاسم أو الحزمة...' : 'Search app or package...',
                    prefixIcon: const Icon(Icons.search),
                    isDense: true,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: Icon(_sortAsc ? Icons.sort_by_alpha : Icons.sort),
                onPressed: () => setState(() => _sortAsc = !_sortAsc),
              ),
            ],
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              _chip('all', s.isAr ? 'الكل' : 'All'),
              _chip('user', s.isAr ? 'المستخدم' : 'User'),
              _chip('system', s.isAr ? 'النظام' : 'System'),
              _chip('allowed', s.isAr ? 'مسموح' : 'Allowed'),
              _chip('blocked', s.isAr ? 'محجوب' : 'Blocked'),
              _chip('new', s.isAr ? 'جديد / حجر' : 'New'),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Expanded(
          child: filtered.isEmpty
              ? ArchonStateView(
                  icon: Icons.apps_outage,
                  title: s.isAr ? 'لا توجد تطبيقات مطابقة' : 'No Matching Apps',
                  message: s.isAr ? 'جرّب تغيير البحث أو الفلتر.' : 'Adjust search or filters.',
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: filtered.length,
                  itemBuilder: (ctx, i) {
                    final app = filtered[i];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AppDetailsScreen(
                              app: app,
                              controller: widget.controller,
                              strings: s,
                            ),
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  AppIconView(iconBase64: app.iconBase64, size: 42),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(app.appName,
                                            style: const TextStyle(fontWeight: FontWeight.bold)),
                                        Text(
                                          '${app.packageName} · UID ${app.uid}',
                                          style: const TextStyle(
                                              fontSize: 11, color: ArchonColors.textSecondary),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                    ),
                                  ),
                                  SeverityIndicator(severity: app.severity, strings: s),
                                ],
                              ),
                              if (!app.isControllable) ...[
                                const SizedBox(height: 6),
                                Text(
                                  s.isAr
                                      ? 'غير متاح للتحكم بسبب قيود النظام (${app.controlLimitationReason})'
                                      : 'Not controllable due to OS restriction (${app.controlLimitationReason})',
                                  style: const TextStyle(
                                      fontSize: 11, color: ArchonColors.warningOrange),
                                ),
                              ] else ...[
                                const SizedBox(height: 10),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(s.wifiLabel,
                                        style: const TextStyle(
                                            fontSize: 12, color: ArchonColors.textSecondary)),
                                    RuleSymbolBar(
                                      compact: true,
                                      current: app.rules.wifiRule,
                                      onSelected: (act) async {
                                        if (await confirmSensitiveBlockIfNeeded(
                                            context, app, act, s)) {
                                          await widget.controller.setAppRule(
                                            packageName: app.packageName,
                                            network: NetworkTransport.wifi,
                                            action: act,
                                            isSensitive:
                                                app.severity == AppSeverity.sensitiveRed,
                                          );
                                        }
                                      },
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 6),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(s.mobileLabel,
                                        style: const TextStyle(
                                            fontSize: 12, color: ArchonColors.textSecondary)),
                                    RuleSymbolBar(
                                      compact: true,
                                      current: app.rules.mobileRule,
                                      onSelected: (act) async {
                                        if (await confirmSensitiveBlockIfNeeded(
                                            context, app, act, s)) {
                                          await widget.controller.setAppRule(
                                            packageName: app.packageName,
                                            network: NetworkTransport.mobile,
                                            action: act,
                                            isSensitive:
                                                app.severity == AppSeverity.sensitiveRed,
                                          );
                                        }
                                      },
                                    ),
                                  ],
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _chip(String key, String label) {
    final active = _filterType == key;
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 6),
      child: ChoiceChip(
        label: Text(label),
        selected: active,
        onSelected: (_) => setState(() => _filterType = key),
      ),
    );
  }
}

// Screen 5: App Details Screen
class AppDetailsScreen extends StatelessWidget {
  final InstalledAppItem app;
  final FirewallController controller;
  final AppStrings strings;

  const AppDetailsScreen({
    super.key,
    required this.app,
    required this.controller,
    required this.strings,
  });

  @override
  Widget build(BuildContext context) {
    final s = strings;
    final liveApp = controller.apps.firstWhere(
      (a) => a.packageName == app.packageName,
      orElse: () => app,
    );

    return Scaffold(
      appBar: AppBar(title: Text(liveApp.appName)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  AppIconView(iconBase64: liveApp.iconBase64, size: 54),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(liveApp.appName,
                            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                        Text(liveApp.packageName,
                            style: const TextStyle(fontSize: 12, color: ArchonColors.textSecondary)),
                        Text('UID: ${liveApp.uid} · ${liveApp.isSystemApp ? (s.isAr ? 'تطبيق نظام' : 'System App') : (s.isAr ? 'تطبيق مستخدم' : 'User App')}',
                            style: const TextStyle(fontSize: 12, color: ArchonColors.textSecondary)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SeverityIndicator(severity: liveApp.severity, strings: s),
                  const SizedBox(height: 8),
                  Text(_severityMessage(liveApp.severity, s),
                      style: const TextStyle(color: ArchonColors.textSecondary, height: 1.5)),
                  if (liveApp.sharedUidPackages.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      s.isAr
                          ? 'ملاحظة: يشارك هذا التطبيق نفس UID مع: ${liveApp.sharedUidPackages.join(", ")}'
                          : 'Note: Shares UID with: ${liveApp.sharedUidPackages.join(", ")}',
                      style: const TextStyle(fontSize: 12, color: ArchonColors.warningOrange),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (liveApp.isControllable)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.wifiLabel, style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    RuleSymbolBar(
                      current: liveApp.rules.wifiRule,
                      onSelected: (act) async {
                        if (await confirmSensitiveBlockIfNeeded(context, liveApp, act, s)) {
                          await controller.setAppRule(
                            packageName: liveApp.packageName,
                            network: NetworkTransport.wifi,
                            action: act,
                            isSensitive: liveApp.severity == AppSeverity.sensitiveRed,
                          );
                        }
                      },
                      onTimedAllow: () async {
                        final mins = await showTimedAllowDialog(context, s);
                        if (mins != null) {
                          await controller.setAppRule(
                            packageName: liveApp.packageName,
                            network: NetworkTransport.wifi,
                            action: RuleAction.allowTimed,
                            durationMinutes: mins,
                          );
                        }
                      },
                    ),
                    const SizedBox(height: 16),
                    Text(s.mobileLabel, style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    RuleSymbolBar(
                      current: liveApp.rules.mobileRule,
                      onSelected: (act) async {
                        if (await confirmSensitiveBlockIfNeeded(context, liveApp, act, s)) {
                          await controller.setAppRule(
                            packageName: liveApp.packageName,
                            network: NetworkTransport.mobile,
                            action: act,
                            isSensitive: liveApp.severity == AppSeverity.sensitiveRed,
                          );
                        }
                      },
                      onTimedAllow: () async {
                        final mins = await showTimedAllowDialog(context, s);
                        if (mins != null) {
                          await controller.setAppRule(
                            packageName: liveApp.packageName,
                            network: NetworkTransport.mobile,
                            action: RuleAction.allowTimed,
                            durationMinutes: mins,
                          );
                        }
                      },
                    ),
                    const Divider(height: 24),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(s.isAr ? 'حجب تلقائي عند إطفاء الشاشة' : 'Screen-Off Auto-Block'),
                      value: liveApp.rules.screenOffBlock,
                      onChanged: (v) => controller.setAppScreenOffBlock(liveApp.packageName, v),
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => PerAppLogScreen(
                  packageName: liveApp.packageName,
                  appName: liveApp.appName,
                  controller: controller,
                  strings: s,
                ),
              ),
            ),
            icon: const Icon(Icons.history),
            label: Text(s.isAr ? 'عرض سجل نشاط هذا التطبيق' : 'View App Activity Log'),
          ),
        ],
      ),
    );
  }

  String _severityMessage(AppSeverity sev, AppStrings s) {
    switch (sev) {
      case AppSeverity.safeGreen:
        return s.sevGreenMsg;
      case AppSeverity.mediumOrange:
        return s.sevOrangeMsg;
      case AppSeverity.sensitiveRed:
        return s.sevRedMsg;
      case AppSeverity.unknown:
        return s.sevUnknownMsg;
    }
  }
}

// Screen 8: Per-App Activity Log Screen
class PerAppLogScreen extends StatelessWidget {
  final String packageName;
  final String appName;
  final FirewallController controller;
  final AppStrings strings;

  const PerAppLogScreen({
    super.key,
    required this.packageName,
    required this.appName,
    required this.controller,
    required this.strings,
  });

  @override
  Widget build(BuildContext context) {
    final s = strings;
    final appLogs = controller.logs.where((l) => l.packageName == packageName).toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(appName),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep_outlined),
            onPressed: () => controller.clearLogs(packageName: packageName),
          ),
        ],
      ),
      body: appLogs.isEmpty
          ? ArchonStateView(
              icon: Icons.receipt_long_outlined,
              title: s.isAr ? 'لا توجد سجلات لهذا التطبيق' : 'No Logs For This App',
              message: s.isAr ? 'ستظهر محاولات الاتصال هنا فور رصدها.' : 'Connection attempts appear here.',
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: appLogs.length,
              itemBuilder: (ctx, i) {
                final item = appLogs[i];
                final allowed = item.decision == 'allowed';
                return Card(
                  child: ListTile(
                    leading: Icon(
                      allowed ? Icons.check_circle : Icons.block,
                      color: allowed ? ArchonColors.safeGreen : ArchonColors.dangerRed,
                    ),
                    title: Text(item.domain ?? item.destIp ?? '—'),
                    subtitle: Text(
                      '${item.network.wire} · ${item.protocol ?? ''} : ${item.destPort ?? ''} · ${item.reason} (${item.ruleSource})',
                      style: const TextStyle(fontSize: 11),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
