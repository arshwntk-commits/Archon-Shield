import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/constants/archon_links.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/archon_theme.dart';
import '../../state/firewall_controller.dart';
import 'home_and_protection_screens.dart';
import 'splash_and_lock_screens.dart';

// Hub screen linking Screens 11-18 + 3, 9, 10, 20
class MoreHubScreen extends StatelessWidget {
  final FirewallController controller;
  final AppStrings strings;
  const MoreHubScreen({super.key, required this.controller, required this.strings});

  @override
  Widget build(BuildContext context) {
    final s = strings;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _navTile(context, Icons.bar_chart, s.screenStats,
            () => StatisticsScreen(controller: controller, strings: s)),
        _navTile(context, Icons.layers, s.screenProfiles,
            () => ProfilesScreen(controller: controller, strings: s)),
        _navTile(context, Icons.security, s.isAr ? 'إعدادات الحماية' : 'Protection Settings',
            () => ProtectionSettingsScreen(controller: controller, strings: s)),
        _navTile(context, Icons.notifications_outlined, s.isAr ? 'إعدادات الإشعارات' : 'Notification Settings',
            () => NotificationSettingsScreen(controller: controller, strings: s)),
        _navTile(context, Icons.language, s.isAr ? 'اللغة والمظهر' : 'Language & Theme',
            () => LanguageThemeSettingsScreen(controller: controller, strings: s)),
        _navTile(context, Icons.privacy_tip_outlined, s.isAr ? 'إعدادات الخصوصية والنطاقات' : 'Privacy & Domains',
            () => PrivacySettingsScreen(controller: controller, strings: s)),
        _navTile(context, Icons.save_alt, s.screenBackup,
            () => BackupRestoreScreen(controller: controller, strings: s)),
        _navTile(context, Icons.fingerprint, s.screenAppLock,
            () => AppLockSettingsScreen(controller: controller, strings: s)),
        _navTile(context, Icons.perm_device_info, s.screenPermissions,
            () => PermissionsSetupScreen(controller: controller, strings: s, onContinue: () => Navigator.pop(context))),
        _navTile(context, Icons.help_outline, s.screenHelp,
            () => HelpSupportScreen(strings: s)),
        _navTile(context, Icons.info_outline, s.screenAbout,
            () => AboutUsScreen(strings: s)),
      ],
    );
  }

  Widget _navTile(BuildContext context, IconData icon, String title, Widget Function() builder) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: ArchonColors.archonBlueGlow),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => builder())),
      ),
    );
  }
}

// Screen 11: Protection Settings
class ProtectionSettingsScreen extends StatelessWidget {
  final FirewallController controller;
  final AppStrings strings;
  const ProtectionSettingsScreen({super.key, required this.controller, required this.strings});

  @override
  Widget build(BuildContext context) {
    final s = strings;
    return Scaffold(
      appBar: AppBar(title: Text(s.isAr ? 'إعدادات الحماية' : 'Protection Settings')),
      body: ListView(
        children: [
          SwitchListTile(
            title: Text(s.isAr ? 'حجر التطبيقات الجديدة تلقائياً' : 'Auto-Quarantine New Apps'),
            value: controller.autoQuarantine,
            onChanged: (v) => controller.updateSetting('autoQuarantine', v),
          ),
          SwitchListTile(
            title: Text(s.isAr ? 'الحظر التلقائي أثناء التجوال الدولي' : 'Block on Roaming'),
            value: controller.blockOnRoaming,
            onChanged: (v) => controller.updateSetting('blockOnRoaming', v),
          ),
          SwitchListTile(
            title: Text(s.isAr ? 'تشغيل الحماية تلقائياً بعد إعادة التشغيل' : 'Auto-Start on Boot'),
            value: controller.autoStartOnBoot,
            onChanged: (v) => controller.updateSetting('autoStartOnBoot', v),
          ),
        ],
      ),
    );
  }
}

// Screen 12: Notification Settings
class NotificationSettingsScreen extends StatelessWidget {
  final FirewallController controller;
  final AppStrings strings;
  const NotificationSettingsScreen({super.key, required this.controller, required this.strings});

  @override
  Widget build(BuildContext context) {
    final s = strings;
    return Scaffold(
      appBar: AppBar(title: Text(s.isAr ? 'إعدادات الإشعارات' : 'Notification Settings')),
      body: ListView(
        children: [
          SwitchListTile(
            title: Text(s.isAr ? 'إشعارات طلبات الاتصال الفورية' : 'Instant Connection Prompts'),
            value: controller.notificationsEnabled,
            onChanged: (v) => controller.updateSetting('notificationsEnabled', v),
          ),
          SwitchListTile(
            title: Text(s.isAr ? 'تمييز محاولات الشاشة المطفأة' : 'Highlight Screen-Off Attempts'),
            value: controller.screenOffAlertEnabled,
            onChanged: (v) => controller.updateSetting('screenOffAlertEnabled', v),
          ),
        ],
      ),
    );
  }
}

// Screen 13: Language & Theme Settings
class LanguageThemeSettingsScreen extends StatelessWidget {
  final FirewallController controller;
  final AppStrings strings;
  const LanguageThemeSettingsScreen({super.key, required this.controller, required this.strings});

  @override
  Widget build(BuildContext context) {
    final s = strings;
    return Scaffold(
      appBar: AppBar(title: Text(s.isAr ? 'اللغة والمظهر' : 'Language & Theme')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Column(
              children: [
                RadioListTile<String>(
                  title: const Text('العربية (RTL)'),
                  value: 'ar',
                  groupValue: controller.language,
                  onChanged: (v) => controller.setLanguage(v ?? 'ar'),
                ),
                RadioListTile<String>(
                  title: const Text('English (LTR)'),
                  value: 'en',
                  groupValue: controller.language,
                  onChanged: (v) => controller.setLanguage(v ?? 'en'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.palette_outlined, color: ArchonColors.archonBlueGlow),
              title: Text(s.isAr ? 'هوية أرشون تك الداكنة' : 'ARCHON TECH Dark Identity'),
              subtitle: const Text('#05070A · #1A6BFF · #10B981 · #F59E0B · #EF4444'),
            ),
          ),
        ],
      ),
    );
  }
}

// Screen 14: Privacy Settings & Domain Blocklist
class PrivacySettingsScreen extends StatefulWidget {
  final FirewallController controller;
  final AppStrings strings;
  const PrivacySettingsScreen({super.key, required this.controller, required this.strings});

  @override
  State<PrivacySettingsScreen> createState() => _PrivacySettingsScreenState();
}

class _PrivacySettingsScreenState extends State<PrivacySettingsScreen> {
  final _domainCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final s = widget.strings;
    return Scaffold(
      appBar: AppBar(title: Text(s.isAr ? 'إعدادات الخصوصية' : 'Privacy Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(s.localPrivacyPledge, style: const TextStyle(height: 1.5)),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _domainCtrl,
                  decoration: InputDecoration(
                    hintText: 'ads.example.com',
                    labelText: s.isAr ? 'حظر نطاق DNS' : 'Block DNS Domain',
                    border: const OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () {
                  final d = _domainCtrl.text.trim();
                  if (d.isNotEmpty) {
                    widget.controller.addBlockedDomain(d);
                    _domainCtrl.clear();
                  }
                },
                child: Text(s.isAr ? 'إضافة' : 'Add'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...widget.controller.blockedDomains.map((d) => Card(
                child: ListTile(
                  title: Text(d),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline, color: ArchonColors.dangerRed),
                    onPressed: () => widget.controller.removeBlockedDomain(d),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}

// Screen 15: Local Backup & Restore
class BackupRestoreScreen extends StatefulWidget {
  final FirewallController controller;
  final AppStrings strings;
  const BackupRestoreScreen({super.key, required this.controller, required this.strings});

  @override
  State<BackupRestoreScreen> createState() => _BackupRestoreScreenState();
}

class _BackupRestoreScreenState extends State<BackupRestoreScreen> {
  final _pwdCtrl = TextEditingController();
  String? _statusMsg;

  @override
  Widget build(BuildContext context) {
    final s = widget.strings;
    return Scaffold(
      appBar: AppBar(title: Text(s.screenBackup)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                s.isAr
                    ? 'نسخ احتياطي محلي 100% عبر منتقي ملفات النظام (SAF). لا يتم استخدام Google Drive أو أي سحابة.'
                    : '100% local backup via Android Storage Access Framework. No cloud or Google Drive.',
                style: const TextStyle(color: ArchonColors.textSecondary, height: 1.5),
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _pwdCtrl,
            obscureText: true,
            decoration: InputDecoration(
              labelText: s.isAr ? 'كلمة مرور التشفير (اختياري AES-256-GCM)' : 'Encryption Password (Optional AES-256-GCM)',
              border: const OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 14),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: ArchonColors.archonBlue),
            onPressed: () async {
              final res = await widget.controller.exportBackup(
                password: _pwdCtrl.text.isEmpty ? null : _pwdCtrl.text,
              );
              setState(() {
                _statusMsg = res['success'] == true
                    ? (s.isAr ? 'تم تصدير النسخة المحلية بنجاح ✓' : 'Local backup exported ✓')
                    : '${s.isAr ? 'تعذر التصدير:' : 'Export failed:'} ${res['errorCode']}';
              });
            },
            icon: const Icon(Icons.upload_file),
            label: Text(s.isAr ? 'تصدير نسخة محلية' : 'Export Local Backup'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () async {
              final res = await widget.controller.importBackup(
                password: _pwdCtrl.text.isEmpty ? null : _pwdCtrl.text,
              );
              setState(() {
                _statusMsg = res['success'] == true
                    ? (s.isAr ? 'تمت الاستعادة بنجاح ✓' : 'Backup restored ✓')
                    : '${s.isAr ? 'تعذرت الاستعادة:' : 'Import failed:'} ${res['errorCode']}';
              });
            },
            icon: const Icon(Icons.download),
            label: Text(s.isAr ? 'استيراد نسخة محلية' : 'Import Local Backup'),
          ),
          if (_statusMsg != null) ...[
            const SizedBox(height: 14),
            Text(_statusMsg!, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ],
      ),
    );
  }
}

// App Lock Settings Screen
class AppLockSettingsScreen extends StatefulWidget {
  final FirewallController controller;
  final AppStrings strings;
  const AppLockSettingsScreen({super.key, required this.controller, required this.strings});

  @override
  State<AppLockSettingsScreen> createState() => _AppLockSettingsScreenState();
}

class _AppLockSettingsScreenState extends State<AppLockSettingsScreen> {
  final _pinCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final s = widget.strings;
    return Scaffold(
      appBar: AppBar(title: Text(s.screenAppLock)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _pinCtrl,
              obscureText: true,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: s.isAr ? 'تعيين رمز PIN (4-8 أرقام)' : 'Set PIN (4-8 digits)',
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => widget.controller.enablePinLock(_pinCtrl.text.trim()),
                child: Text(s.isAr ? 'تفعيل القفل بالبصمة و PIN' : 'Enable Biometric & PIN Lock'),
              ),
            ),
            if (widget.controller.appLockEnabled)
              TextButton(
                onPressed: () => widget.controller.disableAppLock(),
                child: Text(s.isAr ? 'إلغاء قفل التطبيق' : 'Disable App Lock',
                    style: const TextStyle(color: ArchonColors.dangerRed)),
              ),
          ],
        ),
      ),
    );
  }
}

// Screen 17: Help & Support Screen
class HelpSupportScreen extends StatelessWidget {
  final AppStrings strings;
  const HelpSupportScreen({super.key, required this.strings});

  @override
  Widget build(BuildContext context) {
    final s = strings;
    return Scaffold(
      appBar: AppBar(title: Text(s.screenHelp)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset('assets/images/support-bot-archon.jpg',
                    width: 48, height: 48, fit: BoxFit.cover),
              ),
              title: Text(s.isAr ? 'مركز الدعم الفني (@Archon_S_BOT)' : 'Technical Support (@Archon_S_BOT)'),
              subtitle: Text(s.isAr ? 'تواصل مباشر عبر تيليجرام' : 'Official support bot on Telegram'),
              trailing: const Icon(Icons.open_in_new),
              onTap: () => launchUrl(Uri.parse(ArchonLinks.supportBot),
                  mode: LaunchMode.externalApplication),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => launchUrl(Uri.parse(ArchonLinks.faqPage),
                      mode: LaunchMode.externalApplication),
                  child: Text(s.isAr ? 'الأسئلة الشائعة بالموقع' : 'Website FAQ'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton(
                  onPressed: () => launchUrl(Uri.parse(ArchonLinks.contactPage),
                      mode: LaunchMode.externalApplication),
                  child: Text(s.isAr ? 'اتصل بنا' : 'Contact Us'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _faqCard(s.isAr ? 'معنى الرموز الأربعة (✓ / ✓✓ / ✕ / ✕✕)' : 'Symbol Rules Meaning',
              '${s.symAllowSession}\n${s.symAllowPerm}\n${s.symDenyTemp}\n${s.symDenyPerm}'),
          _faqCard(s.isAr ? 'دليل ألوان التصنيف' : 'Severity Colors Guide',
              '🟢 ${s.sevGreenTitle}: ${s.sevGreenMsg}\n🟠 ${s.sevOrangeTitle}: ${s.sevOrangeMsg}\n🔴 ${s.sevRedTitle}: ${s.sevRedMsg}'),
          _faqCard(s.isAr ? 'كيف يعمل VPN المحلي بدون Root؟' : 'How Local VPN Works Without Root',
              s.isAr
                  ? 'ينشئ التطبيق نفق VPN محلياً على الجهاز فقط لحجب التطبيقات غير المصرح بها دون إرسال أي بيانات للإنترنت.'
                  : 'Creates an on-device VPN loop to block unapproved apps without root or external servers.'),
        ],
      ),
    );
  }

  Widget _faqCard(String title, String body) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: ExpansionTile(
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Text(body, style: const TextStyle(color: ArchonColors.textSecondary, height: 1.5)),
            ),
          ],
        ),
      );
}

// Screen 18: About Us Screen
class AboutUsScreen extends StatelessWidget {
  final AppStrings strings;
  const AboutUsScreen({super.key, required this.strings});

  @override
  Widget build(BuildContext context) {
    final s = strings;
    return Scaffold(
      appBar: AppBar(title: Text(s.screenAbout)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Image.asset('assets/images/archon-tech-logo.png', width: 96, height: 96),
                  const SizedBox(height: 12),
                  Text(s.appDual, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text(s.brandDual, style: const TextStyle(color: ArchonColors.archonBlueGlow)),
                  const SizedBox(height: 6),
                  const Text('v1.0.0 · THINK · BUILD · EVOLVE',
                      style: TextStyle(fontSize: 11, color: ArchonColors.textSecondary)),
                  const SizedBox(height: 12),
                  Text(s.officialDesc, textAlign: TextAlign.center),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(s.isAr ? 'عن أرشون تك' : 'About ARCHON TECH',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(s.aboutBio, style: const TextStyle(height: 1.5)),
                  const SizedBox(height: 8),
                  Text(s.aboutVision, style: const TextStyle(color: ArchonColors.textSecondary)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          _linkTile(s.isAr ? 'الموقع الرسمي' : 'Official Website', ArchonLinks.officialWebsite),
          _linkTile(s.isAr ? 'سياسة الخصوصية' : 'Privacy Policy', ArchonLinks.privacyPolicy),
          _linkTile(s.isAr ? 'شروط الاستخدام' : 'Terms of Use', ArchonLinks.termsOfUse),
          _linkTile(s.isAr ? 'الملكية الفكرية' : 'Intellectual Property', ArchonLinks.intellectualProperty),
          _linkTile('Telegram Channel (@ArchonTech)', ArchonLinks.telegramChannel),
          _linkTile('WhatsApp Channel', ArchonLinks.whatsappChannel),
          _linkTile('Facebook (ArchonTech2026)', ArchonLinks.facebookPage),
          _linkTile('Instagram (@archon_tech2026)', ArchonLinks.instagramAccount),
          const SizedBox(height: 16),
          Text(
            '© 2026 ${s.brandDual}',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, color: ArchonColors.textSecondary),
          ),
        ],
      ),
    );
  }

  Widget _linkTile(String title, String url) => Card(
        margin: const EdgeInsets.only(bottom: 6),
        child: ListTile(
          title: Text(title),
          trailing: const Icon(Icons.open_in_new, size: 18),
          onTap: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
        ),
      );
}
