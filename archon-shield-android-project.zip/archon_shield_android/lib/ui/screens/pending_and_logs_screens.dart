import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/archon_theme.dart';
import '../../models/firewall_models.dart';
import '../../state/firewall_controller.dart';
import '../widgets/archon_brand_widgets.dart';
import 'splash_and_lock_screens.dart';

// Screen 6: Pending Requests Queue Screen
class PendingRequestsScreen extends StatelessWidget {
  final FirewallController controller;
  final AppStrings strings;

  const PendingRequestsScreen({
    super.key,
    required this.controller,
    required this.strings,
  });

  @override
  Widget build(BuildContext context) {
    final s = strings;
    final items = controller.pendingRequests;
    if (items.isEmpty) {
      return ArchonStateView(
        icon: Icons.mark_email_read_outlined,
        title: s.isAr ? 'لا توجد طلبات انتظار حالياً' : 'No Pending Requests',
        message: s.isAr
            ? 'عند تشغيل الحماية، أي محاولة اتصال غير مصرح بها ستظهر هنا لاتخاذ القرار.'
            : 'When protection is active, unapproved connection attempts will appear here.',
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(14),
      itemCount: items.length,
      itemBuilder: (ctx, i) {
        final req = items[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.radar, color: ArchonColors.archonBlueGlow, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(req.appName,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    ),
                    Text(
                      _statusText(req.status, s),
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: req.status == 'approved'
                            ? ArchonColors.safeGreen
                            : req.status == 'denied'
                                ? ArchonColors.dangerRed
                                : ArchonColors.warningOrange,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  '${req.network.wire.toUpperCase()} · ${req.protocol} · ${req.domain ?? req.destIp}:${req.destPort} · ×${req.attemptCount}${req.screenOff ? (s.isAr ? ' · الشاشة مطفأة' : ' · Screen Off') : ''}',
                  style: const TextStyle(fontSize: 12, color: ArchonColors.textSecondary),
                ),
                const SizedBox(height: 10),
                if (req.status != 'unidentified_app')
                  RuleSymbolBar(
                    current: RuleAction.none,
                    onSelected: (act) async {
                      await controller.setAppRule(
                        packageName: req.packageName,
                        network: req.network,
                        action: act,
                        isSensitive: req.severity == AppSeverity.sensitiveRed,
                      );
                    },
                    onTimedAllow: () async {
                      final mins = await showTimedAllowDialog(context, s);
                      if (mins != null) {
                        await controller.setAppRule(
                          packageName: req.packageName,
                          network: req.network,
                          action: RuleAction.allowTimed,
                          durationMinutes: mins,
                        );
                      }
                    },
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _statusText(String status, AppStrings s) {
    switch (status) {
      case 'approved':
        return s.isAr ? 'تمت الموافقة' : 'Approved';
      case 'denied':
        return s.isAr ? 'تم الرفض' : 'Denied';
      case 'unidentified_app':
        return s.isAr ? 'تعذر تحديد التطبيق' : 'Unidentified App';
      case 'incomplete_info':
        return s.isAr ? 'معلومات الاتصال غير مكتملة' : 'Incomplete Info';
      default:
        return s.isAr ? 'طلب جديد' : 'New Request';
    }
  }
}

// Screen 7: Global Activity Log Screen
class GlobalActivityLogScreen extends StatefulWidget {
  final FirewallController controller;
  final AppStrings strings;

  const GlobalActivityLogScreen({
    super.key,
    required this.controller,
    required this.strings,
  });

  @override
  State<GlobalActivityLogScreen> createState() => _GlobalActivityLogScreenState();
}

class _GlobalActivityLogScreenState extends State<GlobalActivityLogScreen> {
  String _search = '';
  String _decisionFilter = 'all';

  @override
  Widget build(BuildContext context) {
    final s = widget.strings;
    final list = widget.controller.logs.where((l) {
      if (_decisionFilter != 'all' && l.decision != _decisionFilter) return false;
      if (_search.isNotEmpty) {
        final q = _search.toLowerCase();
        return l.appName.toLowerCase().contains(q) ||
            (l.domain ?? '').toLowerCase().contains(q) ||
            (l.destIp ?? '').toLowerCase().contains(q);
      }
      return true;
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  onChanged: (v) => setState(() => _search = v),
                  decoration: InputDecoration(
                    hintText: s.isAr ? 'بحث في السجل أو النطاق...' : 'Search logs or domain...',
                    prefixIcon: const Icon(Icons.search),
                    isDense: true,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.delete_forever_outlined, color: ArchonColors.dangerRed),
                onPressed: () async {
                  final ok = await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      backgroundColor: ArchonColors.surfaceCard,
                      title: Text(s.isAr ? 'مسح جميع السجلات' : 'Clear All Logs'),
                      content: Text(s.isAr ? 'هل تريد حذف السجل بالكامل؟' : 'Delete all activity logs?'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.isAr ? 'إلغاء' : 'Cancel')),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: ArchonColors.dangerRed),
                          onPressed: () => Navigator.pop(ctx, true),
                          child: Text(s.isAr ? 'مسح' : 'Clear'),
                        ),
                      ],
                    ),
                  );
                  if (ok == true) {
                    await widget.controller.clearLogs();
                  }
                },
              ),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ChoiceChip(
              label: Text(s.isAr ? 'الكل' : 'All'),
              selected: _decisionFilter == 'all',
              onSelected: (_) => setState(() => _decisionFilter = 'all'),
            ),
            const SizedBox(width: 8),
            ChoiceChip(
              label: Text(s.isAr ? 'محجوب' : 'Blocked'),
              selected: _decisionFilter == 'blocked',
              onSelected: (_) => setState(() => _decisionFilter = 'blocked'),
            ),
            const SizedBox(width: 8),
            ChoiceChip(
              label: Text(s.isAr ? 'مسموح' : 'Allowed'),
              selected: _decisionFilter == 'allowed',
              onSelected: (_) => setState(() => _decisionFilter = 'allowed'),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Expanded(
          child: list.isEmpty
              ? ArchonStateView(
                  icon: Icons.history_toggle_off,
                  title: s.isAr ? 'السجل فارغ' : 'No Activity Logs',
                  message: s.isAr ? 'لا توجد أحداث مسجلة بعد.' : 'No recorded network events yet.',
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: list.length,
                  itemBuilder: (ctx, i) {
                    final item = list[i];
                    final allowed = item.decision == 'allowed';
                    return Card(
                      child: ListTile(
                        leading: Icon(
                          allowed ? Icons.check_circle_outline : Icons.block,
                          color: allowed ? ArchonColors.safeGreen : ArchonColors.dangerRed,
                        ),
                        title: Text('${item.appName} → ${item.domain ?? item.destIp ?? "—"}'),
                        subtitle: Text(
                          '${item.network.wire} · ${item.protocol ?? ""}:${item.destPort ?? ""} · ${item.reason} · ${item.ruleSource}',
                          style: const TextStyle(fontSize: 11),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
