import 'dart:convert';
import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/archon_theme.dart';
import '../../models/firewall_models.dart';

class ArchonTopBarLogo extends StatelessWidget {
  final AppStrings strings;
  const ArchonTopBarLogo({super.key, required this.strings});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Image.asset(
          'assets/images/archon-tech-logo.png',
          height: 30,
          fit: BoxFit.contain,
        ),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              strings.appDual,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: ArchonColors.textPrimary,
              ),
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              strings.brandDual,
              style: const TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: ArchonColors.archonBlueGlow,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class ArchonAmbientWatermark extends StatelessWidget {
  final double opacity;
  const ArchonAmbientWatermark({super.key, this.opacity = 0.07});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Center(
        child: Opacity(
          opacity: opacity,
          child: Image.asset(
            'assets/images/archon-tech-logo.png',
            width: 240,
            fit: BoxFit.contain,
          ),
        ),
      ),
    );
  }
}

class AppIconView extends StatelessWidget {
  final String? iconBase64;
  final double size;
  const AppIconView({super.key, this.iconBase64, this.size = 40});

  @override
  Widget build(BuildContext context) {
    if (iconBase64 != null && iconBase64!.isNotEmpty) {
      try {
        final bytes = base64Decode(iconBase64!);
        return ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Image.memory(bytes, width: size, height: size, fit: BoxFit.cover),
        );
      } catch (_) {}
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: ArchonColors.surfaceElevated,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: ArchonColors.borderSubtle),
      ),
      child: const Icon(Icons.android, color: ArchonColors.archonBlueGlow, size: 22),
    );
  }
}

class SeverityIndicator extends StatelessWidget {
  final AppSeverity severity;
  final AppStrings strings;
  const SeverityIndicator({super.key, required this.severity, required this.strings});

  Color get color {
    switch (severity) {
      case AppSeverity.safeGreen:
        return ArchonColors.safeGreen;
      case AppSeverity.mediumOrange:
        return ArchonColors.warningOrange;
      case AppSeverity.sensitiveRed:
        return ArchonColors.dangerRed;
      case AppSeverity.unknown:
        return ArchonColors.unknownSlate;
    }
  }

  String get title {
    switch (severity) {
      case AppSeverity.safeGreen:
        return strings.sevGreenTitle;
      case AppSeverity.mediumOrange:
        return strings.sevOrangeTitle;
      case AppSeverity.sensitiveRed:
        return strings.sevRedTitle;
      case AppSeverity.unknown:
        return strings.sevUnknownTitle;
    }
  }

  IconData get icon {
    switch (severity) {
      case AppSeverity.safeGreen:
        return Icons.verified_user_outlined;
      case AppSeverity.mediumOrange:
        return Icons.info_outline;
      case AppSeverity.sensitiveRed:
        return Icons.warning_amber_rounded;
      case AppSeverity.unknown:
        return Icons.help_outline;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: color),
        const SizedBox(width: 4),
        Text(
          title,
          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: color),
        ),
      ],
    );
  }
}

class RuleSymbolBar extends StatelessWidget {
  final RuleAction current;
  final ValueChanged<RuleAction> onSelected;
  final VoidCallback? onTimedAllow;
  final bool compact;

  const RuleSymbolBar({
    super.key,
    required this.current,
    required this.onSelected,
    this.onTimedAllow,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _symBtn('✓', RuleAction.allowSession, ArchonColors.safeGreen),
        const SizedBox(width: 4),
        _symBtn('✓✓', RuleAction.allowPermanent, ArchonColors.safeGreen),
        const SizedBox(width: 4),
        _symBtn('✕', RuleAction.denySession, ArchonColors.dangerRed),
        const SizedBox(width: 4),
        _symBtn('✕✕', RuleAction.denyPermanent, ArchonColors.dangerRed),
        if (onTimedAllow != null) ...[
          const SizedBox(width: 4),
          InkWell(
            onTap: onTimedAllow,
            borderRadius: BorderRadius.circular(8),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: compact ? 6 : 8, vertical: compact ? 5 : 7),
              decoration: BoxDecoration(
                color: current == RuleAction.allowTimed
                    ? ArchonColors.archonBlue.withValues(alpha: 0.25)
                    : ArchonColors.surfaceElevated,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: current == RuleAction.allowTimed
                      ? ArchonColors.archonBlue
                      : ArchonColors.borderSubtle,
                ),
              ),
              child: const Icon(Icons.timer_outlined, size: 15, color: ArchonColors.archonBlueGlow),
            ),
          ),
        ],
      ],
    );
  }

  Widget _symBtn(String label, RuleAction action, Color activeColor) {
    final selected = current == action;
    return InkWell(
      onTap: () => onSelected(selected ? RuleAction.none : action),
      borderRadius: BorderRadius.circular(8),
      child: Container(
        constraints: BoxConstraints(minWidth: compact ? 28 : 34, minHeight: compact ? 28 : 34),
        alignment: Alignment.center,
        padding: EdgeInsets.symmetric(horizontal: compact ? 6 : 8, vertical: 4),
        decoration: BoxDecoration(
          color: selected ? activeColor.withValues(alpha: 0.22) : ArchonColors.surfaceElevated,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? activeColor : ArchonColors.borderSubtle,
            width: selected ? 1.4 : 1,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: compact ? 11 : 12,
            fontWeight: FontWeight.w800,
            color: selected ? activeColor : ArchonColors.textSecondary,
          ),
        ),
      ),
    );
  }
}

Future<bool> confirmSensitiveBlockIfNeeded(
  BuildContext context,
  InstalledAppItem app,
  RuleAction targetAction,
  AppStrings strings,
) async {
  if (!targetAction.isDeny() || app.severity != AppSeverity.sensitiveRed) {
    return true;
  }
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: ArchonColors.surfaceCard,
      title: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: ArchonColors.dangerRed),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              strings.isAr ? 'تحذير: تطبيق حساس' : 'Warning: Sensitive Component',
              style: const TextStyle(color: ArchonColors.dangerRed, fontSize: 16),
            ),
          ),
        ],
      ),
      content: Text(
        '${app.appName} (${app.packageName})\n\n${strings.sevRedMsg}',
        style: const TextStyle(color: ArchonColors.textPrimary, height: 1.5),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: Text(strings.isAr ? 'إلغاء' : 'Cancel'),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: ArchonColors.dangerRed),
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(strings.isAr ? 'تأكيد الحظر' : 'Confirm Block'),
        ),
      ],
    ),
  );
  return ok == true;
}

Future<int?> showTimedAllowDialog(BuildContext context, AppStrings strings) async {
  return showModalBottomSheet<int>(
    context: context,
    backgroundColor: ArchonColors.surfaceCard,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (ctx) {
      final customCtrl = TextEditingController(text: '10');
      return Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              strings.isAr ? 'سماح مؤقت بمدة زمنية' : 'Timed Allow Duration',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 10,
              children: [5, 15, 30].map((m) {
                return ActionChip(
                  label: Text(strings.isAr ? '$m دقائق' : '$m min'),
                  onPressed: () => Navigator.pop(ctx, m),
                );
              }).toList(),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: customCtrl,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: strings.isAr ? 'مدة مخصصة (بالدقائق)' : 'Custom minutes',
                      border: const OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {
                    final parsed = int.tryParse(customCtrl.text.trim()) ?? 10;
                    Navigator.pop(ctx, parsed.clamp(1, 1440));
                  },
                  child: Text(strings.isAr ? 'تطبيق' : 'Apply'),
                ),
              ],
            ),
          ],
        ),
      );
    },
  );
}
