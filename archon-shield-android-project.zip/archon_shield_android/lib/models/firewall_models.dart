enum RuleAction {
  none('none', '—'),
  allowSession('allow_session', '✓'),
  allowPermanent('allow_permanent', '✓✓'),
  allowTimed('allow_timed', '⏱✓'),
  denySession('deny_session', '✕'),
  denyPermanent('deny_permanent', '✕✕');

  final String wire;
  final String symbol;
  const RuleAction(this.wire, this.symbol);

  bool get isAllow =>
      this == allowSession || this == allowPermanent || this == allowTimed;
  bool get isDeny => this == denySession || this == denyPermanent;

  static RuleAction fromWire(String? v) =>
      RuleAction.values.firstWhere((e) => e.wire == v, orElse: () => none);
}

enum AppSeverity {
  safeGreen('safe_green'),
  mediumOrange('medium_orange'),
  sensitiveRed('sensitive_red'),
  unknown('unknown');

  final String wire;
  const AppSeverity(this.wire);

  static AppSeverity fromWire(String? v) =>
      AppSeverity.values.firstWhere((e) => e.wire == v, orElse: () => unknown);
}

enum NetworkTransport {
  wifi('wifi'),
  mobile('mobile'),
  roaming('roaming'),
  none('none');

  final String wire;
  const NetworkTransport(this.wire);

  static NetworkTransport fromWire(String? v) =>
      NetworkTransport.values.firstWhere((e) => e.wire == v, orElse: () => none);
}

enum VpnEngineState {
  stopped('stopped'),
  starting('starting'),
  active('active'),
  revoked('revoked'),
  conflictOtherVpn('conflict_other_vpn'),
  error('error');

  final String wire;
  const VpnEngineState(this.wire);

  static VpnEngineState fromWire(String? v) =>
      VpnEngineState.values.firstWhere((e) => e.wire == v, orElse: () => stopped);
}

class AppRuleSet {
  final String packageName;
  final RuleAction wifiRule;
  final int wifiExpiresAtMs;
  final RuleAction mobileRule;
  final int mobileExpiresAtMs;
  final bool screenOffBlock;
  final String source;

  const AppRuleSet({
    required this.packageName,
    this.wifiRule = RuleAction.none,
    this.wifiExpiresAtMs = 0,
    this.mobileRule = RuleAction.none,
    this.mobileExpiresAtMs = 0,
    this.screenOffBlock = false,
    this.source = 'manual',
  });

  factory AppRuleSet.fromMap(Map<dynamic, dynamic> map) => AppRuleSet(
        packageName: map['packageName']?.toString() ?? '',
        wifiRule: RuleAction.fromWire(map['wifiRule']?.toString()),
        wifiExpiresAtMs: (map['wifiExpiresAtMs'] as num?)?.toInt() ?? 0,
        mobileRule: RuleAction.fromWire(map['mobileRule']?.toString()),
        mobileExpiresAtMs: (map['mobileExpiresAtMs'] as num?)?.toInt() ?? 0,
        screenOffBlock: map['screenOffBlock'] == true,
        source: map['source']?.toString() ?? 'manual',
      );
}

class InstalledAppItem {
  final String packageName;
  final String appName;
  final int uid;
  final bool isSystemApp;
  final bool isPreinstalledUpdated;
  final bool hasInternetPermission;
  final bool isControllable;
  final String? controlLimitationReason;
  final List<String> sharedUidPackages;
  final int installedAtMs;
  final bool isQuarantined;
  final String? iconBase64;
  final AppSeverity severity;
  final List<String> reasonCodes;
  final bool requiresConfirmationToBlock;
  final AppRuleSet rules;

  const InstalledAppItem({
    required this.packageName,
    required this.appName,
    required this.uid,
    required this.isSystemApp,
    required this.isPreinstalledUpdated,
    required this.hasInternetPermission,
    required this.isControllable,
    this.controlLimitationReason,
    required this.sharedUidPackages,
    required this.installedAtMs,
    required this.isQuarantined,
    this.iconBase64,
    required this.severity,
    required this.reasonCodes,
    required this.requiresConfirmationToBlock,
    required this.rules,
  });

  factory InstalledAppItem.fromMap(Map<dynamic, dynamic> map) {
    final cls = (map['classification'] as Map<dynamic, dynamic>?) ?? {};
    final rulesMap = (map['rules'] as Map<dynamic, dynamic>?) ?? {};
    return InstalledAppItem(
      packageName: map['packageName']?.toString() ?? '',
      appName: map['appName']?.toString() ?? '',
      uid: (map['uid'] as num?)?.toInt() ?? -1,
      isSystemApp: map['isSystemApp'] == true,
      isPreinstalledUpdated: map['isPreinstalledUpdated'] == true,
      hasInternetPermission: map['hasInternetPermission'] == true,
      isControllable: map['isControllable'] != false,
      controlLimitationReason: map['controlLimitationReason']?.toString(),
      sharedUidPackages: ((map['sharedUidPackages'] as List?) ?? [])
          .map((e) => e.toString())
          .toList(),
      installedAtMs: (map['installedAtMs'] as num?)?.toInt() ?? 0,
      isQuarantined: map['isQuarantined'] == true,
      iconBase64: map['iconBase64']?.toString(),
      severity: AppSeverity.fromWire(cls['severity']?.toString()),
      reasonCodes:
          ((cls['reasonCodes'] as List?) ?? []).map((e) => e.toString()).toList(),
      requiresConfirmationToBlock: cls['requiresConfirmationToBlock'] == true,
      rules: AppRuleSet.fromMap(rulesMap),
    );
  }
}

class PendingRequestItem {
  final String id;
  final String packageName;
  final String appName;
  final int uid;
  final NetworkTransport network;
  final String protocol;
  final String destIp;
  final int destPort;
  final String? domain;
  final String status;
  final int attemptCount;
  final int lastSeenMs;
  final bool screenOff;
  final AppSeverity severity;

  const PendingRequestItem({
    required this.id,
    required this.packageName,
    required this.appName,
    required this.uid,
    required this.network,
    required this.protocol,
    required this.destIp,
    required this.destPort,
    this.domain,
    required this.status,
    required this.attemptCount,
    required this.lastSeenMs,
    required this.screenOff,
    required this.severity,
  });

  factory PendingRequestItem.fromMap(Map<dynamic, dynamic> map) =>
      PendingRequestItem(
        id: map['id']?.toString() ?? '',
        packageName: map['packageName']?.toString() ?? '',
        appName: map['appName']?.toString() ?? '',
        uid: (map['uid'] as num?)?.toInt() ?? -1,
        network: NetworkTransport.fromWire(map['network']?.toString()),
        protocol: map['protocol']?.toString() ?? '',
        destIp: map['destIp']?.toString() ?? '',
        destPort: (map['destPort'] as num?)?.toInt() ?? 0,
        domain: map['domain']?.toString(),
        status: map['status']?.toString() ?? 'new',
        attemptCount: (map['attemptCount'] as num?)?.toInt() ?? 1,
        lastSeenMs: (map['lastSeenMs'] as num?)?.toInt() ?? 0,
        screenOff: map['screenOff'] == true,
        severity: AppSeverity.fromWire(map['severity']?.toString()),
      );
}

class ActivityLogItem {
  final int id;
  final int timestampMs;
  final String packageName;
  final String appName;
  final int uid;
  final NetworkTransport network;
  final String decision;
  final String connectionState;
  final String? destIp;
  final int? destPort;
  final String? protocol;
  final String? domain;
  final String reason;
  final String ruleSource;
  final bool screenOff;

  const ActivityLogItem({
    required this.id,
    required this.timestampMs,
    required this.packageName,
    required this.appName,
    required this.uid,
    required this.network,
    required this.decision,
    required this.connectionState,
    this.destIp,
    this.destPort,
    this.protocol,
    this.domain,
    required this.reason,
    required this.ruleSource,
    required this.screenOff,
  });

  factory ActivityLogItem.fromMap(Map<dynamic, dynamic> map) => ActivityLogItem(
        id: (map['id'] as num?)?.toInt() ?? 0,
        timestampMs: (map['timestampMs'] as num?)?.toInt() ?? 0,
        packageName: map['packageName']?.toString() ?? '',
        appName: map['appName']?.toString() ?? '',
        uid: (map['uid'] as num?)?.toInt() ?? -1,
        network: NetworkTransport.fromWire(map['network']?.toString()),
        decision: map['decision']?.toString() ?? 'blocked',
        connectionState: map['connectionState']?.toString() ?? '',
        destIp: map['destIp']?.toString(),
        destPort: (map['destPort'] as num?)?.toInt(),
        protocol: map['protocol']?.toString(),
        domain: map['domain']?.toString(),
        reason: map['reason']?.toString() ?? '',
        ruleSource: map['ruleSource']?.toString() ?? 'rule',
        screenOff: map['screenOff'] == true,
      );
}

class FirewallProfileItem {
  final String id;
  final String nameAr;
  final String nameEn;
  final bool isBuiltIn;
  final RuleAction defaultWifiRule;
  final RuleAction defaultMobileRule;
  final bool blockOnRoaming;
  final bool screenOffAutoBlock;

  const FirewallProfileItem({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.isBuiltIn,
    required this.defaultWifiRule,
    required this.defaultMobileRule,
    required this.blockOnRoaming,
    required this.screenOffAutoBlock,
  });

  factory FirewallProfileItem.fromMap(Map<dynamic, dynamic> map) =>
      FirewallProfileItem(
        id: map['id']?.toString() ?? '',
        nameAr: map['nameAr']?.toString() ?? '',
        nameEn: map['nameEn']?.toString() ?? '',
        isBuiltIn: map['isBuiltIn'] == true,
        defaultWifiRule: RuleAction.fromWire(map['defaultWifiRule']?.toString()),
        defaultMobileRule:
            RuleAction.fromWire(map['defaultMobileRule']?.toString()),
        blockOnRoaming: map['blockOnRoaming'] == true,
        screenOffAutoBlock: map['screenOffAutoBlock'] == true,
      );
}
