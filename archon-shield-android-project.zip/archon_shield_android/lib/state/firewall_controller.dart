import 'dart:async';
import 'package:flutter/foundation.dart';
import '../bridge/firewall_bridge.dart';
import '../models/firewall_models.dart';

class FirewallController extends ChangeNotifier {
  final FirewallBridge _bridge = FirewallBridge();
  StreamSubscription<Map<String, dynamic>>? _eventSub;

  bool isLoading = true;
  String? errorMessage;

  VpnEngineState vpnState = VpnEngineState.stopped;
  NetworkTransport currentNetwork = NetworkTransport.none;
  bool isRoaming = false;
  bool externalVpnDetected = false;
  bool vpnConsentGranted = false;
  bool notificationsGranted = true;
  bool batteryOptimizationIgnored = false;

  String language = 'ar';
  String activeProfileId = 'custom';
  bool autoQuarantine = true;
  bool blockOnRoaming = true;
  bool autoStartOnBoot = false;
  bool notificationsEnabled = true;
  bool screenOffAlertEnabled = true;
  bool appLockEnabled = false;
  bool unlockedInSession = true;
  bool hasPin = false;
  bool biometricAvailable = false;

  List<InstalledAppItem> apps = [];
  List<PendingRequestItem> pendingRequests = [];
  List<ActivityLogItem> logs = [];
  List<FirewallProfileItem> profiles = [];
  List<String> blockedDomains = [];
  Map<String, dynamic> statistics = {};

  Future<void> initialize() async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    try {
      await _loadSettingsAndStatus();
      if (appLockEnabled) {
        unlockedInSession = false;
      }
      await Future.wait([
        refreshApps(),
        refreshPending(),
        refreshLogs(),
        refreshProfiles(),
        refreshStatistics(),
        refreshBlockedDomains(),
      ]);

      _eventSub?.cancel();
      _eventSub = _bridge.eventsStream().listen(_handleNativeEvent);
    } catch (e) {
      errorMessage = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> _loadSettingsAndStatus() async {
    final status = await _bridge.getVpnStatus();
    vpnState = VpnEngineState.fromWire(status['state']?.toString());
    currentNetwork = NetworkTransport.fromWire(status['network']?.toString());
    isRoaming = status['isRoaming'] == true;
    externalVpnDetected = status['externalVpnDetected'] == true;
    vpnConsentGranted = status['vpnConsentGranted'] == true;
    notificationsGranted = status['notificationsGranted'] == true;
    batteryOptimizationIgnored = status['batteryOptimizationIgnored'] == true;

    final settings = await _bridge.getSettings();
    language = settings['language']?.toString() == 'en' ? 'en' : 'ar';
    activeProfileId = settings['activeProfileId']?.toString() ?? 'custom';
    autoQuarantine = settings['autoQuarantine'] != false;
    blockOnRoaming = settings['blockOnRoaming'] != false;
    autoStartOnBoot = settings['autoStartOnBoot'] == true;
    notificationsEnabled = settings['notificationsEnabled'] != false;
    screenOffAlertEnabled = settings['screenOffAlertEnabled'] != false;
    appLockEnabled = settings['appLockEnabled'] == true;
    hasPin = settings['hasPin'] == true;
    biometricAvailable = settings['biometricAvailable'] == true;
  }

  void _handleNativeEvent(Map<String, dynamic> evt) {
    final type = evt['type']?.toString();
    final data = evt['data'];
    if (data is! Map) return;

    switch (type) {
      case 'vpn_state':
        vpnState = VpnEngineState.fromWire(data['state']?.toString());
        currentNetwork = NetworkTransport.fromWire(data['network']?.toString());
        isRoaming = data['isRoaming'] == true;
        externalVpnDetected = data['externalVpnDetected'] == true;
        notifyListeners();
        break;
      case 'pending_request':
        final req = PendingRequestItem.fromMap(data);
        final idx = pendingRequests.indexWhere((p) => p.id == req.id);
        if (idx >= 0) {
          pendingRequests[idx] = req;
        } else {
          pendingRequests.insert(0, req);
        }
        notifyListeners();
        break;
      case 'log_event':
        logs.insert(0, ActivityLogItem.fromMap(data));
        if (logs.length > 500) logs.removeLast();
        notifyListeners();
        break;
      case 'rule_changed':
      case 'apps_changed':
        refreshApps();
        refreshPending();
        break;
    }
  }

  Future<bool> toggleProtection() async {
    if (vpnState == VpnEngineState.active) {
      await _bridge.stopFirewall();
    } else {
      await _bridge.startFirewall();
    }
    await _loadSettingsAndStatus();
    notifyListeners();
    return vpnState == VpnEngineState.active;
  }

  Future<void> refreshApps() async {
    apps = await _bridge.getInstalledApps(includeIcons: true);
    notifyListeners();
  }

  Future<void> refreshPending() async {
    pendingRequests = await _bridge.getPendingRequests();
    notifyListeners();
  }

  Future<void> refreshLogs({String? packageName}) async {
    logs = await _bridge.getActivityLogs(packageName: packageName, limit: 300);
    notifyListeners();
  }

  Future<void> refreshProfiles() async {
    profiles = await _bridge.getProfiles();
    notifyListeners();
  }

  Future<void> refreshStatistics() async {
    statistics = await _bridge.getStatistics();
    notifyListeners();
  }

  Future<void> refreshBlockedDomains() async {
    blockedDomains = await _bridge.getBlockedDomains();
    notifyListeners();
  }

  Future<void> setAppRule({
    required String packageName,
    required NetworkTransport network,
    required RuleAction action,
    int durationMinutes = 0,
    bool isSensitive = false,
  }) async {
    await _bridge.setAppRule(
      packageName: packageName,
      network: network,
      action: action,
      durationMinutes: durationMinutes,
      isSensitive: isSensitive,
    );
    await Future.wait([refreshApps(), refreshPending()]);
  }

  Future<void> setAppScreenOffBlock(String pkg, bool enabled) async {
    await _bridge.setAppScreenOffBlock(pkg, enabled);
    await refreshApps();
  }

  Future<void> clearLogs({String? packageName}) async {
    await _bridge.clearActivityLogs(packageName: packageName);
    await Future.wait([refreshLogs(), refreshStatistics()]);
  }

  Future<void> setLanguage(String code) async {
    language = code == 'en' ? 'en' : 'ar';
    await _bridge.updateSettings({'language': language});
    notifyListeners();
  }

  Future<void> updateSetting(String key, bool value) async {
    await _bridge.updateSettings({key: value});
    await _loadSettingsAndStatus();
    notifyListeners();
  }

  Future<void> setActiveProfile(String profileId) async {
    await _bridge.setActiveProfile(profileId);
    activeProfileId = profileId;
    notifyListeners();
  }

  Future<void> saveCustomProfile(FirewallProfileItem profile) async {
    await _bridge.saveProfile(profile);
    await refreshProfiles();
  }

  Future<void> deleteProfile(String id) async {
    await _bridge.deleteProfile(id);
    await refreshProfiles();
  }

  Future<void> addBlockedDomain(String domain) async {
    await _bridge.addBlockedDomain(domain);
    await refreshBlockedDomains();
  }

  Future<void> removeBlockedDomain(String domain) async {
    await _bridge.removeBlockedDomain(domain);
    await refreshBlockedDomains();
  }

  Future<bool> unlockWithBiometric(String title, String subtitle, String cancel) async {
    final ok = await _bridge.authenticateBiometric(title, subtitle, cancel);
    if (ok) {
      unlockedInSession = true;
      notifyListeners();
    }
    return ok;
  }

  Future<bool> unlockWithPin(String pin) async {
    final ok = await _bridge.verifyAppLockPin(pin);
    if (ok) {
      unlockedInSession = true;
      notifyListeners();
    }
    return ok;
  }

  Future<bool> enablePinLock(String pin) async {
    final ok = await _bridge.setAppLockPin(pin);
    if (ok) {
      await _loadSettingsAndStatus();
      notifyListeners();
    }
    return ok;
  }

  Future<void> disableAppLock() async {
    await _bridge.disableAppLock();
    unlockedInSession = true;
    await _loadSettingsAndStatus();
    notifyListeners();
  }

  Future<bool> requestNotifications() async {
    final granted = await _bridge.requestNotificationPermission();
    notificationsGranted = granted;
    notifyListeners();
    return granted;
  }

  Future<void> openBatterySettings() => _bridge.openBatteryOptimizationSettings();

  Future<Map<String, dynamic>> exportBackup({String? password}) =>
      _bridge.exportBackupViaSaf(password: password);

  Future<Map<String, dynamic>> importBackup({String? password}) async {
    final res = await _bridge.importBackupViaSaf(password: password);
    if (res['success'] == true) {
      await initialize();
    }
    return res;
  }

  @override
  void dispose() {
    _eventSub?.cancel();
    super.dispose();
  }
}
