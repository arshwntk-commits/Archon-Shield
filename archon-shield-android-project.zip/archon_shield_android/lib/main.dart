import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core/localization/app_localizations.dart';
import 'core/theme/archon_theme.dart';
import 'state/firewall_controller.dart';
import 'ui/screens/apps_and_details_screens.dart';
import 'ui/screens/home_and_protection_screens.dart';
import 'ui/screens/pending_and_logs_screens.dart';
import 'ui/screens/settings_help_about_screens.dart';
import 'ui/screens/splash_and_lock_screens.dart';
import 'ui/widgets/archon_brand_widgets.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ArchonShieldApp());
}

class ArchonShieldApp extends StatefulWidget {
  const ArchonShieldApp({super.key});

  @override
  State<ArchonShieldApp> createState() => _ArchonShieldAppState();
}

class _ArchonShieldAppState extends State<ArchonShieldApp> {
  final FirewallController _controller = FirewallController();

  @override
  void initState() {
    super.initState();
    _controller.initialize();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final strings = AppStrings(_controller.language);
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: strings.appDual,
          theme: ArchonTheme.buildDarkTheme(),
          locale: Locale(_controller.language),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          builder: (context, child) => Directionality(
            textDirection: strings.direction,
            child: child ?? const SizedBox.shrink(),
          ),
          home: _buildRoot(strings),
        );
      },
    );
  }

  Widget _buildRoot(AppStrings strings) {
    if (_controller.isLoading) {
      return SplashScreen(strings: strings);
    }
    if (_controller.errorMessage != null) {
      return Scaffold(
        body: ArchonStateView(
          icon: Icons.error_outline,
          accent: ArchonColors.dangerRed,
          title: strings.isAr ? 'تعذر تهيئة التطبيق' : 'Initialization Failed',
          message: _controller.errorMessage!,
          actionLabel: strings.isAr ? 'إعادة المحاولة' : 'Retry',
          onAction: () => _controller.initialize(),
        ),
      );
    }
    if (_controller.appLockEnabled && !_controller.unlockedInSession) {
      return AppLockScreen(controller: _controller, strings: strings);
    }
    return MainShellScreen(controller: _controller, strings: strings);
  }
}

class MainShellScreen extends StatefulWidget {
  final FirewallController controller;
  final AppStrings strings;
  const MainShellScreen({super.key, required this.controller, required this.strings});

  @override
  State<MainShellScreen> createState() => _MainShellScreenState();
}

class _MainShellScreenState extends State<MainShellScreen> {
  int _tabIndex = 0;

  @override
  Widget build(BuildContext context) {
    final s = widget.strings;
    final screens = [
      HomeDashboardScreen(
        controller: widget.controller,
        strings: s,
        onNavigateTab: (idx) => setState(() => _tabIndex = idx),
        onOpenProtectionControl: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ProtectionControlScreen(controller: widget.controller, strings: s),
          ),
        ),
        onOpenStats: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => StatisticsScreen(controller: widget.controller, strings: s),
          ),
        ),
        onOpenProfiles: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ProfilesScreen(controller: widget.controller, strings: s),
          ),
        ),
      ),
      PendingRequestsScreen(controller: widget.controller, strings: s),
      AppsListScreen(controller: widget.controller, strings: s),
      GlobalActivityLogScreen(controller: widget.controller, strings: s),
      MoreHubScreen(controller: widget.controller, strings: s),
    ];

    return Scaffold(
      appBar: AppBar(
        title: ArchonTopBarLogo(strings: s),
        actions: [
          IconButton(
            tooltip: s.isAr ? 'تبديل اللغة' : 'Switch Language',
            icon: const Icon(Icons.translate, size: 20),
            onPressed: () =>
                widget.controller.setLanguage(s.isAr ? 'en' : 'ar'),
          ),
        ],
      ),
      body: IndexedStack(index: _tabIndex, children: screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (i) => setState(() => _tabIndex = i),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.shield_outlined), label: s.navHome),
          NavigationDestination(icon: const Icon(Icons.hourglass_top), label: s.navPending),
          NavigationDestination(icon: const Icon(Icons.apps), label: s.navApps),
          NavigationDestination(icon: const Icon(Icons.receipt_long), label: s.navLogs),
          NavigationDestination(icon: const Icon(Icons.grid_view), label: s.navMore),
        ],
      ),
    );
  }
}
