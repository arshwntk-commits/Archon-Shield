# Keep Kotlin bridge models and Flutter method channels intact in release builds
-keep class com.archontech.shield.** { *; }
-dontwarn javax.crypto.**
