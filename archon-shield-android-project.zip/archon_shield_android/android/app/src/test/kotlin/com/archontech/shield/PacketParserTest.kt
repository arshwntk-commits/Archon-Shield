package com.archontech.shield

import com.archontech.shield.vpn.PacketParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class PacketParserTest {

    @Test
    fun parseIpv4UdpDnsPacketExtractsDomainSafely() {
        // Minimal IPv4 (20B) + UDP (8B) + DNS Question for "example.com"
        val dnsPayload = byteArrayOf(
            0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            7, 'e'.code.toByte(), 'x'.code.toByte(), 'a'.code.toByte(), 'm'.code.toByte(), 'p'.code.toByte(), 'l'.code.toByte(), 'e'.code.toByte(),
            3, 'c'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(),
            0,
            0x00, 0x01, 0x00, 0x01
        )
        val totalLen = 20 + 8 + dnsPayload.size
        val pkt = ByteArray(totalLen)
        // IPv4 header
        pkt[0] = 0x45.toByte()
        pkt[2] = ((totalLen shr 8) and 0xFF).toByte()
        pkt[3] = (totalLen and 0xFF).toByte()
        pkt[9] = PacketParser.PROTO_UDP.toByte()
        // Src IP 10.215.173.1
        pkt[12] = 10; pkt[13] = 215.toByte(); pkt[14] = 173.toByte(); pkt[15] = 1
        // Dst IP 8.8.8.8
        pkt[16] = 8; pkt[17] = 8; pkt[18] = 8; pkt[19] = 8
        // UDP header: srcPort=54321, dstPort=53
        pkt[20] = (54321 shr 8).toByte(); pkt[21] = (54321 and 0xFF).toByte()
        pkt[22] = 0; pkt[23] = 53
        val udpLen = 8 + dnsPayload.size
        pkt[24] = (udpLen shr 8).toByte(); pkt[25] = (udpLen and 0xFF).toByte()
        System.arraycopy(dnsPayload, 0, pkt, 28, dnsPayload.size)

        val parsed = PacketParser.parse(pkt, totalLen)
        assertNotNull(parsed)
        assertEquals(4, parsed!!.ipVersion)
        assertEquals("UDP", parsed.protocolName)
        assertEquals("8.8.8.8", parsed.destIp)
        assertEquals(53, parsed.destPort)
        assertEquals("example.com", parsed.domain)
    }

    @Test
    fun parseTruncatedPacketReturnsNullSafely() {
        val truncated = byteArrayOf(0x45, 0x00, 0x00)
        assertNull(PacketParser.parse(truncated, truncated.size))
    }
}
