package com.archontech.shield

import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import com.archontech.shield.classifier.AppClassifier
import com.archontech.shield.models.AppSeverity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AppClassifierTest {

    @Test
    fun classifiesAppWithoutInternetAsGreenSafe() {
        val pkg = PackageInfo().apply {
            packageName = "com.example.localcalculator"
            requestedPermissions = arrayOf("android.permission.VIBRATE")
            applicationInfo = ApplicationInfo().apply {
                flags = 0
                uid = 10200
            }
        }
        val res = AppClassifier.classify(pkg)
        assertEquals(AppSeverity.SAFE_GREEN, res.severity)
        assertTrue(res.reasonCodes.contains("no_internet_permission_declared"))
    }

    @Test
    fun classifiesCoreOsPackageAsRedSensitiveWithConfirmation() {
        val pkg = PackageInfo().apply {
            packageName = "com.google.android.gms"
            requestedPermissions = arrayOf("android.permission.INTERNET")
            applicationInfo = ApplicationInfo().apply {
                flags = ApplicationInfo.FLAG_SYSTEM
                uid = 10050
            }
        }
        val res = AppClassifier.classify(pkg)
        assertEquals(AppSeverity.SENSITIVE_RED, res.severity)
        assertTrue(res.requiresConfirmationToBlock)
    }

    @Test
    fun classifiesUnknownUserAppWithInternetAsUnknownRatherThanGuessing() {
        val pkg = PackageInfo().apply {
            packageName = "com.vendor.customutility"
            requestedPermissions = arrayOf("android.permission.INTERNET")
            applicationInfo = ApplicationInfo().apply {
                flags = 0
                uid = 10345
            }
        }
        val res = AppClassifier.classify(pkg)
        assertEquals(AppSeverity.UNKNOWN, res.severity)
    }
}
