package com.archontech.shield.classifier

import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.os.Build
import com.archontech.shield.models.AppSeverity
import com.archontech.shield.models.ClassificationResult

/**
 * Evidence-based, extensible application impact classifier.
 *
 * Rules do NOT blindly mark every system app as RED or every user app as GREEN.
 * Instead, classification evaluates permissions, Android app category, UID/package
 * role, and documented OS dependencies. When evidence is insufficient, returns UNKNOWN.
 */
object AppClassifier {

    private val coreOsCriticalPackages = setOf(
        "android",
        "com.android.systemui",
        "com.android.phone",
        "com.android.server.telecom",
        "com.android.providers.telephony",
        "com.android.providers.downloads",
        "com.android.providers.settings",
        "com.android.captiveportallogin",
        "com.android.networkstack",
        "com.android.networkstack.tethering",
        "com.android.ims",
        "com.google.android.gms",
        "com.google.android.gsf",
        "com.android.vending",
        "com.google.android.webview",
        "com.android.webview"
    )

    private val criticalPrefixes = listOf(
        "com.android.internal.",
        "com.qualcomm.qti.telephony",
        "com.samsung.android.ims",
        "com.sec.imsservice"
    )

    private val offlineToolPackages = setOf(
        "com.android.calculator2",
        "com.google.android.calculator",
        "com.android.camera2",
        "com.android.deskclock",
        "com.google.android.deskclock",
        "com.android.soundrecorder",
        "com.android.documentsui",
        "com.google.android.documentsui"
    )

    private val mediumImpactKeywords = listOf(
        "whatsapp", "telegram", "messenger", "instagram", "facebook",
        "twitter", "x.android", "snapchat", "tiktok", "discord",
        "chrome", "firefox", "browser", "opera", "brave", "edge",
        "maps", "waze", "uber", "careem", "gmail", "outlook",
        "youtube", "spotify", "netflix", "drive", "dropbox"
    )

    fun classify(packageInfo: PackageInfo): ClassificationResult {
        val appInfo = packageInfo.applicationInfo
            ?: return ClassificationResult(
                severity = AppSeverity.UNKNOWN,
                reasonCodes = listOf("insufficient_metadata"),
                requiresConfirmationToBlock = false
            )

        val pkg = packageInfo.packageName.lowercase()
        val permissions = packageInfo.requestedPermissions?.toSet() ?: emptySet()
        val hasInternet = permissions.contains("android.permission.INTERNET")
        val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        val uid = appInfo.uid

        // 1. Core system/telephony/push packages -> RED with explicit evidence
        if (coreOsCriticalPackages.contains(pkg) || criticalPrefixes.any { pkg.startsWith(it) }) {
            return ClassificationResult(
                severity = AppSeverity.SENSITIVE_RED,
                reasonCodes = listOf("core_os_or_push_dependency", if (isSystem) "system_component" else "critical_service"),
                requiresConfirmationToBlock = true
            )
        }

        // Core shared Android OS UIDs (system=1000, phone=1001, network=1002..1099)
        if (uid in 1000..1999 && hasInternet) {
            return ClassificationResult(
                severity = AppSeverity.SENSITIVE_RED,
                reasonCodes = listOf("privileged_system_uid", "requires_network_for_os_services"),
                requiresConfirmationToBlock = true
            )
        }

        // 2. Apps that do not declare INTERNET permission at all -> GREEN (safe)
        if (!hasInternet) {
            return ClassificationResult(
                severity = AppSeverity.SAFE_GREEN,
                reasonCodes = listOf("no_internet_permission_declared"),
                requiresConfirmationToBlock = false
            )
        }

        // 3. Known offline-first utilities (even if system-installed like Calculator/Clock) -> GREEN
        if (offlineToolPackages.contains(pkg)) {
            return ClassificationResult(
                severity = AppSeverity.SAFE_GREEN,
                reasonCodes = listOf("offline_utility_category"),
                requiresConfirmationToBlock = false
            )
        }

        // 4. Known communication, browser, maps, or cloud-sync packages -> ORANGE
        if (mediumImpactKeywords.any { pkg.contains(it) }) {
            return ClassificationResult(
                severity = AppSeverity.MEDIUM_ORANGE,
                reasonCodes = listOf("cloud_sync_or_realtime_messaging"),
                requiresConfirmationToBlock = false
            )
        }

        // 5. Android O+ ApplicationInfo.category inspection
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            when (appInfo.category) {
                ApplicationInfo.CATEGORY_SOCIAL,
                ApplicationInfo.CATEGORY_NEWS,
                ApplicationInfo.CATEGORY_MAPS,
                ApplicationInfo.CATEGORY_AUDIO,
                ApplicationInfo.CATEGORY_VIDEO -> {
                    return ClassificationResult(
                        severity = AppSeverity.MEDIUM_ORANGE,
                        reasonCodes = listOf("online_media_or_communication_category"),
                        requiresConfirmationToBlock = false
                    )
                }
                ApplicationInfo.CATEGORY_PRODUCTIVITY,
                ApplicationInfo.CATEGORY_IMAGE -> {
                    return ClassificationResult(
                        severity = AppSeverity.SAFE_GREEN,
                        reasonCodes = listOf("local_first_productivity_or_media_editor"),
                        requiresConfirmationToBlock = false
                    )
                }
                ApplicationInfo.CATEGORY_GAME -> {
                    return ClassificationResult(
                        severity = AppSeverity.MEDIUM_ORANGE,
                        reasonCodes = listOf("game_may_require_online_auth_or_multiplayer"),
                        requiresConfirmationToBlock = false
                    )
                }
            }
        }

        // 6. System app with INTERNET that is not in core critical list -> UNKNOWN or MEDIUM depending on permissions
        if (isSystem) {
            val hasBootOrSync = permissions.contains("android.permission.RECEIVE_BOOT_COMPLETED") ||
                permissions.contains("android.permission.WRITE_SYNC_SETTINGS")
            return if (hasBootOrSync) {
                ClassificationResult(
                    severity = AppSeverity.MEDIUM_ORANGE,
                    reasonCodes = listOf("system_app_with_background_sync"),
                    requiresConfirmationToBlock = false
                )
            } else {
                ClassificationResult(
                    severity = AppSeverity.UNKNOWN,
                    reasonCodes = listOf("insufficient_behavioral_evidence"),
                    requiresConfirmationToBlock = false
                )
            }
        }

        // 7. User app with INTERNET and uncategorized metadata -> UNKNOWN rather than guessing GREEN
        return ClassificationResult(
            severity = AppSeverity.UNKNOWN,
            reasonCodes = listOf("uncategorized_internet_app"),
            requiresConfirmationToBlock = false
        )
    }
}
