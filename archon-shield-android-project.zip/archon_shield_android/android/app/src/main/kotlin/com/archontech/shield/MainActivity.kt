package com.archontech.shield

import android.content.Intent
import com.archontech.shield.bridge.ArchonEventBus
import com.archontech.shield.bridge.ArchonPlatformBridge
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterFragmentActivity() {

    private var bridge: ArchonPlatformBridge? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val platformBridge = ArchonPlatformBridge(this)
        bridge = platformBridge

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            METHOD_CHANNEL
        ).setMethodCallHandler(platformBridge)

        EventChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            EVENT_CHANNEL
        ).setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                ArchonEventBus.attach(events)
            }

            override fun onCancel(arguments: Any?) {
                ArchonEventBus.detach()
            }
        })
    }

    @Deprecated("Handled for VpnService.prepare and Android SAF document pickers")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        bridge?.onActivityResult(requestCode, resultCode, data)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        bridge?.onRequestPermissionsResult(requestCode, grantResults)
    }

    override fun onDestroy() {
        bridge?.dispose()
        super.onDestroy()
    }

    companion object {
        private const val METHOD_CHANNEL = "com.archontech.shield/methods"
        private const val EVENT_CHANNEL = "com.archontech.shield/events"
    }
}
