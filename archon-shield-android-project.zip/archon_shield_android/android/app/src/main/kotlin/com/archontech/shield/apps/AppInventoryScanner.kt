package com.archontech.shield.apps

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Base64
import com.archontech.shield.classifier.AppClassifier
import com.archontech.shield.models.AppRuleSet
import com.archontech.shield.models.InstalledAppRecord
import com.archontech.shield.rules.FirewallRulesStore
import java.io.ByteArrayOutputStream

class AppInventoryScanner(
    private val context: Context,
    private val rulesStore: FirewallRulesStore
) {
    private val pm: PackageManager = context.packageManager
    private val iconCache = HashMap<String, String>()

    fun scanAllApps(includeIcons: Boolean = true): List<InstalledAppRecord> {
        val flags = PackageManager.GET_PERMISSIONS
        val packages: List<PackageInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(flags)
        }

        // Map UIDs to detect sharedUserId groups honestly
        val uidToPackages = HashMap<Int, MutableList<String>>()
        for (pkgInfo in packages) {
            val uid = pkgInfo.applicationInfo?.uid ?: continue
            uidToPackages.getOrPut(uid) { mutableListOf() }.add(pkgInfo.packageName)
        }

        val allRules = rulesStore.getAllRulesMap()
        val quarantinedSet = rulesStore.getQuarantinedPackages()
        val selfPkg = context.packageName
        val results = ArrayList<InstalledAppRecord>(packages.size)

        for (pkgInfo in packages) {
            val appInfo = pkgInfo.applicationInfo ?: continue
            val pkgName = pkgInfo.packageName
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val isUpdatedSystem = (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            val hasInternet = pkgInfo.requestedPermissions
                ?.contains("android.permission.INTERNET") == true

            val uid = appInfo.uid
            val sharedList = uidToPackages[uid]?.filter { it != pkgName } ?: emptyList()

            // Honest controllability check:
            // 1. Self package must remain excluded from blocking to avoid self-lockout
            // 2. Root/kernel UID 0 cannot be safely filtered per-app via VpnService
            val (controllable, limitReason) = when {
                pkgName == selfPkg -> false to "self_firewall_excluded"
                uid <= 0 -> false to "kernel_uid_not_vpn_controllable"
                else -> true to null
            }

            val label = try {
                pm.getApplicationLabel(appInfo).toString().ifBlank { pkgName }
            } catch (_: Exception) {
                pkgName
            }

            val iconB64 = if (includeIcons) getCachedIconBase64(pkgName, appInfo) else null
            val classification = AppClassifier.classify(pkgInfo)
            val rules = allRules[pkgName] ?: AppRuleSet(packageName = pkgName)

            results.add(
                InstalledAppRecord(
                    packageName = pkgName,
                    appName = label,
                    uid = uid,
                    isSystemApp = isSystem,
                    isPreinstalledUpdated = isUpdatedSystem,
                    hasInternetPermission = hasInternet,
                    isControllable = controllable,
                    controlLimitationReason = limitReason,
                    sharedUidPackages = sharedList,
                    installedAtMs = pkgInfo.firstInstallTime,
                    updatedAtMs = pkgInfo.lastUpdateTime,
                    isQuarantined = quarantinedSet.contains(pkgName),
                    iconBase64 = iconB64,
                    classification = classification,
                    rules = rules
                )
            )
        }

        return results.sortedBy { it.appName.lowercase() }
    }

    fun resolveAppName(packageName: String): String {
        return try {
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            pm.getApplicationLabel(info).toString().ifBlank { packageName }
        } catch (_: Exception) {
            packageName
        }
    }

    fun resolvePackagesForUid(uid: Int): List<String> {
        if (uid <= 0) return emptyList()
        return try {
            pm.getPackagesForUid(uid)?.toList() ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun getCachedIconBase64(pkgName: String, appInfo: ApplicationInfo): String? {
        iconCache[pkgName]?.let { return it }
        return try {
            val drawable = pm.getApplicationIcon(appInfo)
            val bitmap = drawableToBitmap(drawable, 72)
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 85, stream)
            val encoded = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
            iconCache[pkgName] = encoded
            encoded
        } catch (_: Exception) {
            null
        }
    }

    private fun drawableToBitmap(drawable: Drawable, sizePx: Int): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return Bitmap.createScaledBitmap(drawable.bitmap, sizePx, sizePx, true)
        }
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }
}
