package com.archontech.shield.models

import org.json.JSONArray
import org.json.JSONObject

enum class RuleAction(val wire: String) {
    NONE("none"),
    ALLOW_SESSION("allow_session"),
    ALLOW_PERMANENT("allow_permanent"),
    ALLOW_TIMED("allow_timed"),
    DENY_SESSION("deny_session"),
    DENY_PERMANENT("deny_permanent");

    fun isAllow(): Boolean = this == ALLOW_SESSION || this == ALLOW_PERMANENT || this == ALLOW_TIMED
    fun isDeny(): Boolean = this == DENY_SESSION || this == DENY_PERMANENT

    companion object {
        fun fromWire(value: String?): RuleAction =
            entries.firstOrNull { it.wire == value } ?: NONE
    }
}

enum class AppSeverity(val wire: String) {
    SAFE_GREEN("safe_green"),
    MEDIUM_ORANGE("medium_orange"),
    SENSITIVE_RED("sensitive_red"),
    UNKNOWN("unknown");

    companion object {
        fun fromWire(value: String?): AppSeverity =
            entries.firstOrNull { it.wire == value } ?: UNKNOWN
    }
}

enum class NetworkTransport(val wire: String) {
    WIFI("wifi"),
    MOBILE("mobile"),
    ROAMING("roaming"),
    NONE("none");

    companion object {
        fun fromWire(value: String?): NetworkTransport =
            entries.firstOrNull { it.wire == value } ?: NONE
    }
}

enum class PendingStatus(val wire: String) {
    NEW("new"),
    APPROVED("approved"),
    DENIED("denied"),
    UNIDENTIFIED_APP("unidentified_app"),
    INCOMPLETE_INFO("incomplete_info");

    companion object {
        fun fromWire(value: String?): PendingStatus =
            entries.firstOrNull { it.wire == value } ?: NEW
    }
}

enum class VpnEngineState(val wire: String) {
    STOPPED("stopped"),
    STARTING("starting"),
    ACTIVE("active"),
    REVOKED("revoked"),
    CONFLICT_OTHER_VPN("conflict_other_vpn"),
    ERROR("error");

    companion object {
        fun fromWire(value: String?): VpnEngineState =
            entries.firstOrNull { it.wire == value } ?: STOPPED
    }
}

data class AppRuleSet(
    val packageName: String,
    val wifiRule: RuleAction = RuleAction.NONE,
    val wifiExpiresAtMs: Long = 0L,
    val mobileRule: RuleAction = RuleAction.NONE,
    val mobileExpiresAtMs: Long = 0L,
    val screenOffBlock: Boolean = false,
    val source: String = "manual",
    val updatedAtMs: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("packageName", packageName)
        put("wifiRule", wifiRule.wire)
        put("wifiExpiresAtMs", wifiExpiresAtMs)
        put("mobileRule", mobileRule.wire)
        put("mobileExpiresAtMs", mobileExpiresAtMs)
        put("screenOffBlock", screenOffBlock)
        put("source", source)
        put("updatedAtMs", updatedAtMs)
    }

    fun toMap(): Map<String, Any?> = mapOf(
        "packageName" to packageName,
        "wifiRule" to wifiRule.wire,
        "wifiExpiresAtMs" to wifiExpiresAtMs,
        "mobileRule" to mobileRule.wire,
        "mobileExpiresAtMs" to mobileExpiresAtMs,
        "screenOffBlock" to screenOffBlock,
        "source" to source,
        "updatedAtMs" to updatedAtMs
    )
}

data class ClassificationResult(
    val severity: AppSeverity,
    val reasonCodes: List<String>,
    val requiresConfirmationToBlock: Boolean
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "severity" to severity.wire,
        "reasonCodes" to reasonCodes,
        "requiresConfirmationToBlock" to requiresConfirmationToBlock
    )
}

data class InstalledAppRecord(
    val packageName: String,
    val appName: String,
    val uid: Int,
    val isSystemApp: Boolean,
    val isPreinstalledUpdated: Boolean,
    val hasInternetPermission: Boolean,
    val isControllable: Boolean,
    val controlLimitationReason: String?,
    val sharedUidPackages: List<String>,
    val installedAtMs: Long,
    val updatedAtMs: Long,
    val isQuarantined: Boolean,
    val iconBase64: String?,
    val classification: ClassificationResult,
    val rules: AppRuleSet
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "packageName" to packageName,
        "appName" to appName,
        "uid" to uid,
        "isSystemApp" to isSystemApp,
        "isPreinstalledUpdated" to isPreinstalledUpdated,
        "hasInternetPermission" to hasInternetPermission,
        "isControllable" to isControllable,
        "controlLimitationReason" to controlLimitationReason,
        "sharedUidPackages" to sharedUidPackages,
        "installedAtMs" to installedAtMs,
        "updatedAtMs" to updatedAtMs,
        "isQuarantined" to isQuarantined,
        "iconBase64" to iconBase64,
        "classification" to classification.toMap(),
        "rules" to rules.toMap()
    )
}

data class PendingRequestRecord(
    val id: String,
    val packageName: String,
    val appName: String,
    val uid: Int,
    val network: NetworkTransport,
    val protocol: String,
    val destIp: String,
    val destPort: Int,
    val domain: String?,
    val status: PendingStatus,
    val attemptCount: Int,
    val firstSeenMs: Long,
    val lastSeenMs: Long,
    val screenOff: Boolean,
    val severity: AppSeverity
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "packageName" to packageName,
        "appName" to appName,
        "uid" to uid,
        "network" to network.wire,
        "protocol" to protocol,
        "destIp" to destIp,
        "destPort" to destPort,
        "domain" to domain,
        "status" to status.wire,
        "attemptCount" to attemptCount,
        "firstSeenMs" to firstSeenMs,
        "lastSeenMs" to lastSeenMs,
        "screenOff" to screenOff,
        "severity" to severity.wire
    )
}

data class ActivityLogRecord(
    val id: Long,
    val timestampMs: Long,
    val packageName: String,
    val appName: String,
    val uid: Int,
    val network: NetworkTransport,
    val decision: String,
    val connectionState: String,
    val destIp: String?,
    val destPort: Int?,
    val protocol: String?,
    val domain: String?,
    val reason: String,
    val ruleSource: String,
    val screenOff: Boolean
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "timestampMs" to timestampMs,
        "packageName" to packageName,
        "appName" to appName,
        "uid" to uid,
        "network" to network.wire,
        "decision" to decision,
        "connectionState" to connectionState,
        "destIp" to destIp,
        "destPort" to destPort,
        "protocol" to protocol,
        "domain" to domain,
        "reason" to reason,
        "ruleSource" to ruleSource,
        "screenOff" to screenOff
    )
}

data class FirewallProfileRecord(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val isBuiltIn: Boolean,
    val defaultWifiRule: RuleAction,
    val defaultMobileRule: RuleAction,
    val blockOnRoaming: Boolean,
    val screenOffAutoBlock: Boolean,
    val rulesOverridesJson: String
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("nameAr", nameAr)
        put("nameEn", nameEn)
        put("isBuiltIn", isBuiltIn)
        put("defaultWifiRule", defaultWifiRule.wire)
        put("defaultMobileRule", defaultMobileRule.wire)
        put("blockOnRoaming", blockOnRoaming)
        put("screenOffAutoBlock", screenOffAutoBlock)
        put("rulesOverridesJson", rulesOverridesJson)
    }

    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "nameAr" to nameAr,
        "nameEn" to nameEn,
        "isBuiltIn" to isBuiltIn,
        "defaultWifiRule" to defaultWifiRule.wire,
        "defaultMobileRule" to defaultMobileRule.wire,
        "blockOnRoaming" to blockOnRoaming,
        "screenOffAutoBlock" to screenOffAutoBlock,
        "rulesOverridesJson" to rulesOverridesJson
    )

    companion object {
        fun fromJson(obj: JSONObject): FirewallProfileRecord = FirewallProfileRecord(
            id = obj.optString("id"),
            nameAr = obj.optString("nameAr"),
            nameEn = obj.optString("nameEn"),
            isBuiltIn = obj.optBoolean("isBuiltIn", false),
            defaultWifiRule = RuleAction.fromWire(obj.optString("defaultWifiRule")),
            defaultMobileRule = RuleAction.fromWire(obj.optString("defaultMobileRule")),
            blockOnRoaming = obj.optBoolean("blockOnRoaming", true),
            screenOffAutoBlock = obj.optBoolean("screenOffAutoBlock", false),
            rulesOverridesJson = obj.optString("rulesOverridesJson", "{}")
        )

        fun listToJsonArray(list: List<FirewallProfileRecord>): JSONArray =
            JSONArray().apply { list.forEach { put(it.toJson()) } }
    }
}
