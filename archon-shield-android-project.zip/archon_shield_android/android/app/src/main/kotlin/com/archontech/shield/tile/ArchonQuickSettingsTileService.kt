package com.archontech.shield.tile

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.archontech.shield.MainActivity
import com.archontech.shield.rules.FirewallRulesStore
import com.archontech.shield.vpn.ArchonFirewallVpnService

class ArchonQuickSettingsTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        syncTileUi()
    }

    override fun onClick() {
        super.onClick()
        if (ArchonFirewallVpnService.isServiceRunning()) {
            ArchonFirewallVpnService.stop(this)
        } else {
            if (VpnService.prepare(this) == null) {
                ArchonFirewallVpnService.startIfPermitted(this)
            } else {
                // VPN consent dialog requires an Activity
                val intent = Intent(this, MainActivity::class.java).apply {
                    putExtra("request_vpn_start", true)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    val pi = android.app.PendingIntent.getActivity(
                        this,
                        400,
                        intent,
                        android.app.PendingIntent.FLAG_IMMUTABLE
                    )
                    startActivityAndCollapse(pi)
                } else {
                    @Suppress("DEPRECATION")
                    startActivityAndCollapse(intent)
                }
            }
        }
        syncTileUi()
    }

    private fun syncTileUi() {
        val tile = qsTile ?: return
        val active = ArchonFirewallVpnService.isServiceRunning()
        val ar = FirewallRulesStore.getInstance(this).getLanguageCode() == "ar"

        tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = if (ar) "درع أرشون" else "ARCHON SHIELD"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = if (active) {
                if (ar) "الحماية نشطة" else "Protected"
            } else {
                if (ar) "متوقف" else "Stopped"
            }
        }
        tile.updateTile()
    }

    companion object {
        fun requestTileRefresh(context: Context) {
            try {
                requestListeningState(
                    context,
                    ComponentName(context, ArchonQuickSettingsTileService::class.java)
                )
            } catch (_: Exception) {
            }
        }
    }
}
