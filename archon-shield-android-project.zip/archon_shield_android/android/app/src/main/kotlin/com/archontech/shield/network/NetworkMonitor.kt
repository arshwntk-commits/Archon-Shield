package com.archontech.shield.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import com.archontech.shield.models.NetworkTransport

class NetworkMonitor(
    context: Context,
    private val onTransportChanged: (NetworkTransport, Boolean) -> Unit
) {
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    @Volatile
    var currentTransport: NetworkTransport = NetworkTransport.NONE
        private set

    @Volatile
    var isRoaming: Boolean = false
        private set

    @Volatile
    var externalVpnDetected: Boolean = false
        private set

    private var registered = false

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            refreshState(notify = true)
        }

        override fun onLost(network: Network) {
            refreshState(notify = true)
        }

        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
            refreshState(notify = true)
        }
    }

    fun start() {
        refreshState(notify = false)
        if (!registered) {
            try {
                connectivityManager.registerDefaultNetworkCallback(callback)
                registered = true
            } catch (_: Exception) {
                registered = false
            }
        }
    }

    fun stop() {
        if (registered) {
            try {
                connectivityManager.unregisterNetworkCallback(callback)
            } catch (_: Exception) {
            }
            registered = false
        }
    }

    fun refreshState(notify: Boolean = false) {
        val activeNetwork = connectivityManager.activeNetwork
        val caps = activeNetwork?.let { connectivityManager.getNetworkCapabilities(it) }

        val newTransport: NetworkTransport
        val newRoaming: Boolean

        if (caps == null) {
            newTransport = NetworkTransport.NONE
            newRoaming = false
        } else {
            val roamingNow = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_ROAMING)
            newRoaming = roamingNow
            newTransport = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkTransport.WIFI
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ->
                    if (roamingNow) NetworkTransport.ROAMING else NetworkTransport.MOBILE
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkTransport.WIFI
                else -> NetworkTransport.NONE
            }
        }

        externalVpnDetected = detectNonArchonVpn()

        val changed = newTransport != currentTransport || newRoaming != isRoaming
        currentTransport = newTransport
        isRoaming = newRoaming

        if (notify && changed) {
            onTransportChanged(newTransport, newRoaming)
        }
    }

    @Suppress("DEPRECATION")
    private fun detectNonArchonVpn(): Boolean {
        return try {
            val networks = connectivityManager.allNetworks
            networks.any { net ->
                val caps = connectivityManager.getNetworkCapabilities(net) ?: return@any false
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
            }
        } catch (_: Exception) {
            false
        }
    }
}
