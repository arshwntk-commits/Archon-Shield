package com.archontech.shield.vpn

import java.net.InetAddress
import java.nio.ByteBuffer

data class ParsedPacket(
    val ipVersion: Int,
    val protocolNumber: Int,
    val protocolName: String,
    val sourceIp: String,
    val destIp: String,
    val sourcePort: Int,
    val destPort: Int,
    val domain: String?
)

/**
 * Pure Kotlin read-only IPv4/IPv6 + TCP/UDP + DNS/SNI packet inspector.
 *
 * Security & Honesty Note:
 * - Performs NO TLS decryption and NO MITM certificate interception.
 * - Extracts domain ONLY when carried in cleartext DNS (UDP/53) or unencrypted TLS ClientHello SNI (TCP/443).
 * - Encrypted DoH, ECH, or non-standard protocols safely yield domain = null ("unavailable").
 */
object PacketParser {

    const val PROTO_ICMP = 1
    const val PROTO_TCP = 6
    const val PROTO_UDP = 17
    const val PROTO_ICMPV6 = 58

    fun parse(raw: ByteArray, length: Int): ParsedPacket? {
        if (length < 20 || length > raw.size) return null
        val version = (raw[0].toInt() ushr 4) and 0x0F
        return when (version) {
            4 -> parseIpv4(raw, length)
            6 -> parseIpv6(raw, length)
            else -> null
        }
    }

    private fun parseIpv4(raw: ByteArray, length: Int): ParsedPacket? {
        val ihl = (raw[0].toInt() and 0x0F) * 4
        if (ihl < 20 || length < ihl) return null

        val proto = raw[9].toInt() and 0xFF
        val srcIp = InetAddress.getByAddress(raw.copyOfRange(12, 16)).hostAddress ?: return null
        val dstIp = InetAddress.getByAddress(raw.copyOfRange(16, 20)).hostAddress ?: return null

        return parseTransport(4, proto, srcIp, dstIp, raw, ihl, length)
    }

    private fun parseIpv6(raw: ByteArray, length: Int): ParsedPacket? {
        if (length < 40) return null
        var nextHeader = raw[6].toInt() and 0xFF
        var offset = 40
        val srcIp = InetAddress.getByAddress(raw.copyOfRange(8, 24)).hostAddress ?: return null
        val dstIp = InetAddress.getByAddress(raw.copyOfRange(24, 40)).hostAddress ?: return null

        // Walk standard IPv6 extension headers with strict bounds and iteration guard
        var hops = 0
        while (hops < 8 && isIpv6ExtensionHeader(nextHeader)) {
            if (offset + 8 > length) return null
            val hdrNext = raw[offset].toInt() and 0xFF
            val hdrLenBytes = ((raw[offset + 1].toInt() and 0xFF) + 1) * 8
            if (hdrLenBytes <= 0 || offset + hdrLenBytes > length) return null
            nextHeader = hdrNext
            offset += hdrLenBytes
            hops++
        }

        return parseTransport(6, nextHeader, srcIp, dstIp, raw, offset, length)
    }

    private fun isIpv6ExtensionHeader(nh: Int): Boolean =
        nh == 0 || nh == 43 || nh == 44 || nh == 60

    private fun parseTransport(
        ipVersion: Int,
        proto: Int,
        srcIp: String,
        dstIp: String,
        raw: ByteArray,
        offset: Int,
        length: Int
    ): ParsedPacket {
        val protoName = when (proto) {
            PROTO_TCP -> "TCP"
            PROTO_UDP -> "UDP"
            PROTO_ICMP -> "ICMP"
            PROTO_ICMPV6 -> "ICMPv6"
            else -> "PROTO_$proto"
        }

        if ((proto != PROTO_TCP && proto != PROTO_UDP) || offset + 4 > length) {
            return ParsedPacket(ipVersion, proto, protoName, srcIp, dstIp, 0, 0, null)
        }

        val srcPort = ((raw[offset].toInt() and 0xFF) shl 8) or (raw[offset + 1].toInt() and 0xFF)
        val dstPort = ((raw[offset + 2].toInt() and 0xFF) shl 8) or (raw[offset + 3].toInt() and 0xFF)

        val domain: String? = when {
            proto == PROTO_UDP && dstPort == 53 && offset + 8 < length ->
                extractDnsQname(raw, offset + 8, length)
            proto == PROTO_TCP && dstPort == 443 && offset + 20 < length -> {
                val dataOffset = ((raw[offset + 12].toInt() ushr 4) and 0x0F) * 4
                val payloadStart = offset + dataOffset
                if (dataOffset >= 20 && payloadStart < length) {
                    extractTlsSni(raw, payloadStart, length)
                } else null
            }
            else -> null
        }

        return ParsedPacket(ipVersion, proto, protoName, srcIp, dstIp, srcPort, dstPort, domain)
    }

    fun extractDnsQname(raw: ByteArray, dnsStart: Int, length: Int): String? {
        if (dnsStart + 12 >= length) return null
        val qdCount = ((raw[dnsStart + 4].toInt() and 0xFF) shl 8) or (raw[dnsStart + 5].toInt() and 0xFF)
        if (qdCount <= 0) return null

        var pos = dnsStart + 12
        val labels = mutableListOf<String>()
        var steps = 0
        while (pos < length && steps < 64) {
            val len = raw[pos].toInt() and 0xFF
            if (len == 0) break
            // Reject DNS compression pointer inside Question QNAME to prevent malformed loops
            if ((len and 0xC0) != 0) break
            pos++
            if (pos + len > length || len > 63) return null
            labels.add(String(raw, pos, len, Charsets.US_ASCII))
            pos += len
            steps++
        }
        val host = labels.joinToString(".").lowercase()
        return if (host.contains('.') && host.length <= 253) host else null
    }

    fun extractTlsSni(raw: ByteArray, start: Int, length: Int): String? {
        // TLS Record: ContentType=22 (Handshake), Version >= 3.x, HandshakeType=1 (ClientHello)
        if (start + 43 > length) return null
        if ((raw[start].toInt() and 0xFF) != 22) return null
        if ((raw[start + 5].toInt() and 0xFF) != 1) return null

        var pos = start + 5 + 4 // skip handshake header
        pos += 2 + 32 // version + random
        if (pos >= length) return null

        val sessionIdLen = raw[pos].toInt() and 0xFF
        pos += 1 + sessionIdLen
        if (pos + 2 > length) return null

        val cipherLen = ((raw[pos].toInt() and 0xFF) shl 8) or (raw[pos + 1].toInt() and 0xFF)
        pos += 2 + cipherLen
        if (pos + 1 > length) return null

        val compLen = raw[pos].toInt() and 0xFF
        pos += 1 + compLen
        if (pos + 2 > length) return null

        val extTotalLen = ((raw[pos].toInt() and 0xFF) shl 8) or (raw[pos + 1].toInt() and 0xFF)
        pos += 2
        val extEnd = (pos + extTotalLen).coerceAtMost(length)

        while (pos + 4 <= extEnd) {
            val extType = ((raw[pos].toInt() and 0xFF) shl 8) or (raw[pos + 1].toInt() and 0xFF)
            val extLen = ((raw[pos + 2].toInt() and 0xFF) shl 8) or (raw[pos + 3].toInt() and 0xFF)
            pos += 4
            if (pos + extLen > extEnd) return null
            if (extType == 0x0000 && extLen >= 5) {
                val nameType = raw[pos + 2].toInt() and 0xFF
                val nameLen = ((raw[pos + 3].toInt() and 0xFF) shl 8) or (raw[pos + 4].toInt() and 0xFF)
                if (nameType == 0 && pos + 5 + nameLen <= pos + extLen) {
                    val sni = String(raw, pos + 5, nameLen, Charsets.US_ASCII).lowercase()
                    return if (sni.contains('.') && sni.length <= 253) sni else null
                }
            }
            pos += extLen
        }
        return null
    }
}
