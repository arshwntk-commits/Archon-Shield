package com.archontech.shield.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.archontech.shield.bridge.ArchonEventBus
import com.archontech.shield.models.NetworkTransport
import com.archontech.shield.models.PendingStatus
import com.archontech.shield.models.RuleAction
import com.archontech.shield.rules.FirewallRulesStore
import com.archontech.shield.vpn.ArchonFirewallVpnService

class NotificationActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == ACTION_STOP_VPN) {
            ArchonFirewallVpnService.stop(context)
            return
        }

        val pkg = intent.getStringExtra(EXTRA_PACKAGE) ?: return
        if (!PACKAGE_REGEX.matches(pkg)) return
        val net = NetworkTransport.fromWire(intent.getStringExtra(EXTRA_NETWORK))
        val notifId = intent.getIntExtra(EXTRA_NOTIF_ID, -1)

        val ruleAction = when (action) {
            ACTION_ALLOW_SESSION -> RuleAction.ALLOW_SESSION
            ACTION_ALLOW_PERMANENT -> RuleAction.ALLOW_PERMANENT
            ACTION_DENY_SESSION -> RuleAction.DENY_SESSION
            else -> return
        }

        val store = FirewallRulesStore.getInstance(context)
        store.setRule(pkg, net, ruleAction, source = "notification")
        store.updatePendingStatus(
            pkg,
            net,
            if (ruleAction.isAllow()) PendingStatus.APPROVED else PendingStatus.DENIED
        )

        if (notifId > 0) {
            FirewallNotificationManager(context).cancelNotification(notifId)
        }

        ArchonFirewallVpnService.requestTunnelReload(context)
        ArchonEventBus.emit(
            "rule_changed",
            mapOf("packageName" to pkg, "network" to net.wire, "action" to ruleAction.wire)
        )
    }

    companion object {
        const val ACTION_ALLOW_SESSION = "com.archontech.shield.NOTIF_ALLOW_SESSION"
        const val ACTION_ALLOW_PERMANENT = "com.archontech.shield.NOTIF_ALLOW_PERMANENT"
        const val ACTION_DENY_SESSION = "com.archontech.shield.NOTIF_DENY_SESSION"
        const val ACTION_STOP_VPN = "com.archontech.shield.NOTIF_STOP_VPN"

        const val EXTRA_PACKAGE = "pkg"
        const val EXTRA_NETWORK = "net"
        const val EXTRA_NOTIF_ID = "notif_id"

        private val PACKAGE_REGEX = Regex("^[a-zA-Z0-9_.]+$")
    }
}
