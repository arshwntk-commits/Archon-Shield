package com.archontech.shield.bridge

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.archontech.shield.apps.AppInventoryScanner
import com.archontech.shield.backup.LocalBackupManager
import com.archontech.shield.models.*
import com.archontech.shield.network.NetworkMonitor
import com.archontech.shield.notifications.FirewallNotificationManager
import com.archontech.shield.rules.FirewallRulesStore
import com.archontech.shield.security.AppSecurityManager
import com.archontech.shield.vpn.ArchonFirewallVpnService
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class ArchonPlatformBridge(
    private val activity: FragmentActivity
) : MethodChannel.MethodCallHandler {

    private val rulesStore = FirewallRulesStore.getInstance(activity)
    private val appScanner = AppInventoryScanner(activity, rulesStore)
    private val securityManager = AppSecurityManager(activity)
    private val backupManager = LocalBackupManager(activity)
    private val notifications = FirewallNotificationManager(activity)
    private val networkMonitor = NetworkMonitor(activity) { _, _ -> }

    private var pendingVpnResult: MethodChannel.Result? = null
    private var pendingBackupResult: MethodChannel.Result? = null
    private var pendingBackupPassword: String? = null
    private var pendingNotificationResult: MethodChannel.Result? = null

    init {
        networkMonitor.start()
    }

    fun dispose() {
        networkMonitor.stop()
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "getVpnStatus" -> {
                networkMonitor.refreshState(notify = false)
                result.success(
                    mapOf(
                        "state" to ArchonFirewallVpnService.currentState().wire,
                        "errorCode" to ArchonFirewallVpnService.currentErrorCode(),
                        "network" to networkMonitor.currentTransport.wire,
                        "isRoaming" to networkMonitor.isRoaming,
                        "externalVpnDetected" to networkMonitor.externalVpnDetected,
                        "vpnConsentGranted" to (VpnService.prepare(activity) == null),
                        "notificationsGranted" to hasNotificationPermission(),
                        "batteryOptimizationIgnored" to isBatteryOptimizationIgnored()
                    )
                )
            }

            "startFirewall" -> {
                val prepareIntent = VpnService.prepare(activity)
                if (prepareIntent != null) {
                    pendingVpnResult = result
                    @Suppress("DEPRECATION")
                    activity.startActivityForResult(prepareIntent, REQ_VPN_CONSENT)
                } else {
                    val started = ArchonFirewallVpnService.startIfPermitted(activity)
                    result.success(started)
                }
            }

            "stopFirewall" -> {
                ArchonFirewallVpnService.stop(activity)
                result.success(true)
            }

            "requestNotificationPermission" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission()) {
                    pendingNotificationResult = result
                    ActivityCompat.requestPermissions(
                        activity,
                        arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                        REQ_POST_NOTIFICATIONS
                    )
                } else {
                    result.success(true)
                }
            }

            "openBatteryOptimizationSettings" -> {
                val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                activity.startActivity(intent)
                result.success(true)
            }

            "getInstalledApps" -> {
                val includeIcons = call.argument<Boolean>("includeIcons") ?: true
                Thread {
                    val apps = appScanner.scanAllApps(includeIcons = includeIcons).map { it.toMap() }
                    activity.runOnUiThread { result.success(apps) }
                }.start()
            }

            "setAppRule" -> {
                val pkg = call.argument<String>("packageName")
                val netWire = call.argument<String>("network")
                val actionWire = call.argument<String>("action")
                val durationMinutes = (call.argument<Number>("durationMinutes")?.toLong() ?: 0L).coerceIn(0L, 1440L)

                if (pkg.isNullOrBlank() || !PACKAGE_REGEX.matches(pkg)) {
                    result.error("INVALID_ARG", "Invalid package name", null)
                    return
                }
                val network = NetworkTransport.fromWire(netWire)
                val action = RuleAction.fromWire(actionWire)
                rulesStore.setRule(pkg, network, action, durationMinutes, source = "manual")
                rulesStore.updatePendingStatus(
                    pkg,
                    network,
                    if (action.isAllow()) PendingStatus.APPROVED else if (action.isDeny()) PendingStatus.DENIED else PendingStatus.NEW
                )

                if (action.isDeny()) {
                    val apps = appScanner.resolveAppName(pkg)
                    if (call.argument<Boolean>("isSensitive") == true) {
                        notifications.notifySensitiveDecisionWarning(apps)
                    }
                }
                ArchonFirewallVpnService.requestTunnelReload(activity)
                result.success(rulesStore.getRuleForPackage(pkg).toMap())
            }

            "setAppScreenOffBlock" -> {
                val pkg = call.argument<String>("packageName")
                val enabled = call.argument<Boolean>("enabled") ?: false
                if (pkg.isNullOrBlank() || !PACKAGE_REGEX.matches(pkg)) {
                    result.error("INVALID_ARG", "Invalid package name", null)
                    return
                }
                rulesStore.setScreenOffBlockForApp(pkg, enabled)
                ArchonFirewallVpnService.requestTunnelReload(activity)
                result.success(true)
            }

            "getPendingRequests" -> {
                result.success(rulesStore.getPendingRequests().map { it.toMap() })
            }

            "getActivityLogs" -> {
                val pkg = call.argument<String>("packageName")
                val limit = call.argument<Int>("limit") ?: 300
                result.success(rulesStore.getLogs(pkg, limit).map { it.toMap() })
            }

            "clearActivityLogs" -> {
                val pkg = call.argument<String>("packageName")
                rulesStore.clearLogs(pkg)
                result.success(true)
            }

            "getStatistics" -> {
                result.success(rulesStore.getStatistics())
            }

            "getProfiles" -> {
                result.success(rulesStore.getProfiles().map { it.toMap() })
            }

            "setActiveProfile" -> {
                val id = call.argument<String>("profileId") ?: "custom"
                rulesStore.setActiveProfileId(id)
                ArchonFirewallVpnService.requestTunnelReload(activity)
                result.success(true)
            }

            "saveProfile" -> {
                val id = call.argument<String>("id") ?: ""
                val nameAr = call.argument<String>("nameAr") ?: ""
                val nameEn = call.argument<String>("nameEn") ?: ""
                if (id.isBlank() || nameAr.isBlank() || nameEn.isBlank()) {
                    result.error("INVALID_ARG", "Profile name/id required", null)
                    return
                }
                val profile = FirewallProfileRecord(
                    id = id,
                    nameAr = nameAr,
                    nameEn = nameEn,
                    isBuiltIn = false,
                    defaultWifiRule = RuleAction.fromWire(call.argument<String>("defaultWifiRule")),
                    defaultMobileRule = RuleAction.fromWire(call.argument<String>("defaultMobileRule")),
                    blockOnRoaming = call.argument<Boolean>("blockOnRoaming") ?: true,
                    screenOffAutoBlock = call.argument<Boolean>("screenOffAutoBlock") ?: false,
                    rulesOverridesJson = "{}"
                )
                rulesStore.saveProfile(profile)
                result.success(true)
            }

            "deleteProfile" -> {
                val id = call.argument<String>("profileId") ?: ""
                result.success(rulesStore.deleteProfile(id))
            }

            "getBlockedDomains" -> result.success(rulesStore.getBlockedDomains())
            "addBlockedDomain" -> {
                rulesStore.addBlockedDomain(call.argument<String>("domain") ?: "")
                result.success(true)
            }
            "removeBlockedDomain" -> {
                rulesStore.removeBlockedDomain(call.argument<String>("domain") ?: "")
                result.success(true)
            }

            "getSettings" -> {
                result.success(
                    mapOf(
                        "language" to rulesStore.getLanguageCode(),
                        "activeProfileId" to rulesStore.getActiveProfileId(),
                        "autoQuarantine" to rulesStore.isAutoQuarantineEnabled(),
                        "blockOnRoaming" to rulesStore.isBlockOnRoamingEnabled(),
                        "autoStartOnBoot" to rulesStore.isAutoStartOnBootEnabled(),
                        "notificationsEnabled" to rulesStore.isNotificationsEnabled(),
                        "screenOffAlertEnabled" to rulesStore.isScreenOffAlertEnabled(),
                        "appLockEnabled" to securityManager.isAppLockEnabled(),
                        "hasPin" to securityManager.hasPinConfigured(),
                        "biometricAvailable" to securityManager.isBiometricAvailable()
                    )
                )
            }

            "updateSettings" -> {
                call.argument<String>("language")?.let { rulesStore.setLanguageCode(it) }
                call.argument<Boolean>("autoQuarantine")?.let { rulesStore.setAutoQuarantineEnabled(it) }
                call.argument<Boolean>("blockOnRoaming")?.let { rulesStore.setBlockOnRoamingEnabled(it) }
                call.argument<Boolean>("autoStartOnBoot")?.let { rulesStore.setAutoStartOnBootEnabled(it) }
                call.argument<Boolean>("notificationsEnabled")?.let { rulesStore.setNotificationsEnabled(it) }
                call.argument<Boolean>("screenOffAlertEnabled")?.let { rulesStore.setScreenOffAlertEnabled(it) }
                ArchonFirewallVpnService.requestTunnelReload(activity)
                result.success(true)
            }

            "setAppLockPin" -> {
                val pin = call.argument<String>("pin") ?: ""
                result.success(securityManager.setPin(pin))
            }
            "verifyAppLockPin" -> {
                val pin = call.argument<String>("pin") ?: ""
                result.success(securityManager.verifyPin(pin))
            }
            "disableAppLock" -> {
                securityManager.clearPinAndLock()
                result.success(true)
            }
            "authenticateBiometric" -> {
                val title = call.argument<String>("title") ?: "ARCHON SHIELD"
                val subtitle = call.argument<String>("subtitle") ?: ""
                val cancel = call.argument<String>("cancel") ?: "Cancel"
                securityManager.authenticateBiometric(activity, title, subtitle, cancel) { ok, err ->
                    result.success(mapOf("success" to ok, "error" to err))
                }
            }

            "exportBackupViaSaf" -> {
                pendingBackupPassword = call.argument<String>("password")
                pendingBackupResult = result
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "archon_shield_backup.json")
                }
                @Suppress("DEPRECATION")
                activity.startActivityForResult(intent, REQ_BACKUP_EXPORT)
            }

            "importBackupViaSaf" -> {
                pendingBackupPassword = call.argument<String>("password")
                pendingBackupResult = result
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                @Suppress("DEPRECATION")
                activity.startActivityForResult(intent, REQ_BACKUP_IMPORT)
            }

            else -> result.notImplemented()
        }
    }

    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            REQ_VPN_CONSENT -> {
                val res = pendingVpnResult
                pendingVpnResult = null
                if (resultCode == Activity.RESULT_OK) {
                    res?.success(ArchonFirewallVpnService.startIfPermitted(activity))
                } else {
                    res?.success(false)
                }
            }
            REQ_BACKUP_EXPORT -> {
                val res = pendingBackupResult
                val pwd = pendingBackupPassword
                pendingBackupResult = null
                pendingBackupPassword = null
                val uri: Uri? = if (resultCode == Activity.RESULT_OK) data?.data else null
                if (uri == null) {
                    res?.success(mapOf("success" to false, "errorCode" to "cancelled"))
                    return
                }
                try {
                    val content = backupManager.createBackupDocument(pwd)
                    activity.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(content.toByteArray(Charsets.UTF_8))
                    }
                    res?.success(mapOf("success" to true))
                } catch (_: Exception) {
                    res?.success(mapOf("success" to false, "errorCode" to "write_failed"))
                }
            }
            REQ_BACKUP_IMPORT -> {
                val res = pendingBackupResult
                val pwd = pendingBackupPassword
                pendingBackupResult = null
                pendingBackupPassword = null
                val uri: Uri? = if (resultCode == Activity.RESULT_OK) data?.data else null
                if (uri == null) {
                    res?.success(mapOf("success" to false, "errorCode" to "cancelled"))
                    return
                }
                try {
                    val raw = activity.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText()
                        ?: ""
                    val outcome = backupManager.restoreBackupDocument(raw, pwd)
                    if (outcome.success) {
                        ArchonFirewallVpnService.requestTunnelReload(activity)
                    }
                    res?.success(outcome.toMap())
                } catch (_: Exception) {
                    res?.success(mapOf("success" to false, "errorCode" to "read_failed"))
                }
            }
        }
    }

    fun onRequestPermissionsResult(requestCode: Int, grantResults: IntArray) {
        if (requestCode == REQ_POST_NOTIFICATIONS) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            pendingNotificationResult?.success(granted)
            pendingNotificationResult = null
        }
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun isBatteryOptimizationIgnored(): Boolean {
        val pm = activity.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(activity.packageName)
    }

    companion object {
        private const val REQ_VPN_CONSENT = 3001
        private const val REQ_BACKUP_EXPORT = 3002
        private const val REQ_BACKUP_IMPORT = 3003
        private const val REQ_POST_NOTIFICATIONS = 3004
        private val PACKAGE_REGEX = Regex("^[a-zA-Z0-9_.]+$")
    }
}
