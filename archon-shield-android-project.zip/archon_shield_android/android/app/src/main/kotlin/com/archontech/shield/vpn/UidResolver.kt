package com.archontech.shield.vpn

import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import android.os.Process
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress

/**
 * Multi-API UID resolver.
 *
 * Honesty contract:
 * - On Android 10+ (API 29+), uses ConnectivityManager.getConnectionOwnerUid for TCP/UDP.
 * - On Android 8-9 (API 26-28), falls back to reading /proc/net/{tcp,tcp6,udp,udp6}.
 * - If resolution fails (e.g., ICMP, kernel socket, or OEM restriction), returns Process.INVALID_UID (-1)
 *   so the UI reports "Unidentified App" rather than guessing an app.
 */
class UidResolver(context: Context) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    fun resolveUid(packet: ParsedPacket): Int {
        if (packet.protocolNumber != PacketParser.PROTO_TCP &&
            packet.protocolNumber != PacketParser.PROTO_UDP
        ) {
            return Process.INVALID_UID
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return try {
                val local = InetSocketAddress(InetAddress.getByName(packet.sourceIp), packet.sourcePort)
                val remote = InetSocketAddress(InetAddress.getByName(packet.destIp), packet.destPort)
                val uid = connectivityManager.getConnectionOwnerUid(packet.protocolNumber, local, remote)
                if (uid > 0) uid else Process.INVALID_UID
            } catch (_: SecurityException) {
                Process.INVALID_UID
            } catch (_: IllegalArgumentException) {
                Process.INVALID_UID
            } catch (_: Exception) {
                Process.INVALID_UID
            }
        }

        // Android 8.0 / 9.0 fallback via /proc/net
        val procPath = when {
            packet.ipVersion == 4 && packet.protocolNumber == PacketParser.PROTO_TCP -> "/proc/net/tcp"
            packet.ipVersion == 6 && packet.protocolNumber == PacketParser.PROTO_TCP -> "/proc/net/tcp6"
            packet.ipVersion == 4 && packet.protocolNumber == PacketParser.PROTO_UDP -> "/proc/net/udp"
            packet.ipVersion == 6 && packet.protocolNumber == PacketParser.PROTO_UDP -> "/proc/net/udp6"
            else -> return Process.INVALID_UID
        }
        return lookupProcNetUid(procPath, packet.sourcePort)
    }

    private fun lookupProcNetUid(path: String, localPort: Int): Int {
        val portHex = localPort.toString(16).uppercase().padStart(4, '0')
        return try {
            File(path).useLines { lines ->
                for (line in lines.drop(1)) {
                    val cols = line.trim().split(Regex("\\s+"))
                    if (cols.size > 7) {
                        val localAddrPort = cols[1]
                        val colon = localAddrPort.indexOf(':')
                        if (colon >= 0 && localAddrPort.substring(colon + 1).equals(portHex, ignoreCase = true)) {
                            val uid = cols[7].toIntOrNull()
                            if (uid != null && uid > 0) return@useLines uid
                        }
                    }
                }
                Process.INVALID_UID
            }
        } catch (_: Exception) {
            Process.INVALID_UID
        }
    }
}
