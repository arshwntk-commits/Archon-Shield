package com.archontech.shield.rules

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class FirewallDatabaseHelper(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {
    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE app_rules (
                package_name TEXT PRIMARY KEY,
                wifi_rule TEXT NOT NULL DEFAULT 'none',
                wifi_expires_at INTEGER NOT NULL DEFAULT 0,
                wifi_prev_rule TEXT NOT NULL DEFAULT 'none',
                mobile_rule TEXT NOT NULL DEFAULT 'none',
                mobile_expires_at INTEGER NOT NULL DEFAULT 0,
                mobile_prev_rule TEXT NOT NULL DEFAULT 'none',
                screen_off_block INTEGER NOT NULL DEFAULT 0,
                source TEXT NOT NULL DEFAULT 'manual',
                updated_at INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE quarantine (
                package_name TEXT PRIMARY KEY,
                quarantined_at INTEGER NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE profiles (
                id TEXT PRIMARY KEY,
                name_ar TEXT NOT NULL,
                name_en TEXT NOT NULL,
                is_built_in INTEGER NOT NULL DEFAULT 0,
                default_wifi_rule TEXT NOT NULL DEFAULT 'none',
                default_mobile_rule TEXT NOT NULL DEFAULT 'none',
                block_on_roaming INTEGER NOT NULL DEFAULT 1,
                screen_off_auto_block INTEGER NOT NULL DEFAULT 0,
                rules_overrides_json TEXT NOT NULL DEFAULT '{}'
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE pending_requests (
                id TEXT PRIMARY KEY,
                package_name TEXT NOT NULL,
                app_name TEXT NOT NULL,
                uid INTEGER NOT NULL,
                network TEXT NOT NULL,
                protocol TEXT NOT NULL,
                dest_ip TEXT NOT NULL,
                dest_port INTEGER NOT NULL,
                domain TEXT,
                status TEXT NOT NULL DEFAULT 'new',
                attempt_count INTEGER NOT NULL DEFAULT 1,
                first_seen_ms INTEGER NOT NULL,
                last_seen_ms INTEGER NOT NULL,
                screen_off INTEGER NOT NULL DEFAULT 0,
                severity TEXT NOT NULL DEFAULT 'unknown'
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_pending_pkg_net ON pending_requests(package_name, network)")

        db.execSQL(
            """
            CREATE TABLE activity_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp_ms INTEGER NOT NULL,
                package_name TEXT NOT NULL,
                app_name TEXT NOT NULL,
                uid INTEGER NOT NULL,
                network TEXT NOT NULL,
                decision TEXT NOT NULL,
                connection_state TEXT NOT NULL,
                dest_ip TEXT,
                dest_port INTEGER,
                protocol TEXT,
                domain TEXT,
                reason TEXT NOT NULL,
                rule_source TEXT NOT NULL,
                screen_off INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_logs_pkg_ts ON activity_logs(package_name, timestamp_ms DESC)")
        db.execSQL("CREATE INDEX idx_logs_ts ON activity_logs(timestamp_ms DESC)")

        db.execSQL(
            """
            CREATE TABLE blocked_domains (
                domain TEXT PRIMARY KEY,
                added_at INTEGER NOT NULL
            )
            """.trimIndent()
        )

        seedBuiltInProfiles(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS blocked_domains (domain TEXT PRIMARY KEY, added_at INTEGER NOT NULL)")
        }
    }

    private fun seedBuiltInProfiles(db: SQLiteDatabase) {
        db.execSQL(
            """
            INSERT OR IGNORE INTO profiles
            (id, name_ar, name_en, is_built_in, default_wifi_rule, default_mobile_rule, block_on_roaming, screen_off_auto_block, rules_overrides_json)
            VALUES
            ('custom', 'الوضع المخصص', 'Custom Mode', 1, 'none', 'none', 1, 0, '{}'),
            ('lockdown', 'وضع الحصن (إغلاق تام)', 'Lockdown Mode', 1, 'deny_session', 'deny_session', 1, 1, '{}'),
            ('data_saver', 'وضع توفير البيانات', 'Data Saver Mode', 1, 'none', 'deny_permanent', 1, 1, '{}')
            """.trimIndent()
        )
    }

    companion object {
        private const val DATABASE_NAME = "archon_shield_local.db"
        private const val DATABASE_VERSION = 2
    }
}
