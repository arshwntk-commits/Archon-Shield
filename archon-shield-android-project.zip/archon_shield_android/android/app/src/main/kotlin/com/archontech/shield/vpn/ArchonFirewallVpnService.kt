package com.archontech.shield.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import android.os.Process
import com.archontech.shield.apps.AppInventoryScanner
import com.archontech.shield.bridge.ArchonEventBus
import com.archontech.shield.classifier.AppClassifier
import com.archontech.shield.models.*
import com.archontech.shield.network.NetworkMonitor
import com.archontech.shield.notifications.FirewallNotificationManager
import com.archontech.shield.rules.FirewallRulesStore
import com.archontech.shield.tile.ArchonQuickSettingsTileService
import java.io.FileInputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Local No-Root Android Firewall VpnService.
 *
 * Security & Leak-Prevention Design:
 * - Captures BOTH IPv4 (0.0.0.0/0) and IPv6 (::/0) inside the TUN interface so blocked/pending
 *   apps have zero IPv6 or DNS leak paths.
 * - Explicitly allowed apps for the active network (Wi-Fi vs Mobile) are excluded via
 *   Builder.addDisallowedApplication(pkg) so they bypass TUN at full native speed.
 * - Blocked, unapproved (default-deny), quarantined, roaming-blocked, and screen-off-blocked
 *   apps remain inside the TUN blackhole: their packets are inspected by PacketParser + UidResolver,
 *   logged locally, pushed to the Pending Queue, and NEVER forwarded out of the device.
 */
class ArchonFirewallVpnService : VpnService() {

    private lateinit var rulesStore: FirewallRulesStore
    private lateinit var appScanner: AppInventoryScanner
    private lateinit var uidResolver: UidResolver
    private lateinit var notifications: FirewallNotificationManager
    private lateinit var networkMonitor: NetworkMonitor

    private var tunFd: ParcelFileDescriptor? = null
    private var readerThread: Thread? = null
    private val running = AtomicBoolean(false)

    @Volatile
    private var isScreenOff = false

    // Notification cooldown per (packageName__network) to avoid flooding the user
    private val lastNotifiedMap = ConcurrentHashMap<String, Long>()

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    isScreenOff = true
                    rebuildTunnel()
                }
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    isScreenOff = false
                    rebuildTunnel()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        rulesStore = FirewallRulesStore.getInstance(this)
        appScanner = AppInventoryScanner(this, rulesStore)
        uidResolver = UidResolver(this)
        notifications = FirewallNotificationManager(this)
        networkMonitor = NetworkMonitor(this) { _, _ ->
            if (running.get()) {
                rebuildTunnel()
                emitEngineState()
            }
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        isScreenOff = !pm.isInteractive

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(screenReceiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopFirewall(byUser = true)
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> {
                if (running.get()) {
                    rebuildTunnel()
                    emitEngineState()
                }
                return START_STICKY
            }
            else -> {
                startFirewall()
                return START_STICKY
            }
        }
    }

    private fun startFirewall() {
        if (prepare(this) != null) {
            setState(VpnEngineState.ERROR, "vpn_consent_missing")
            notifications.notifyVpnError()
            stopSelf()
            return
        }

        setState(VpnEngineState.STARTING)
        networkMonitor.start()

        startForeground(
            FirewallNotificationManager.STATUS_NOTIFICATION_ID,
            notifications.buildOngoingStatusNotification(
                allowedCount = 0,
                blockedCount = 0,
                network = networkMonitor.currentTransport
            )
        )

        if (!establishTunnel()) {
            setState(VpnEngineState.ERROR, "tun_establish_failed")
            notifications.notifyVpnError()
            stopSelf()
            return
        }

        running.set(true)
        rulesStore.setProtectionIntendedActive(true)
        setState(VpnEngineState.ACTIVE)
        ArchonQuickSettingsTileService.requestTileRefresh(this)
        startPacketReader()
    }

    @Synchronized
    private fun rebuildTunnel() {
        if (!running.get()) return
        val previousFd = tunFd
        establishTunnel()
        try {
            previousFd?.close()
        } catch (_: Exception) {
        }
    }

    private fun establishTunnel(): Boolean {
        val builder = Builder()
            .setSession("ARCHON SHIELD Local Firewall")
            .setMtu(1500)
            .addAddress("10.215.173.1", 32)
            .addAddress("fd00:4152:4348::1", 128)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            .setBlocking(true)

        val transport = networkMonitor.currentTransport
        val roaming = networkMonitor.isRoaming

        // Always allow Archon Shield itself so UI/support links remain functional
        try {
            builder.addDisallowedApplication(packageName)
        } catch (_: PackageManager.NameNotFoundException) {
        }

        val allApps = appScanner.scanAllApps(includeIcons = false)
        var allowedCount = 0
        var blockedCount = 0

        for (app in allApps) {
            if (app.packageName == packageName || !app.isControllable) continue
            val (allowed, _) = rulesStore.isPackageAllowedNow(
                packageName = app.packageName,
                transport = transport,
                isRoaming = roaming,
                isScreenOff = isScreenOff
            )
            if (allowed) {
                try {
                    builder.addDisallowedApplication(app.packageName)
                    allowedCount++
                } catch (_: PackageManager.NameNotFoundException) {
                }
            } else {
                blockedCount++
            }
        }

        val newFd = try {
            builder.establish()
        } catch (_: Exception) {
            null
        } ?: return false

        tunFd = newFd
        notifications.updateOngoingStatus(allowedCount, blockedCount, transport)
        return true
    }

    private fun startPacketReader() {
        readerThread?.interrupt()
        readerThread = Thread({
            val buffer = ByteArray(32767)
            while (running.get() && !Thread.currentThread().isInterrupted) {
                val fd = tunFd ?: break
                try {
                    val input = FileInputStream(fd.fileDescriptor)
                    while (running.get() && tunFd == fd && !Thread.currentThread().isInterrupted) {
                        val len = input.read(buffer)
                        if (len > 0) {
                            rulesStore.addTunBytesRead(len.toLong())
                            handleCapturedPacket(buffer, len)
                        } else if (len < 0) {
                            break
                        }
                    }
                } catch (_: InterruptedException) {
                    break
                } catch (_: Exception) {
                    if (running.get()) {
                        Thread.sleep(150)
                    }
                }
            }
        }, "ArchonTunReader").apply {
            isDaemon = true
            start()
        }
    }

    private fun handleCapturedPacket(raw: ByteArray, length: Int) {
        val packet = PacketParser.parse(raw, length) ?: return
        val uid = uidResolver.resolveUid(packet)
        val transport = networkMonitor.currentTransport

        val packages = if (uid > 0) appScanner.resolvePackagesForUid(uid) else emptyList()
        if (packages.isEmpty()) {
            // Honest handling: do NOT invent an app name when UID cannot be resolved
            val pending = rulesStore.upsertPendingRequest(
                packageName = "uid.$uid",
                appName = if (uid == Process.INVALID_UID) "Unidentified App" else "UID $uid",
                uid = uid,
                network = transport,
                protocol = packet.protocolName,
                destIp = packet.destIp,
                destPort = packet.destPort,
                domain = packet.domain,
                status = PendingStatus.UNIDENTIFIED_APP,
                screenOff = isScreenOff,
                severity = AppSeverity.UNKNOWN
            )
            val log = rulesStore.appendLog(
                packageName = pending.packageName,
                appName = pending.appName,
                uid = uid,
                network = transport,
                decision = "blocked",
                connectionState = "unidentified_app",
                destIp = packet.destIp,
                destPort = packet.destPort,
                protocol = packet.protocolName,
                domain = packet.domain,
                reason = "cannot_resolve_uid",
                ruleSource = "engine",
                screenOff = isScreenOff
            )
            emitPacketEvents(pending, log)
            return
        }

        val pkgName = packages.first()
        val appName = appScanner.resolveAppName(pkgName)
        val (_, blockReason) = rulesStore.isPackageAllowedNow(
            packageName = pkgName,
            transport = transport,
            isRoaming = networkMonitor.isRoaming,
            isScreenOff = isScreenOff
        )

        val pkgInfo = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.getPackageInfo(
                    pkgName,
                    PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(pkgName, PackageManager.GET_PERMISSIONS)
            }
        } catch (_: Exception) {
            null
        }
        val severity = pkgInfo?.let { AppClassifier.classify(it).severity } ?: AppSeverity.UNKNOWN

        val isPendingStatus = if (packet.destIp.isBlank()) {
            PendingStatus.INCOMPLETE_INFO
        } else {
            PendingStatus.NEW
        }

        val pending = rulesStore.upsertPendingRequest(
            packageName = pkgName,
            appName = appName,
            uid = uid,
            network = transport,
            protocol = packet.protocolName,
            destIp = packet.destIp,
            destPort = packet.destPort,
            domain = packet.domain,
            status = isPendingStatus,
            screenOff = isScreenOff,
            severity = severity
        )

        val log = rulesStore.appendLog(
            packageName = pkgName,
            appName = appName,
            uid = uid,
            network = transport,
            decision = "blocked",
            connectionState = if (isScreenOff) "blocked_screen_off" else "blocked_tun_drop",
            destIp = packet.destIp,
            destPort = packet.destPort,
            protocol = packet.protocolName,
            domain = packet.domain,
            reason = blockReason,
            ruleSource = if (blockReason.startsWith("profile_")) "profile" else "rule",
            screenOff = isScreenOff
        )

        // Rate-limit interactive notifications per (package + network) every 15s
        val rule = rulesStore.getRuleForPackage(pkgName)
        val effectiveRule = if (transport == NetworkTransport.WIFI) rule.wifiRule else rule.mobileRule
        if (effectiveRule != RuleAction.DENY_PERMANENT && rulesStore.isNotificationsEnabled()) {
            val cooldownKey = "${pkgName}__${transport.wire}"
            val now = System.currentTimeMillis()
            val prev = lastNotifiedMap[cooldownKey] ?: 0L
            if (now - prev >= 15_000L) {
                lastNotifiedMap[cooldownKey] = now
                notifications.notifyPendingConnection(
                    packageName = pkgName,
                    appName = appName,
                    network = transport,
                    domainOrIp = packet.domain ?: packet.destIp,
                    isScreenOff = isScreenOff
                )
            }
        }

        emitPacketEvents(pending, log)
    }

    private fun emitPacketEvents(pending: PendingRequestRecord, log: ActivityLogRecord) {
        ArchonEventBus.emit("pending_request", pending.toMap())
        ArchonEventBus.emit("log_event", log.toMap())
    }

    override fun onRevoke() {
        notifications.notifyServiceStopped(revokedBySystem = true)
        stopFirewall(byUser = false, revoked = true)
        super.onRevoke()
    }

    private fun stopFirewall(byUser: Boolean, revoked: Boolean = false) {
        running.set(false)
        readerThread?.interrupt()
        readerThread = null
        try {
            tunFd?.close()
        } catch (_: Exception) {
        }
        tunFd = null
        networkMonitor.stop()

        // Session rules expire immediately when protection is stopped
        rulesStore.clearSessionRules()
        rulesStore.setProtectionIntendedActive(false)

        if (!byUser && !revoked) {
            notifications.notifyServiceStopped(revokedBySystem = false)
        }
        setState(if (revoked) VpnEngineState.REVOKED else VpnEngineState.STOPPED)
        ArchonQuickSettingsTileService.requestTileRefresh(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {
        }
        if (running.get()) {
            stopFirewall(byUser = false)
        }
        super.onDestroy()
    }

    private fun setState(state: VpnEngineState, errorCode: String? = null) {
        engineState.set(state)
        lastErrorCode.set(errorCode)
        emitEngineState()
    }

    private fun emitEngineState() {
        ArchonEventBus.emit(
            "vpn_state",
            mapOf(
                "state" to engineState.get().wire,
                "errorCode" to lastErrorCode.get(),
                "network" to networkMonitor.currentTransport.wire,
                "isRoaming" to networkMonitor.isRoaming,
                "externalVpnDetected" to networkMonitor.externalVpnDetected,
                "isScreenOff" to isScreenOff
            )
        )
    }

    companion object {
        const val ACTION_START = "com.archontech.shield.ACTION_START"
        const val ACTION_STOP = "com.archontech.shield.ACTION_STOP"
        const val ACTION_RELOAD = "com.archontech.shield.ACTION_RELOAD"

        private val engineState = AtomicReference(VpnEngineState.STOPPED)
        private val lastErrorCode = AtomicReference<String?>(null)

        fun isServiceRunning(): Boolean = engineState.get() == VpnEngineState.ACTIVE
        fun currentState(): VpnEngineState = engineState.get()
        fun currentErrorCode(): String? = lastErrorCode.get()

        fun startIfPermitted(context: Context): Boolean {
            if (prepare(context) != null) return false
            val intent = Intent(context, ArchonFirewallVpnService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            return true
        }

        fun stop(context: Context) {
            val intent = Intent(context, ArchonFirewallVpnService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun requestTunnelReload(context: Context) {
            if (!isServiceRunning()) return
            val intent = Intent(context, ArchonFirewallVpnService::class.java).apply {
                action = ACTION_RELOAD
            }
            context.startService(intent)
        }
    }
}
