package com.archontech.shield.backup

import android.content.Context
import android.util.Base64
import com.archontech.shield.models.FirewallProfileRecord
import com.archontech.shield.models.NetworkTransport
import com.archontech.shield.models.RuleAction
import com.archontech.shield.rules.FirewallRulesStore
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * 100% Local Backup & Restore Manager (Zero cloud, zero external servers).
 *
 * - Exports ONLY rules, profiles, blocked domains, and non-sensitive settings.
 * - Never exports PIN hashes, encryption keys, or activity logs/device identifiers.
 * - Includes SHA-256 integrity verification and optional PBKDF2 + AES-256-GCM password encryption.
 */
class LocalBackupManager(private val context: Context) {

    private val rulesStore = FirewallRulesStore.getInstance(context)

    fun createBackupDocument(password: String?): String {
        val payload = JSONObject().apply {
            put("app", "ARCHON_SHIELD")
            put("schemaVersion", CURRENT_SCHEMA_VERSION)
            put("createdAtMs", System.currentTimeMillis())

            val rulesArr = JSONArray()
            rulesStore.getAllRulesMap().values.forEach { rulesArr.put(it.toJson()) }
            put("rules", rulesArr)

            val profilesArr = FirewallProfileRecord.listToJsonArray(
                rulesStore.getProfiles().filter { !it.isBuiltIn }
            )
            put("customProfiles", profilesArr)

            val domainsArr = JSONArray()
            rulesStore.getBlockedDomains().forEach { domainsArr.put(it) }
            put("blockedDomains", domainsArr)

            put("settings", rulesStore.exportAllSettingsJson())
        }

        val canonicalBody = payload.toString()
        val digestHex = sha256Hex(canonicalBody)

        val envelope = JSONObject().apply {
            put("format", "archon_shield_local_backup")
            put("schemaVersion", CURRENT_SCHEMA_VERSION)
            put("sha256", digestHex)
            if (password.isNullOrEmpty()) {
                put("encrypted", false)
                put("payload", payload)
            } else {
                val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
                val key = deriveAesKey(password, salt)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
                val ciphertext = cipher.doFinal(canonicalBody.toByteArray(Charsets.UTF_8))

                put("encrypted", true)
                put("kdf", "PBKDF2WithHmacSHA256")
                put("iterations", KDF_ITERATIONS)
                put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                put("iv", Base64.encodeToString(iv, Base64.NO_WRAP))
                put("ciphertext", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            }
        }
        return envelope.toString(2)
    }

    fun restoreBackupDocument(rawContent: String, password: String?): BackupRestoreResult {
        if (rawContent.length > MAX_BACKUP_BYTES) {
            return BackupRestoreResult(false, "backup_too_large")
        }
        val envelope = try {
            JSONObject(rawContent)
        } catch (_: Exception) {
            return BackupRestoreResult(false, "invalid_json_format")
        }

        if (envelope.optString("format") != "archon_shield_local_backup") {
            return BackupRestoreResult(false, "unsupported_backup_format")
        }

        val schemaVersion = envelope.optInt("schemaVersion", -1)
        if (schemaVersion !in 1..CURRENT_SCHEMA_VERSION) {
            return BackupRestoreResult(false, "unsupported_schema_version")
        }

        val expectedSha = envelope.optString("sha256", "")
        val encrypted = envelope.optBoolean("encrypted", false)

        val payloadObj: JSONObject = if (!encrypted) {
            val obj = envelope.optJSONObject("payload")
                ?: return BackupRestoreResult(false, "missing_payload")
            if (expectedSha.isNotEmpty() && sha256Hex(obj.toString()) != expectedSha) {
                return BackupRestoreResult(false, "checksum_mismatch")
            }
            obj
        } else {
            if (password.isNullOrEmpty()) {
                return BackupRestoreResult(false, "password_required")
            }
            val decrypted = try {
                val salt = Base64.decode(envelope.getString("salt"), Base64.NO_WRAP)
                val iv = Base64.decode(envelope.getString("iv"), Base64.NO_WRAP)
                val ciphertext = Base64.decode(envelope.getString("ciphertext"), Base64.NO_WRAP)
                val key = deriveAesKey(password, salt)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                String(cipher.doFinal(ciphertext), Charsets.UTF_8)
            } catch (_: Exception) {
                return BackupRestoreResult(false, "decryption_failed_wrong_password_or_corrupt")
            }

            if (expectedSha.isNotEmpty() && sha256Hex(decrypted) != expectedSha) {
                return BackupRestoreResult(false, "checksum_mismatch")
            }
            try {
                JSONObject(decrypted)
            } catch (_: Exception) {
                return BackupRestoreResult(false, "corrupt_decrypted_payload")
            }
        }

        // Validate & apply rules safely (sanitizing package names & enum values)
        var restoredRules = 0
        val rulesArr = payloadObj.optJSONArray("rules") ?: JSONArray()
        for (i in 0 until rulesArr.length()) {
            val item = rulesArr.optJSONObject(i) ?: continue
            val pkg = item.optString("packageName", "")
            if (!PACKAGE_REGEX.matches(pkg)) continue

            val wifiRule = RuleAction.fromWire(item.optString("wifiRule"))
            val mobileRule = RuleAction.fromWire(item.optString("mobileRule"))
            val screenOff = item.optBoolean("screenOffBlock", false)

            // Never import ephemeral session rules as permanent
            val safeWifi = if (wifiRule == RuleAction.ALLOW_PERMANENT || wifiRule == RuleAction.DENY_PERMANENT) wifiRule else RuleAction.NONE
            val safeMobile = if (mobileRule == RuleAction.ALLOW_PERMANENT || mobileRule == RuleAction.DENY_PERMANENT) mobileRule else RuleAction.NONE

            rulesStore.setRule(pkg, NetworkTransport.WIFI, safeWifi, source = "backup_restore")
            rulesStore.setRule(pkg, NetworkTransport.MOBILE, safeMobile, source = "backup_restore")
            rulesStore.setScreenOffBlockForApp(pkg, screenOff)
            restoredRules++
        }

        var restoredProfiles = 0
        val profilesArr = payloadObj.optJSONArray("customProfiles") ?: JSONArray()
        for (i in 0 until profilesArr.length()) {
            val pObj = profilesArr.optJSONObject(i) ?: continue
            val profile = FirewallProfileRecord.fromJson(pObj)
            if (profile.id.isNotBlank() && !profile.isBuiltIn && ID_REGEX.matches(profile.id)) {
                rulesStore.saveProfile(profile.copy(isBuiltIn = false))
                restoredProfiles++
            }
        }

        val domainsArr = payloadObj.optJSONArray("blockedDomains") ?: JSONArray()
        for (i in 0 until domainsArr.length()) {
            val domain = domainsArr.optString(i, "").trim().lowercase()
            if (DOMAIN_REGEX.matches(domain)) {
                rulesStore.addBlockedDomain(domain)
            }
        }

        payloadObj.optJSONObject("settings")?.let { settingsObj ->
            rulesStore.importSettingsJson(settingsObj)
        }

        return BackupRestoreResult(
            success = true,
            errorCode = null,
            restoredRulesCount = restoredRules,
            restoredProfilesCount = restoredProfiles
        )
    }

    private fun deriveAesKey(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, KDF_ITERATIONS, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }

    private fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    data class BackupRestoreResult(
        val success: Boolean,
        val errorCode: String?,
        val restoredRulesCount: Int = 0,
        val restoredProfilesCount: Int = 0
    ) {
        fun toMap(): Map<String, Any?> = mapOf(
            "success" to success,
            "errorCode" to errorCode,
            "restoredRulesCount" to restoredRulesCount,
            "restoredProfilesCount" to restoredProfilesCount
        )
    }

    companion object {
        const val CURRENT_SCHEMA_VERSION = 1
        private const val KDF_ITERATIONS = 100_000
        private const val MAX_BACKUP_BYTES = 5 * 1024 * 1024
        private val PACKAGE_REGEX = Regex("^[a-zA-Z0-9_.]{1,200}$")
        private val ID_REGEX = Regex("^[a-zA-Z0-9_-]{1,64}$")
        private val DOMAIN_REGEX = Regex("^[a-z0-9.-]{3,253}$")
    }
}
