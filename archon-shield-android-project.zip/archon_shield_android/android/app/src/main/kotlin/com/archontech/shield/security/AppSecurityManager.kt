package com.archontech.shield.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Handles local App Lock (Biometric + salted PBKDF2WithHmacSHA256 PIN).
 * Stores credentials strictly inside Android Keystore-backed EncryptedSharedPreferences.
 */
class AppSecurityManager(private val context: Context) {

    private val securePrefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context.applicationContext,
            "archon_shield_secure_vault",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun isAppLockEnabled(): Boolean = securePrefs.getBoolean(KEY_LOCK_ENABLED, false)

    fun setAppLockEnabled(enabled: Boolean) {
        securePrefs.edit().putBoolean(KEY_LOCK_ENABLED, enabled).apply()
    }

    fun isBiometricAvailable(): Boolean {
        val manager = BiometricManager.from(context)
        val res = manager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.BIOMETRIC_WEAK
        )
        return res == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun hasPinConfigured(): Boolean =
        !securePrefs.getString(KEY_PIN_HASH, null).isNullOrEmpty()

    fun setPin(pin: String): Boolean {
        if (!PIN_REGEX.matches(pin)) return false
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derivePinHash(pin, salt)
        securePrefs.edit()
            .putString(KEY_PIN_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_PIN_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .putBoolean(KEY_LOCK_ENABLED, true)
            .apply()
        return true
    }

    fun verifyPin(pin: String): Boolean {
        if (!PIN_REGEX.matches(pin)) return false
        val saltB64 = securePrefs.getString(KEY_PIN_SALT, null) ?: return false
        val hashB64 = securePrefs.getString(KEY_PIN_HASH, null) ?: return false
        val salt = Base64.decode(saltB64, Base64.NO_WRAP)
        val expected = Base64.decode(hashB64, Base64.NO_WRAP)
        val actual = derivePinHash(pin, salt)
        return MessageDigest.isEqual(expected, actual)
    }

    fun clearPinAndLock() {
        securePrefs.edit()
            .remove(KEY_PIN_SALT)
            .remove(KEY_PIN_HASH)
            .putBoolean(KEY_LOCK_ENABLED, false)
            .apply()
    }

    fun authenticateBiometric(
        activity: FragmentActivity,
        title: String,
        subtitle: String,
        negativeText: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        if (!isBiometricAvailable()) {
            onResult(false, "biometric_unavailable")
            return
        }
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onResult(true, null)
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onResult(false, "biometric_error_$errorCode")
                }

                override fun onAuthenticationFailed() {
                    // User can retry inside system prompt
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setNegativeButtonText(negativeText)
            .build()
        prompt.authenticate(info)
    }

    private fun derivePinHash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(spec)
            .encoded
    }

    companion object {
        private const val KEY_LOCK_ENABLED = "app_lock_enabled"
        private const val KEY_PIN_SALT = "pin_salt"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val PBKDF2_ITERATIONS = 120_000
        private val PIN_REGEX = Regex("^\\d{4,8}$")
    }
}
