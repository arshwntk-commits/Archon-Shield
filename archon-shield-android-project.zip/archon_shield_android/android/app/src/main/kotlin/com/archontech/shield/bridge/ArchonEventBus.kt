package com.archontech.shield.bridge

import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.EventChannel

object ArchonEventBus {
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile
    private var sink: EventChannel.EventSink? = null

    fun attach(eventSink: EventChannel.EventSink?) {
        sink = eventSink
    }

    fun detach() {
        sink = null
    }

    fun emit(type: String, payload: Map<String, Any?>) {
        val currentSink = sink ?: return
        val event = mapOf("type" to type, "data" to payload)
        if (Looper.myLooper() == Looper.getMainLooper()) {
            currentSink.success(event)
        } else {
            mainHandler.post { sink?.success(event) }
        }
    }
}
