package com.archontech.shield.rules

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import com.archontech.shield.models.*
import org.json.JSONObject

class FirewallRulesStore private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val dbHelper = FirewallDatabaseHelper(appContext)
    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun getRuleForPackage(packageName: String): AppRuleSet {
        val db = dbHelper.readableDatabase
        db.rawQuery(
            "SELECT * FROM app_rules WHERE package_name = ?",
            arrayOf(packageName)
        ).use { cursor ->
            if (!cursor.moveToFirst()) {
                return AppRuleSet(packageName = packageName)
            }
            val now = System.currentTimeMillis()
            var wifiRule = RuleAction.fromWire(cursor.getString(cursor.getColumnIndexOrThrow("wifi_rule")))
            var wifiExp = cursor.getLong(cursor.getColumnIndexOrThrow("wifi_expires_at"))
            val wifiPrev = RuleAction.fromWire(cursor.getString(cursor.getColumnIndexOrThrow("wifi_prev_rule")))
            if (wifiRule == RuleAction.ALLOW_TIMED && wifiExp in 1..now) {
                wifiRule = wifiPrev
                wifiExp = 0L
                setRule(packageName, NetworkTransport.WIFI, wifiRule, 0L, "timed_revert")
            }

            var mobileRule = RuleAction.fromWire(cursor.getString(cursor.getColumnIndexOrThrow("mobile_rule")))
            var mobileExp = cursor.getLong(cursor.getColumnIndexOrThrow("mobile_expires_at"))
            val mobilePrev = RuleAction.fromWire(cursor.getString(cursor.getColumnIndexOrThrow("mobile_prev_rule")))
            if (mobileRule == RuleAction.ALLOW_TIMED && mobileExp in 1..now) {
                mobileRule = mobilePrev
                mobileExp = 0L
                setRule(packageName, NetworkTransport.MOBILE, mobileRule, 0L, "timed_revert")
            }

            return AppRuleSet(
                packageName = packageName,
                wifiRule = wifiRule,
                wifiExpiresAtMs = wifiExp,
                mobileRule = mobileRule,
                mobileExpiresAtMs = mobileExp,
                screenOffBlock = cursor.getInt(cursor.getColumnIndexOrThrow("screen_off_block")) == 1,
                source = cursor.getString(cursor.getColumnIndexOrThrow("source")),
                updatedAtMs = cursor.getLong(cursor.getColumnIndexOrThrow("updated_at"))
            )
        }
    }

    @Synchronized
    fun getAllRulesMap(): Map<String, AppRuleSet> {
        val map = HashMap<String, AppRuleSet>()
        val now = System.currentTimeMillis()
        val expiredReverts = mutableListOf<Triple<String, NetworkTransport, RuleAction>>()
        val db = dbHelper.readableDatabase
        db.rawQuery("SELECT * FROM app_rules", null).use { cursor ->
            while (cursor.moveToNext()) {
                val pkg = cursor.getString(cursor.getColumnIndexOrThrow("package_name"))
                var wifiRule = RuleAction.fromWire(cursor.getString(cursor.getColumnIndexOrThrow("wifi_rule")))
                var wifiExp = cursor.getLong(cursor.getColumnIndexOrThrow("wifi_expires_at"))
                val wifiPrev = RuleAction.fromWire(cursor.getString(cursor.getColumnIndexOrThrow("wifi_prev_rule")))
                if (wifiRule == RuleAction.ALLOW_TIMED && wifiExp in 1..now) {
                    wifiRule = wifiPrev
                    wifiExp = 0L
                    expiredReverts.add(Triple(pkg, NetworkTransport.WIFI, wifiPrev))
                }

                var mobileRule = RuleAction.fromWire(cursor.getString(cursor.getColumnIndexOrThrow("mobile_rule")))
                var mobileExp = cursor.getLong(cursor.getColumnIndexOrThrow("mobile_expires_at"))
                val mobilePrev = RuleAction.fromWire(cursor.getString(cursor.getColumnIndexOrThrow("mobile_prev_rule")))
                if (mobileRule == RuleAction.ALLOW_TIMED && mobileExp in 1..now) {
                    mobileRule = mobilePrev
                    mobileExp = 0L
                    expiredReverts.add(Triple(pkg, NetworkTransport.MOBILE, mobilePrev))
                }

                map[pkg] = AppRuleSet(
                    packageName = pkg,
                    wifiRule = wifiRule,
                    wifiExpiresAtMs = wifiExp,
                    mobileRule = mobileRule,
                    mobileExpiresAtMs = mobileExp,
                    screenOffBlock = cursor.getInt(cursor.getColumnIndexOrThrow("screen_off_block")) == 1,
                    source = cursor.getString(cursor.getColumnIndexOrThrow("source")),
                    updatedAtMs = cursor.getLong(cursor.getColumnIndexOrThrow("updated_at"))
                )
            }
        }
        expiredReverts.forEach { (pkg, net, prev) -> setRule(pkg, net, prev, 0L, "timed_revert") }
        return map
    }

    @Synchronized
    fun setRule(
        packageName: String,
        network: NetworkTransport,
        action: RuleAction,
        durationMinutes: Long = 0L,
        source: String = "manual"
    ) {
        val current = getRuleForPackage(packageName)
        val db = dbHelper.writableDatabase
        val now = System.currentTimeMillis()
        val expiresAt = if (action == RuleAction.ALLOW_TIMED && durationMinutes > 0L) {
            now + durationMinutes * 60_000L
        } else {
            0L
        }

        val values = ContentValues().apply {
            put("package_name", packageName)
            put("source", source)
            put("updated_at", now)
            put("screen_off_block", if (current.screenOffBlock) 1 else 0)
            if (network == NetworkTransport.WIFI) {
                put("wifi_rule", action.wire)
                put("wifi_expires_at", expiresAt)
                if (action == RuleAction.ALLOW_TIMED && current.wifiRule != RuleAction.ALLOW_TIMED) {
                    put("wifi_prev_rule", current.wifiRule.wire)
                } else if (action != RuleAction.ALLOW_TIMED) {
                    put("wifi_prev_rule", action.wire)
                }
                put("mobile_rule", current.mobileRule.wire)
                put("mobile_expires_at", current.mobileExpiresAtMs)
            } else {
                put("wifi_rule", current.wifiRule.wire)
                put("wifi_expires_at", current.wifiExpiresAtMs)
                put("mobile_rule", action.wire)
                put("mobile_expires_at", expiresAt)
                if (action == RuleAction.ALLOW_TIMED && current.mobileRule != RuleAction.ALLOW_TIMED) {
                    put("mobile_prev_rule", current.mobileRule.wire)
                } else if (action != RuleAction.ALLOW_TIMED) {
                    put("mobile_prev_rule", action.wire)
                }
            }
        }

        db.insertWithOnConflict("app_rules", null, values, SQLiteDatabase.CONFLICT_REPLACE)

        if (action != RuleAction.NONE) {
            setQuarantined(packageName, false)
        }
    }

    @Synchronized
    fun setScreenOffBlockForApp(packageName: String, enabled: Boolean) {
        val current = getRuleForPackage(packageName)
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("package_name", packageName)
            put("wifi_rule", current.wifiRule.wire)
            put("wifi_expires_at", current.wifiExpiresAtMs)
            put("mobile_rule", current.mobileRule.wire)
            put("mobile_expires_at", current.mobileExpiresAtMs)
            put("screen_off_block", if (enabled) 1 else 0)
            put("source", current.source)
            put("updated_at", System.currentTimeMillis())
        }
        db.insertWithOnConflict("app_rules", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    @Synchronized
    fun clearSessionRules() {
        val db = dbHelper.writableDatabase
        db.execSQL(
            "UPDATE app_rules SET wifi_rule = 'none', wifi_expires_at = 0 WHERE wifi_rule IN ('allow_session', 'deny_session', 'allow_timed')"
        )
        db.execSQL(
            "UPDATE app_rules SET mobile_rule = 'none', mobile_expires_at = 0 WHERE mobile_rule IN ('allow_session', 'deny_session', 'allow_timed')"
        )
    }

    @Synchronized
    fun deleteRulesForPackage(packageName: String) {
        dbHelper.writableDatabase.delete("app_rules", "package_name = ?", arrayOf(packageName))
    }

    @Synchronized
    fun setQuarantined(packageName: String, quarantined: Boolean) {
        val db = dbHelper.writableDatabase
        if (quarantined) {
            val cv = ContentValues().apply {
                put("package_name", packageName)
                put("quarantined_at", System.currentTimeMillis())
            }
            db.insertWithOnConflict("quarantine", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        } else {
            db.delete("quarantine", "package_name = ?", arrayOf(packageName))
        }
    }

    @Synchronized
    fun getQuarantinedPackages(): Set<String> {
        val set = HashSet<String>()
        dbHelper.readableDatabase.rawQuery("SELECT package_name FROM quarantine", null).use { c ->
            while (c.moveToNext()) set.add(c.getString(0))
        }
        return set
    }

    @Synchronized
    fun isPackageAllowedNow(
        packageName: String,
        transport: NetworkTransport,
        isRoaming: Boolean,
        isScreenOff: Boolean
    ): Pair<Boolean, String> {
        val activeProfile = getActiveProfile()

        // 1. Lockdown profile blocks everything except user explicit permanent overrides?
        // Actually Lockdown blocks ALL non-system-critical traffic cleanly.
        if (activeProfile.id == "lockdown") {
            return false to "profile_lockdown"
        }

        // 2. Quarantined newly installed apps are blocked until explicit decision
        if (getQuarantinedPackages().contains(packageName)) {
            return false to "auto_quarantine"
        }

        // 3. Roaming hard-block when enabled globally or by profile
        if ((isRoaming || transport == NetworkTransport.ROAMING) &&
            (isBlockOnRoamingEnabled() || activeProfile.blockOnRoaming)
        ) {
            return false to "block_on_roaming"
        }

        val rule = getRuleForPackage(packageName)

        // 4. Screen-off auto-block per app or global profile
        if (isScreenOff && (rule.screenOffBlock || activeProfile.screenOffAutoBlock)) {
            return false to "screen_off_auto_block"
        }

        val effectiveAction = when (transport) {
            NetworkTransport.WIFI -> rule.wifiRule
            NetworkTransport.MOBILE, NetworkTransport.ROAMING -> rule.mobileRule
            NetworkTransport.NONE -> RuleAction.NONE
        }

        val finalAction = if (effectiveAction == RuleAction.NONE) {
            when (transport) {
                NetworkTransport.WIFI -> activeProfile.defaultWifiRule
                NetworkTransport.MOBILE, NetworkTransport.ROAMING -> activeProfile.defaultMobileRule
                NetworkTransport.NONE -> RuleAction.NONE
            }
        } else {
            effectiveAction
        }

        return when (finalAction) {
            RuleAction.ALLOW_SESSION -> true to "rule_allow_session"
            RuleAction.ALLOW_PERMANENT -> true to "rule_allow_permanent"
            RuleAction.ALLOW_TIMED -> true to "rule_allow_timed"
            RuleAction.DENY_SESSION -> false to "rule_deny_session"
            RuleAction.DENY_PERMANENT -> false to "rule_deny_permanent"
            RuleAction.NONE -> false to "default_deny_unapproved"
        }
    }

    @Synchronized
    fun upsertPendingRequest(
        packageName: String,
        appName: String,
        uid: Int,
        network: NetworkTransport,
        protocol: String,
        destIp: String,
        destPort: Int,
        domain: String?,
        status: PendingStatus,
        screenOff: Boolean,
        severity: AppSeverity
    ): PendingRequestRecord {
        val id = "${packageName}__${network.wire}"
        val now = System.currentTimeMillis()
        val db = dbHelper.writableDatabase
        var existingCount = 0
        var firstSeen = now

        db.rawQuery(
            "SELECT attempt_count, first_seen_ms FROM pending_requests WHERE id = ?",
            arrayOf(id)
        ).use { c ->
            if (c.moveToFirst()) {
                existingCount = c.getInt(0)
                firstSeen = c.getLong(1)
            }
        }

        val newCount = existingCount + 1
        val cv = ContentValues().apply {
            put("id", id)
            put("package_name", packageName)
            put("app_name", appName)
            put("uid", uid)
            put("network", network.wire)
            put("protocol", protocol)
            put("dest_ip", destIp)
            put("dest_port", destPort)
            put("domain", domain)
            put("status", status.wire)
            put("attempt_count", newCount)
            put("first_seen_ms", firstSeen)
            put("last_seen_ms", now)
            put("screen_off", if (screenOff) 1 else 0)
            put("severity", severity.wire)
        }
        db.insertWithOnConflict("pending_requests", null, cv, SQLiteDatabase.CONFLICT_REPLACE)

        return PendingRequestRecord(
            id = id,
            packageName = packageName,
            appName = appName,
            uid = uid,
            network = network,
            protocol = protocol,
            destIp = destIp,
            destPort = destPort,
            domain = domain,
            status = status,
            attemptCount = newCount,
            firstSeenMs = firstSeen,
            lastSeenMs = now,
            screenOff = screenOff,
            severity = severity
        )
    }

    @Synchronized
    fun updatePendingStatus(packageName: String, network: NetworkTransport, status: PendingStatus) {
        val db = dbHelper.writableDatabase
        val cv = ContentValues().apply { put("status", status.wire) }
        db.update(
            "pending_requests",
            cv,
            "package_name = ? AND network = ?",
            arrayOf(packageName, network.wire)
        )
    }

    @Synchronized
    fun getPendingRequests(): List<PendingRequestRecord> {
        val list = ArrayList<PendingRequestRecord>()
        dbHelper.readableDatabase.rawQuery(
            "SELECT * FROM pending_requests ORDER BY last_seen_ms DESC LIMIT 200",
            null
        ).use { c ->
            while (c.moveToNext()) {
                list.add(
                    PendingRequestRecord(
                        id = c.getString(c.getColumnIndexOrThrow("id")),
                        packageName = c.getString(c.getColumnIndexOrThrow("package_name")),
                        appName = c.getString(c.getColumnIndexOrThrow("app_name")),
                        uid = c.getInt(c.getColumnIndexOrThrow("uid")),
                        network = NetworkTransport.fromWire(c.getString(c.getColumnIndexOrThrow("network"))),
                        protocol = c.getString(c.getColumnIndexOrThrow("protocol")),
                        destIp = c.getString(c.getColumnIndexOrThrow("dest_ip")),
                        destPort = c.getInt(c.getColumnIndexOrThrow("dest_port")),
                        domain = c.getString(c.getColumnIndexOrThrow("domain")),
                        status = PendingStatus.fromWire(c.getString(c.getColumnIndexOrThrow("status"))),
                        attemptCount = c.getInt(c.getColumnIndexOrThrow("attempt_count")),
                        firstSeenMs = c.getLong(c.getColumnIndexOrThrow("first_seen_ms")),
                        lastSeenMs = c.getLong(c.getColumnIndexOrThrow("last_seen_ms")),
                        screenOff = c.getInt(c.getColumnIndexOrThrow("screen_off")) == 1,
                        severity = AppSeverity.fromWire(c.getString(c.getColumnIndexOrThrow("severity")))
                    )
                )
            }
        }
        return list
    }

    @Synchronized
    fun appendLog(
        packageName: String,
        appName: String,
        uid: Int,
        network: NetworkTransport,
        decision: String,
        connectionState: String,
        destIp: String?,
        destPort: Int?,
        protocol: String?,
        domain: String?,
        reason: String,
        ruleSource: String,
        screenOff: Boolean
    ): ActivityLogRecord {
        val db = dbHelper.writableDatabase
        val now = System.currentTimeMillis()
        val cv = ContentValues().apply {
            put("timestamp_ms", now)
            put("package_name", packageName)
            put("app_name", appName)
            put("uid", uid)
            put("network", network.wire)
            put("decision", decision)
            put("connection_state", connectionState)
            put("dest_ip", destIp)
            put("dest_port", destPort)
            put("protocol", protocol)
            put("domain", domain)
            put("reason", reason)
            put("rule_source", ruleSource)
            put("screen_off", if (screenOff) 1 else 0)
        }
        val id = db.insert("activity_logs", null, cv)

        // Efficient local retention cap: keep newest 5,000 log entries
        db.execSQL(
            "DELETE FROM activity_logs WHERE id NOT IN (SELECT id FROM activity_logs ORDER BY id DESC LIMIT 5000)"
        )

        return ActivityLogRecord(
            id = id,
            timestampMs = now,
            packageName = packageName,
            appName = appName,
            uid = uid,
            network = network,
            decision = decision,
            connectionState = connectionState,
            destIp = destIp,
            destPort = destPort,
            protocol = protocol,
            domain = domain,
            reason = reason,
            ruleSource = ruleSource,
            screenOff = screenOff
        )
    }

    @Synchronized
    fun getLogs(packageName: String? = null, limit: Int = 300): List<ActivityLogRecord> {
        val list = ArrayList<ActivityLogRecord>()
        val safeLimit = limit.coerceIn(1, 1000)
        val query = if (packageName.isNullOrBlank()) {
            "SELECT * FROM activity_logs ORDER BY timestamp_ms DESC LIMIT $safeLimit"
        } else {
            "SELECT * FROM activity_logs WHERE package_name = ? ORDER BY timestamp_ms DESC LIMIT $safeLimit"
        }
        val args = if (packageName.isNullOrBlank()) null else arrayOf(packageName)

        dbHelper.readableDatabase.rawQuery(query, args).use { c ->
            while (c.moveToNext()) {
                val portIdx = c.getColumnIndexOrThrow("dest_port")
                list.add(
                    ActivityLogRecord(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        timestampMs = c.getLong(c.getColumnIndexOrThrow("timestamp_ms")),
                        packageName = c.getString(c.getColumnIndexOrThrow("package_name")),
                        appName = c.getString(c.getColumnIndexOrThrow("app_name")),
                        uid = c.getInt(c.getColumnIndexOrThrow("uid")),
                        network = NetworkTransport.fromWire(c.getString(c.getColumnIndexOrThrow("network"))),
                        decision = c.getString(c.getColumnIndexOrThrow("decision")),
                        connectionState = c.getString(c.getColumnIndexOrThrow("connection_state")),
                        destIp = c.getString(c.getColumnIndexOrThrow("dest_ip")),
                        destPort = if (c.isNull(portIdx)) null else c.getInt(portIdx),
                        protocol = c.getString(c.getColumnIndexOrThrow("protocol")),
                        domain = c.getString(c.getColumnIndexOrThrow("domain")),
                        reason = c.getString(c.getColumnIndexOrThrow("reason")),
                        ruleSource = c.getString(c.getColumnIndexOrThrow("rule_source")),
                        screenOff = c.getInt(c.getColumnIndexOrThrow("screen_off")) == 1
                    )
                )
            }
        }
        return list
    }

    @Synchronized
    fun clearLogs(packageName: String? = null) {
        val db = dbHelper.writableDatabase
        if (packageName.isNullOrBlank()) {
            db.delete("activity_logs", null, null)
        } else {
            db.delete("activity_logs", "package_name = ?", arrayOf(packageName))
        }
    }

    @Synchronized
    fun getProfiles(): List<FirewallProfileRecord> {
        val list = ArrayList<FirewallProfileRecord>()
        dbHelper.readableDatabase.rawQuery("SELECT * FROM profiles ORDER BY is_built_in DESC, name_en ASC", null).use { c ->
            while (c.moveToNext()) {
                list.add(
                    FirewallProfileRecord(
                        id = c.getString(c.getColumnIndexOrThrow("id")),
                        nameAr = c.getString(c.getColumnIndexOrThrow("name_ar")),
                        nameEn = c.getString(c.getColumnIndexOrThrow("name_en")),
                        isBuiltIn = c.getInt(c.getColumnIndexOrThrow("is_built_in")) == 1,
                        defaultWifiRule = RuleAction.fromWire(c.getString(c.getColumnIndexOrThrow("default_wifi_rule"))),
                        defaultMobileRule = RuleAction.fromWire(c.getString(c.getColumnIndexOrThrow("default_mobile_rule"))),
                        blockOnRoaming = c.getInt(c.getColumnIndexOrThrow("block_on_roaming")) == 1,
                        screenOffAutoBlock = c.getInt(c.getColumnIndexOrThrow("screen_off_auto_block")) == 1,
                        rulesOverridesJson = c.getString(c.getColumnIndexOrThrow("rules_overrides_json"))
                    )
                )
            }
        }
        return list
    }

    @Synchronized
    fun saveProfile(profile: FirewallProfileRecord) {
        val cv = ContentValues().apply {
            put("id", profile.id)
            put("name_ar", profile.nameAr)
            put("name_en", profile.nameEn)
            put("is_built_in", if (profile.isBuiltIn) 1 else 0)
            put("default_wifi_rule", profile.defaultWifiRule.wire)
            put("default_mobile_rule", profile.defaultMobileRule.wire)
            put("block_on_roaming", if (profile.blockOnRoaming) 1 else 0)
            put("screen_off_auto_block", if (profile.screenOffAutoBlock) 1 else 0)
            put("rules_overrides_json", profile.rulesOverridesJson)
        }
        dbHelper.writableDatabase.insertWithOnConflict("profiles", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    @Synchronized
    fun deleteProfile(profileId: String): Boolean {
        val existing = getProfiles().firstOrNull { it.id == profileId } ?: return false
        if (existing.isBuiltIn) return false
        dbHelper.writableDatabase.delete("profiles", "id = ?", arrayOf(profileId))
        if (getActiveProfileId() == profileId) {
            setActiveProfileId("custom")
        }
        return true
    }

    @Synchronized
    fun getActiveProfile(): FirewallProfileRecord {
        val id = getActiveProfileId()
        return getProfiles().firstOrNull { it.id == id }
            ?: getProfiles().first()
    }

    fun getActiveProfileId(): String = prefs.getString(KEY_ACTIVE_PROFILE, "custom") ?: "custom"
    fun setActiveProfileId(id: String) = prefs.edit().putString(KEY_ACTIVE_PROFILE, id).apply()

    @Synchronized
    fun getBlockedDomains(): List<String> {
        val list = ArrayList<String>()
        dbHelper.readableDatabase.rawQuery("SELECT domain FROM blocked_domains ORDER BY domain ASC", null).use { c ->
            while (c.moveToNext()) list.add(c.getString(0))
        }
        return list
    }

    @Synchronized
    fun addBlockedDomain(domain: String) {
        val clean = domain.trim().lowercase()
        if (clean.isEmpty() || !clean.contains(".")) return
        val cv = ContentValues().apply {
            put("domain", clean)
            put("added_at", System.currentTimeMillis())
        }
        dbHelper.writableDatabase.insertWithOnConflict("blocked_domains", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    @Synchronized
    fun removeBlockedDomain(domain: String) {
        dbHelper.writableDatabase.delete("blocked_domains", "domain = ?", arrayOf(domain.trim().lowercase()))
    }

    @Synchronized
    fun getStatistics(): Map<String, Any> {
        val db = dbHelper.readableDatabase
        val now = System.currentTimeMillis()
        val dayStart = now - 86_400_000L
        val weekStart = now - 7 * 86_400_000L
        val monthStart = now - 30 * 86_400_000L

        var totalAllowed = 0L
        var totalBlocked = 0L
        var todayAttempts = 0L
        var weekAttempts = 0L
        var monthAttempts = 0L

        db.rawQuery("SELECT decision, COUNT(*) FROM activity_logs GROUP BY decision", null).use { c ->
            while (c.moveToNext()) {
                val decision = c.getString(0)
                val count = c.getLong(1)
                if (decision == "allowed") totalAllowed += count else totalBlocked += count
            }
        }
        db.rawQuery("SELECT COUNT(*) FROM activity_logs WHERE timestamp_ms >= ?", arrayOf(dayStart.toString())).use { c ->
            if (c.moveToFirst()) todayAttempts = c.getLong(0)
        }
        db.rawQuery("SELECT COUNT(*) FROM activity_logs WHERE timestamp_ms >= ?", arrayOf(weekStart.toString())).use { c ->
            if (c.moveToFirst()) weekAttempts = c.getLong(0)
        }
        db.rawQuery("SELECT COUNT(*) FROM activity_logs WHERE timestamp_ms >= ?", arrayOf(monthStart.toString())).use { c ->
            if (c.moveToFirst()) monthAttempts = c.getLong(0)
        }

        val topApps = ArrayList<Map<String, Any>>()
        db.rawQuery(
            """
            SELECT package_name, app_name, COUNT(*) as cnt,
                   SUM(CASE WHEN decision = 'blocked' THEN 1 ELSE 0 END) as blocked_cnt
            FROM activity_logs
            GROUP BY package_name
            ORDER BY cnt DESC
            LIMIT 8
            """.trimIndent(),
            null
        ).use { c ->
            while (c.moveToNext()) {
                topApps.add(
                    mapOf(
                        "packageName" to c.getString(0),
                        "appName" to c.getString(1),
                        "attempts" to c.getLong(2),
                        "blocked" to c.getLong(3)
                    )
                )
            }
        }

        return mapOf(
            "totalAllowed" to totalAllowed,
            "totalBlocked" to totalBlocked,
            "totalAttempts" to (totalAllowed + totalBlocked),
            "todayAttempts" to todayAttempts,
            "weekAttempts" to weekAttempts,
            "monthAttempts" to monthAttempts,
            "tunneledBytesRead" to prefs.getLong(KEY_TUN_BYTES_READ, 0L),
            "topApps" to topApps
        )
    }

    fun addTunBytesRead(delta: Long) {
        if (delta <= 0L) return
        val current = prefs.getLong(KEY_TUN_BYTES_READ, 0L)
        prefs.edit().putLong(KEY_TUN_BYTES_READ, current + delta).apply()
    }

    // Settings getters/setters
    fun isAutoQuarantineEnabled(): Boolean = prefs.getBoolean(KEY_AUTO_QUARANTINE, true)
    fun setAutoQuarantineEnabled(v: Boolean) = prefs.edit().putBoolean(KEY_AUTO_QUARANTINE, v).apply()

    fun isBlockOnRoamingEnabled(): Boolean = prefs.getBoolean(KEY_BLOCK_ROAMING, true)
    fun setBlockOnRoamingEnabled(v: Boolean) = prefs.edit().putBoolean(KEY_BLOCK_ROAMING, v).apply()

    fun isAutoStartOnBootEnabled(): Boolean = prefs.getBoolean(KEY_AUTO_START_BOOT, false)
    fun setAutoStartOnBootEnabled(v: Boolean) = prefs.edit().putBoolean(KEY_AUTO_START_BOOT, v).apply()

    fun wasProtectionIntendedActive(): Boolean = prefs.getBoolean(KEY_PROTECTION_ACTIVE, false)
    fun setProtectionIntendedActive(v: Boolean) = prefs.edit().putBoolean(KEY_PROTECTION_ACTIVE, v).apply()

    fun isNotificationsEnabled(): Boolean = prefs.getBoolean(KEY_NOTIF_ENABLED, true)
    fun setNotificationsEnabled(v: Boolean) = prefs.edit().putBoolean(KEY_NOTIF_ENABLED, v).apply()

    fun isScreenOffAlertEnabled(): Boolean = prefs.getBoolean(KEY_SCREEN_OFF_ALERT, true)
    fun setScreenOffAlertEnabled(v: Boolean) = prefs.edit().putBoolean(KEY_SCREEN_OFF_ALERT, v).apply()

    fun getLanguageCode(): String = prefs.getString(KEY_LANGUAGE, "ar") ?: "ar"
    fun setLanguageCode(lang: String) {
        val safe = if (lang == "en") "en" else "ar"
        prefs.edit().putString(KEY_LANGUAGE, safe).apply()
    }

    fun exportAllSettingsJson(): JSONObject = JSONObject().apply {
        put("language", getLanguageCode())
        put("activeProfileId", getActiveProfileId())
        put("autoQuarantine", isAutoQuarantineEnabled())
        put("blockOnRoaming", isBlockOnRoamingEnabled())
        put("autoStartOnBoot", isAutoStartOnBootEnabled())
        put("notificationsEnabled", isNotificationsEnabled())
        put("screenOffAlertEnabled", isScreenOffAlertEnabled())
    }

    fun importSettingsJson(obj: JSONObject) {
        setLanguageCode(obj.optString("language", "ar"))
        setAutoQuarantineEnabled(obj.optBoolean("autoQuarantine", true))
        setBlockOnRoamingEnabled(obj.optBoolean("blockOnRoaming", true))
        setAutoStartOnBootEnabled(obj.optBoolean("autoStartOnBoot", false))
        setNotificationsEnabled(obj.optBoolean("notificationsEnabled", true))
        setScreenOffAlertEnabled(obj.optBoolean("screenOffAlertEnabled", true))
        val profileId = obj.optString("activeProfileId", "custom")
        if (getProfiles().any { it.id == profileId }) {
            setActiveProfileId(profileId)
        }
    }

    companion object {
        private const val PREFS_NAME = "archon_shield_prefs"
        private const val KEY_ACTIVE_PROFILE = "active_profile"
        private const val KEY_AUTO_QUARANTINE = "auto_quarantine"
        private const val KEY_BLOCK_ROAMING = "block_roaming"
        private const val KEY_AUTO_START_BOOT = "auto_start_boot"
        private const val KEY_PROTECTION_ACTIVE = "protection_intended_active"
        private const val KEY_NOTIF_ENABLED = "notif_enabled"
        private const val KEY_SCREEN_OFF_ALERT = "screen_off_alert"
        private const val KEY_LANGUAGE = "language_code"
        private const val KEY_TUN_BYTES_READ = "tun_bytes_read"

        @Volatile
        private var instance: FirewallRulesStore? = null

        fun getInstance(context: Context): FirewallRulesStore =
            instance ?: synchronized(this) {
                instance ?: FirewallRulesStore(context).also { instance = it }
            }
    }
}
