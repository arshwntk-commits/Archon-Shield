package com.archontech.shield.notifications

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.archontech.shield.MainActivity
import com.archontech.shield.R
import com.archontech.shield.models.NetworkTransport
import com.archontech.shield.rules.FirewallRulesStore

class FirewallNotificationManager(private val context: Context) {

    private val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val rulesStore = FirewallRulesStore.getInstance(context)

    init {
        ensureChannels()
    }

    private fun isArabic(): Boolean = rulesStore.getLanguageCode() == "ar"

    private fun canPostNotifications(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return false
        }
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    private fun ensureChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val ar = isArabic()
        val channels = listOf(
            NotificationChannel(
                CHANNEL_STATUS,
                if (ar) "حالة جدار الحماية" else "Firewall Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = if (ar) "إشعار دائم لحالة خدمة VPN المحلية" else "Ongoing notification for active local VPN firewall"
            },
            NotificationChannel(
                CHANNEL_PENDING,
                if (ar) "طلبات الاتصال والانتظار" else "Pending Connection Requests",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = if (ar) "إشعارات فورية مع أزرار السماح والرفض" else "Instant alerts with direct allow/deny controls"
            },
            NotificationChannel(
                CHANNEL_QUARANTINE,
                if (ar) "التطبيقات الجديدة والحجر" else "New Apps & Quarantine",
                NotificationManager.IMPORTANCE_DEFAULT
            ),
            NotificationChannel(
                CHANNEL_ALERTS,
                if (ar) "تنبيهات الأمان والنظام" else "Security & System Alerts",
                NotificationManager.IMPORTANCE_HIGH
            )
        )
        channels.forEach { manager.createNotificationChannel(it) }
    }

    fun buildOngoingStatusNotification(
        allowedCount: Int,
        blockedCount: Int,
        network: NetworkTransport
    ): Notification {
        val ar = isArabic()
        val netLabel = networkLabel(network, ar)
        val title = if (ar) "درع أرشون نشط · $netLabel" else "ARCHON SHIELD Active · $netLabel"
        val text = if (ar) {
            "محجوب: $blockedCount تطبيق · مسموح: $allowedCount تطبيق"
        } else {
            "Blocked: $blockedCount apps · Allowed: $allowedCount apps"
        }

        val openIntent = PendingIntent.getActivity(
            context,
            100,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getBroadcast(
            context,
            101,
            Intent(context, NotificationActionReceiver::class.java).apply {
                action = NotificationActionReceiver.ACTION_STOP_VPN
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(context, CHANNEL_STATUS)
            .setSmallIcon(R.drawable.ic_archon_tile)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openIntent)
            .addAction(0, if (ar) "إيقاف الحماية" else "Stop Protection", stopIntent)
            .build()
    }

    fun updateOngoingStatus(allowedCount: Int, blockedCount: Int, network: NetworkTransport) {
        if (!canPostNotifications()) return
        manager.notify(STATUS_NOTIFICATION_ID, buildOngoingStatusNotification(allowedCount, blockedCount, network))
    }

    fun notifyPendingConnection(
        packageName: String,
        appName: String,
        network: NetworkTransport,
        domainOrIp: String,
        isScreenOff: Boolean
    ) {
        if (!canPostNotifications() || !rulesStore.isNotificationsEnabled()) return
        val ar = isArabic()
        val netLabel = networkLabel(network, ar)
        val screenTag = if (isScreenOff) {
            if (ar) " · الشاشة مطفأة" else " · Screen Off"
        } else ""

        val title = if (ar) "طلب اتصال: $appName" else "Connection Attempt: $appName"
        val body = if (ar) {
            "$netLabel$screenTag · الوجهة: $domainOrIp"
        } else {
            "$netLabel$screenTag · Target: $domainOrIp"
        }

        val notifId = (packageName.hashCode() and 0x7FFF) + 1000
        val detailIntent = PendingIntent.getActivity(
            context,
            notifId,
            Intent(context, MainActivity::class.java).apply {
                putExtra("open_app_package", packageName)
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val sessionAllowPi = actionPendingIntent(notifId * 10 + 1, NotificationActionReceiver.ACTION_ALLOW_SESSION, packageName, network, notifId)
        val permAllowPi = actionPendingIntent(notifId * 10 + 2, NotificationActionReceiver.ACTION_ALLOW_PERMANENT, packageName, network, notifId)
        val denyPi = actionPendingIntent(notifId * 10 + 3, NotificationActionReceiver.ACTION_DENY_SESSION, packageName, network, notifId)

        val builder = NotificationCompat.Builder(context, CHANNEL_PENDING)
            .setSmallIcon(R.drawable.ic_archon_tile)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(detailIntent)
            .addAction(0, if (ar) "✓ جلسة" else "✓ Session", sessionAllowPi)
            .addAction(0, if (ar) "✓✓ دائم" else "✓✓ Always", permAllowPi)
            .addAction(0, if (ar) "✕ رفض" else "✕ Deny", denyPi)

        loadAppIconBitmap(packageName)?.let { builder.setLargeIcon(it) }
        manager.notify(notifId, builder.build())
    }

    fun notifyNewAppQuarantined(packageName: String, appName: String) {
        if (!canPostNotifications()) return
        val ar = isArabic()
        val notifId = (packageName.hashCode() and 0x7FFF) + 5000
        val openIntent = PendingIntent.getActivity(
            context,
            notifId,
            Intent(context, MainActivity::class.java).apply {
                putExtra("open_app_package", packageName)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(context, CHANNEL_QUARANTINE)
            .setSmallIcon(R.drawable.ic_archon_tile)
            .setContentTitle(if (ar) "تم وضع تطبيق جديد في الحجر: $appName" else "New App Quarantined: $appName")
            .setContentText(if (ar) "تم منعه من الاتصال بالإنترنت حتى تقرر السماح أو الحظر." else "Network access blocked until you allow or deny.")
            .setAutoCancel(true)
            .setContentIntent(openIntent)
            .build()
        manager.notify(notifId, notif)
    }

    fun notifyNewAppInstalled(packageName: String, appName: String) {
        if (!canPostNotifications()) return
        val ar = isArabic()
        val notifId = (packageName.hashCode() and 0x7FFF) + 6000
        val notif = NotificationCompat.Builder(context, CHANNEL_QUARANTINE)
            .setSmallIcon(R.drawable.ic_archon_tile)
            .setContentTitle(if (ar) "تم تثبيت تطبيق جديد: $appName" else "New App Installed: $appName")
            .setContentText(if (ar) "اضغط لمراجعة قواعد الشبكة الخاصة بالتطبيق." else "Tap to review Wi-Fi and Mobile Data rules.")
            .setAutoCancel(true)
            .build()
        manager.notify(notifId, notif)
    }

    fun notifyServiceStopped(revokedBySystem: Boolean) {
        if (!canPostNotifications()) return
        val ar = isArabic()
        val title = if (revokedBySystem) {
            if (ar) "تم سحب إذن VPN وإيقاف الحماية" else "VPN Permission Revoked"
        } else {
            if (ar) "توقفت خدمة درع أرشون" else "ARCHON SHIELD Service Stopped"
        }
        val text = if (ar) {
            "التطبيقات لم تعد محجوبة الآن. اضغط لإعادة تشغيل درع أرشون."
        } else {
            "Traffic is no longer filtered. Tap to re-enable ARCHON SHIELD."
        }
        val openIntent = PendingIntent.getActivity(
            context,
            900,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_archon_tile)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openIntent)
            .build()
        manager.notify(ALERT_STOPPED_ID, notif)
    }

    fun notifyVpnError() {
        if (!canPostNotifications()) return
        val ar = isArabic()
        val notif = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_archon_tile)
            .setContentTitle(if (ar) "تعذر تشغيل جدار الحماية (VPN)" else "VPN Firewall Start Failed")
            .setContentText(if (ar) "تأكد من عدم وجود VPN آخر نشط أو امنح صلاحية VPN." else "Ensure no conflicting VPN is active and VPN consent is granted.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        manager.notify(ALERT_ERROR_ID, notif)
    }

    fun notifySensitiveDecisionWarning(appName: String) {
        if (!canPostNotifications()) return
        val ar = isArabic()
        val notif = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_archon_tile)
            .setContentTitle(if (ar) "تنبيه: حظر تطبيق حساس ($appName)" else "Warning: Sensitive App Blocked ($appName)")
            .setContentText(if (ar) "قد تتأثر الإشعارات أو خدمات النظام المرتبطة بهذا المكون." else "Related system functions or push notifications may be impacted.")
            .setAutoCancel(true)
            .build()
        manager.notify(ALERT_SENSITIVE_ID, notif)
    }

    fun cancelNotification(id: Int) {
        manager.cancel(id)
    }

    private fun actionPendingIntent(
        requestCode: Int,
        action: String,
        packageName: String,
        network: NetworkTransport,
        notifId: Int
    ): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).apply {
            this.action = action
            putExtra(NotificationActionReceiver.EXTRA_PACKAGE, packageName)
            putExtra(NotificationActionReceiver.EXTRA_NETWORK, network.wire)
            putExtra(NotificationActionReceiver.EXTRA_NOTIF_ID, notifId)
        }
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun loadAppIconBitmap(pkg: String): Bitmap? {
        return try {
            val d = context.packageManager.getApplicationIcon(pkg)
            if (d is BitmapDrawable && d.bitmap != null) return d.bitmap
            val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            d.setBounds(0, 0, canvas.width, canvas.height)
            d.draw(canvas)
            bmp
        } catch (_: Exception) {
            null
        }
    }

    private fun networkLabel(network: NetworkTransport, ar: Boolean): String = when (network) {
        NetworkTransport.WIFI -> if (ar) "واي فاي" else "Wi-Fi"
        NetworkTransport.MOBILE -> if (ar) "بيانات الهاتف" else "Mobile Data"
        NetworkTransport.ROAMING -> if (ar) "تجوال دولي" else "Roaming"
        NetworkTransport.NONE -> if (ar) "غير متصل" else "Offline"
    }

    companion object {
        const val STATUS_NOTIFICATION_ID = 1001
        private const val ALERT_STOPPED_ID = 1002
        private const val ALERT_ERROR_ID = 1003
        private const val ALERT_SENSITIVE_ID = 1004

        private const val CHANNEL_STATUS = "archon_vpn_status"
        private const val CHANNEL_PENDING = "archon_pending_requests"
        private const val CHANNEL_QUARANTINE = "archon_new_app_quarantine"
        private const val CHANNEL_ALERTS = "archon_alerts"
    }
}
