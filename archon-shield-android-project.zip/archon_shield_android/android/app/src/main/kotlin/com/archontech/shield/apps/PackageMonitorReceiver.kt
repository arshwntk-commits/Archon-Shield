package com.archontech.shield.apps

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.archontech.shield.bridge.ArchonEventBus
import com.archontech.shield.notifications.FirewallNotificationManager
import com.archontech.shield.rules.FirewallRulesStore
import com.archontech.shield.vpn.ArchonFirewallVpnService

/**
 * Monitors device boot and app install/update/uninstall broadcasts.
 *
 * Android limitation documented: PACKAGE_ADDED arrives slightly after the OS finishes
 * package installation (~milliseconds to ~1s depending on system load). If Auto-Quarantine
 * is enabled, any newly added package is immediately placed under quarantine and blocked
 * because ArchonFirewallVpnService runs in default-deny mode.
 */
class PackageMonitorReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val rulesStore = FirewallRulesStore.getInstance(context)

        when (action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED -> {
                // Always clear ephemeral session rules on device reboot
                rulesStore.clearSessionRules()
                if (rulesStore.isAutoStartOnBootEnabled() && rulesStore.wasProtectionIntendedActive()) {
                    ArchonFirewallVpnService.startIfPermitted(context)
                }
            }

            Intent.ACTION_PACKAGE_ADDED -> {
                val pkgName = intent.data?.schemeSpecificPart ?: return
                val replacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)
                if (replacing || pkgName == context.packageName) return

                val scanner = AppInventoryScanner(context, rulesStore)
                val appName = scanner.resolveAppName(pkgName)
                val notifications = FirewallNotificationManager(context)

                if (rulesStore.isAutoQuarantineEnabled()) {
                    rulesStore.setQuarantined(pkgName, true)
                    notifications.notifyNewAppQuarantined(pkgName, appName)
                    if (ArchonFirewallVpnService.isServiceRunning()) {
                        ArchonFirewallVpnService.requestTunnelReload(context)
                    }
                } else {
                    notifications.notifyNewAppInstalled(pkgName, appName)
                }

                ArchonEventBus.emit(
                    "apps_changed",
                    mapOf("event" to "added", "packageName" to pkgName, "appName" to appName)
                )
            }

            Intent.ACTION_PACKAGE_REPLACED -> {
                val pkgName = intent.data?.schemeSpecificPart ?: return
                ArchonEventBus.emit(
                    "apps_changed",
                    mapOf("event" to "updated", "packageName" to pkgName)
                )
            }

            Intent.ACTION_PACKAGE_REMOVED -> {
                val pkgName = intent.data?.schemeSpecificPart ?: return
                val replacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)
                if (!replacing) {
                    rulesStore.deleteRulesForPackage(pkgName)
                    rulesStore.setQuarantined(pkgName, false)
                    if (ArchonFirewallVpnService.isServiceRunning()) {
                        ArchonFirewallVpnService.requestTunnelReload(context)
                    }
                    ArchonEventBus.emit(
                        "apps_changed",
                        mapOf("event" to "removed", "packageName" to pkgName)
                    )
                }
            }
        }
    }
}
