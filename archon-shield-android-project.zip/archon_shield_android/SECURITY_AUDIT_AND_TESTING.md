# تدقيق الأمان والاختبارات — ARCHON SHIELD

## الضوابط الأمنية المتحققة في الكود
1. **تخزين PIN محلي آمن (`AppSecurityManager.kt`):**
   - يُشتق رمز PIN باستخدام `PBKDF2WithHmacSHA256` (120,000 دورة + Salt عشوائي 16 بايت) ويُحفظ داخل `EncryptedSharedPreferences` المدعوم بـ Android Keystore (`AES256_GCM`).
2. **حماية أوامر الإشعارات (`AndroidManifest.xml` + `NotificationActionReceiver.kt`):**
   - المستقبل `NotificationActionReceiver` مضبوط على `android:exported="false"` لمنع أي تطبيق خارجي من حقن أوامر سماح أو إيقاف مزيفة.
3. **سلامة النسخ الاحتياطي والاستيراد (`LocalBackupManager.kt`):**
   - التحقق من `format`، `schemaVersion`، حد الحجم الأقصى (5 MB)، بصمة `SHA-256`، والتحقق من صحة أسماء الحزم (`^[a-zA-Z0-9_.]{1,200}$`) والنطاقات قبل الكتابة في SQLite.
4. **استعلامات SQLite آمنة (`FirewallRulesStore.kt`):**
   - استخدام المعاملات المرتبطة (`?` placeholders) في جميع الاستعلامات لمنع SQL Injection.
5. **منع تسريب IPv6 و DNS (`ArchonFirewallVpnService.kt`):**
   - التقاط مساري `0.0.0.0/0` و `::/0` داخل نفق TUN للتطبيقات المحجوبة وقيد الانتظار مع إبقاء التطبيقات المسموحة مستثناة عبر `addDisallowedApplication`.
6. **توثيق حدود بيئة التطوير:**
   - لم يُجمَّع ملف APK هنا لعدم وجود Flutter SDK أو Android SDK في حاوية الويب؛ تم تصميم وتدقيق الكود بالكامل وتضمين اختبارات الوحدة في `test/` و `android/app/src/test/`.
