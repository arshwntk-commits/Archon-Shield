import 'package:flutter_test/flutter_test.dart';
import 'package:archon_shield/core/localization/app_localizations.dart';
import 'package:archon_shield/models/firewall_models.dart';

void main() {
  test('RuleAction parses symbols and allow/deny semantics accurately', () {
    expect(RuleAction.fromWire('allow_session').symbol, '✓');
    expect(RuleAction.fromWire('allow_permanent').symbol, '✓✓');
    expect(RuleAction.fromWire('deny_session').symbol, '✕');
    expect(RuleAction.fromWire('deny_permanent').symbol, '✕✕');
    expect(RuleAction.allowSession.isAllow, true);
    expect(RuleAction.denySession.isDeny, true);
  });

  test('Localization preserves dual brand name in both Arabic and English', () {
    const ar = AppStrings('ar');
    const en = AppStrings('en');
    expect(ar.brandDual, 'أرشون تك | ARCHON TECH');
    expect(en.brandDual, 'أرشون تك | ARCHON TECH');
  });
}
